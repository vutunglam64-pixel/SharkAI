import { NextRequest, NextResponse } from 'next/server';
import { WORKSPACE_ROOT, ensureWorkspace, safeResolve, isTextFile } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

export const maxDuration = 30;

// Có phải tham chiếu bên ngoài (không phải tệp trong workspace)?
function isExternal(ref: string): boolean {
  return (
    !ref ||
    /^(https?:)?\/\//i.test(ref) ||
    /^data:/i.test(ref) ||
    /^mailto:|^tel:|^javascript:/i.test(ref) ||
    ref.startsWith('#')
  );
}

// Ghép ref tương đối với thư mục chứa entry → đường dẫn rel chuẩn trong workspace
function resolveRef(entryDir: string, ref: string): string | null {
  const clean = ref.split('#')[0].split('?')[0].trim();
  if (!clean) return null;
  const abs = safeResolve(WORKSPACE_ROOT, entryDir ? `${entryDir}/${clean}` : clean);
  if (!abs) return null;
  if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) return null;
  return path.relative(WORKSPACE_ROOT, abs).split(path.sep).join('/');
}

function readText(rel: string): string | null {
  const abs = safeResolve(WORKSPACE_ROOT, rel);
  if (!abs) return null;
  if (!isTextFile(abs) && fs.statSync(abs).size > 256 * 1024) return null;
  return fs.readFileSync(abs, 'utf-8');
}

function readDataUrl(rel: string): string | null {
  const abs = safeResolve(WORKSPACE_ROOT, rel);
  if (!abs || !fs.existsSync(abs) || !fs.statSync(abs).isFile()) return null;
  const st = fs.statSync(abs);
  if (st.size > 1024 * 1024) return null;
  const buf = fs.readFileSync(abs);
  const ext = path.extname(abs).toLowerCase();
  const mimes: Record<string, string> = {
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
    '.webp': 'image/webp', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
    '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.wav': 'audio/wav',
    '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  };
  const mime = mimes[ext] || 'application/octet-stream';
  return `data:${mime};base64,${buf.toString('base64')}`;
}

// GET /api/preview-bundle?path=index.html
// Xem trước ĐA TỆP: inline CSS/JS, ảnh → data URL, link .html → bundle khác.
// Kết quả là 1 tài liệu HTML trọn vẹn xem được trong iframe (html + css + js cùng lúc).
export async function GET(req: NextRequest) {
  ensureWorkspace();
  const relEntry = String(req.nextUrl.searchParams.get('path') || '').replace(/^[/\\]+/, '');
  if (!relEntry) {
    return new NextResponse('Thiếu tham số path', {
      status: 400,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  if (!/\.html?$/i.test(relEntry)) {
    return new NextResponse('Chỉ xem trước được tệp .html (bản xem trước tự ghép kèm CSS/JS)', {
      status: 400,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  const absEntry = safeResolve(WORKSPACE_ROOT, relEntry);
  if (!absEntry || !fs.existsSync(absEntry) || !fs.statSync(absEntry).isFile()) {
    return new NextResponse('Không tìm thấy tệp trong thư mục dự án', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  const entryDir = path.dirname(relEntry) === '.' ? '' : path.dirname(relEntry);
  let inlined = 0;

  const bundleHtml = (html: string): string => {
    // 1) <link rel="stylesheet" href="..."> → <style> nội dung </style>
    html = html.replace(
      /<link\b[^>]*rel=["']stylesheet["'][^>]*>/gi,
      (tag) => {
        const m = tag.match(/href\s*=\s*["']([^"']+)["']/i);
        if (!m || isExternal(m[1])) return tag;
        const rel = resolveRef(entryDir, m[1]);
        if (!rel || inlined > 40) return tag;
        const css = readText(rel);
        if (css == null) return tag;
        inlined++;
        return `<style>\n/* ${rel} */\n${css.replace(/<\/style>/gi, '<\\/style>')}\n</style>`;
      }
    );
    // (dạng href đứng trước rel)
    html = html.replace(
      /<link\b(?![^>]*rel=["']stylesheet["'])[^>]*href\s*=\s*["']([^"']+)["'][^>]*rel=["']stylesheet["'][^>]*>/gi,
      (tag) => {
        const m = tag.match(/href\s*=\s*["']([^"']+)["']/i);
        if (!m || isExternal(m[1])) return tag;
        const rel = resolveRef(entryDir, m[1]);
        if (!rel || inlined > 40) return tag;
        const css = readText(rel);
        if (css == null) return tag;
        inlined++;
        return `<style>\n/* ${rel} */\n${css.replace(/<\/style>/gi, '<\\/style>')}\n</style>`;
      }
    );

    // 2) <script src="..."></script> → nội dung script inline
    html = html.replace(
      /<script\b([^>]*)\bsrc\s*=\s*["']([^"']+)["']([^>]*)><\/script>/gi,
      (tag, pre: string, src: string, post: string) => {
        if (isExternal(src)) return tag;
        const rel = resolveRef(entryDir, src);
        if (!rel || inlined > 40) return tag;
        const js = readText(rel);
        if (js == null) return tag;
        inlined++;
        const keepType = /type\s*=\s*["']module["']/i.test(`${pre}${post}`) ? ' type="module"' : '';
        return `<script${keepType}>\n// ${rel}\n${js.replace(/<\/script>/gi, '<\\/script>')}\n</script>`;
      }
    );

    // 3) ảnh / video / font local → data URL
    html = html.replace(
      /\b(src|href|poster)\s*=\s*["']([^"']+)["']/gi,
      (tag, attr: string, ref: string) => {
        if (isExternal(ref)) return tag;
        if (!/\.(png|jpe?g|gif|webp|svg|ico|mp4|webm|mp3|wav|woff2?|ttf)([?#]|$)/i.test(ref)) return tag;
        const rel = resolveRef(entryDir, ref);
        if (!rel || inlined > 60) return tag;
        const data = readDataUrl(rel);
        if (!data) return tag;
        inlined++;
        return `${attr}="${data}"`;
      }
    );

    // 4) url(...) trong style inline → data URL
    html = html.replace(
      /url\(\s*["']?([^"')]+)["']?\s*\)/gi,
      (tag, ref: string) => {
        if (isExternal(ref) || ref.startsWith('data:')) return tag;
        if (!/\.(png|jpe?g|gif|webp|svg|ico|woff2?|ttf)([?#]|$)/i.test(ref)) return tag;
        const rel = resolveRef(entryDir, ref);
        if (!rel || inlined > 80) return tag;
        const data = readDataUrl(rel);
        if (!data) return tag;
        inlined++;
        return `url("${data}")`;
      }
    );

    // 5) liên kết tới trang .html khác → mở tiếp qua bundle
    html = html.replace(
      /<a\b([^>]*)href\s*=\s*["']([^"']+\.html?)(["'][^>]*)>/gi,
      (tag, pre: string, ref: string, post: string) => {
        if (isExternal(ref)) return tag;
        const rel = resolveRef(entryDir, ref);
        if (!rel) return tag;
        return `<a${pre}href="/api/preview-bundle?path=${encodeURIComponent(rel)}"${post}>`;
      }
    );

    return html;
  };

  let html = fs.readFileSync(absEntry, 'utf-8');
  if (html.length > 400 * 1024) {
    return new NextResponse('Tệp HTML quá lớn để xem trước', {
      status: 413,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  html = bundleHtml(html);

  return new NextResponse(html, {
    status: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}
