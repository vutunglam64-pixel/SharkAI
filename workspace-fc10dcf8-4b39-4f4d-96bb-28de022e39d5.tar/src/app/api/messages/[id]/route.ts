import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';

/** Lấy danh sách id các tin nhắn ĐỨNG SAU tin nhắn cho trước (theo thứ tự tạo) */
async function idsAfter(sessionId: string, createdAt: Date): Promise<string[]> {
  const after = await db.message.findMany({
    where: { sessionId, createdAt: { gt: createdAt } },
    orderBy: { createdAt: 'asc' },
    select: { id: true },
  });
  return after.map((m) => m.id);
}

// PATCH có 2 luồng:
// 1) Tin nhắn USER: sửa nội dung + XOÁ toàn bộ tin nhắn phía sau → tạo lại (flow chuẩn)
// 2) Tin nhắn ASSISTANT + body.finalize: LƯU KẾT QUẢ Gemini client-side stream về DB
//    (content/thinking/status) — KHÔNG cắt tin nhắn nào
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await jsonBody(req);

  const msg = await db.message.findUnique({ where: { id } });
  if (!msg) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 });

  // ---------- Luồng 2: finalize dòng assistant (Gemini client-side) ----------
  if (msg.role === 'assistant' && body.finalize === true) {
    let content = String(body.content || '');
    if (body.errorMessage) {
      content += (content ? '\n\n' : '') + `> ⚠️ ${String(body.errorMessage).slice(0, 300)}`;
    }
    const status = ['done', 'stopped', 'error'].includes(String(body.status)) ? String(body.status) : 'done';
    const updated = await db.message.update({
      where: { id },
      data: {
        content,
        thinking: body.thinking ? String(body.thinking) : null,
        status,
      },
    });
    return NextResponse.json({ ok: true, message: updated });
  }

  // ---------- Luồng 1: sửa tin nhắn user ----------
  const content = String(body.content || '').trim();
  if (!content) return NextResponse.json({ error: 'Thiếu nội dung' }, { status: 400 });
  if (msg.role !== 'user') return NextResponse.json({ error: 'Chỉ sửa được tin nhắn của bạn' }, { status: 400 });

  const toDelete = await idsAfter(msg.sessionId, msg.createdAt);
  if (toDelete.length > 0) {
    await db.message.deleteMany({ where: { id: { in: toDelete } } });
  }
  const updated = await db.message.update({ where: { id }, data: { content } });
  return NextResponse.json({ ok: true, message: updated, deletedIds: toDelete });
}

// Xoá tin nhắn này + toàn bộ tin nhắn phía sau (dùng cho "Tạo lại" câu trả lời)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const msg = await db.message.findUnique({ where: { id } });
  if (!msg) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 });

  const toDelete = await idsAfter(msg.sessionId, msg.createdAt);
  await db.message.deleteMany({ where: { id: { in: [...toDelete, id] } } });
  return NextResponse.json({ ok: true, deletedIds: [...toDelete, id] });
}
