import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { MODELS } from '@/lib/config';

// ============================================================
// GET /api/v1/models — danh sách model, chuẩn OpenAI
//   Header: Authorization: Bearer sk-shark-free...
// ============================================================

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
};

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS });
}

export async function GET(req: NextRequest) {
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace(/^Bearer\s+/i, '').trim();
  if (token.startsWith('sk-shark-free')) {
    const keyRow = await db.apiKey.findUnique({ where: { key: token } }).catch(() => null);
    if (!keyRow || keyRow.revoked) {
      return new Response(
        JSON.stringify({ error: { message: 'API key không hợp lệ.', type: 'invalid_request_error', code: 'invalid_api_key' } }),
        { status: 401, headers: { 'Content-Type': 'application/json', ...CORS } }
      );
    }
  } else {
    return new Response(
      JSON.stringify({ error: { message: 'Thiếu Authorization: Bearer sk-shark-free...', type: 'invalid_request_error', code: 'missing_api_key' } }),
      { status: 401, headers: { 'Content-Type': 'application/json', ...CORS } }
    );
  }

  return new Response(
    JSON.stringify({
      object: 'list',
      data: MODELS.map((m) => ({
        id: m.id,
        object: 'model',
        created: 1700000000,
        owned_by: m.vendor.toLowerCase().replace(/\s+/g, '-'),
        shark: { name: m.name, params: m.params, desc: m.desc, license: m.license },
      })),
    }),
    { headers: { 'Content-Type': 'application/json', ...CORS } }
  );
}
