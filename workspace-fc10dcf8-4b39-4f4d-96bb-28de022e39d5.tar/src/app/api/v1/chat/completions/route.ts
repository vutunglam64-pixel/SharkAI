import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getZAI } from '@/lib/zai';
import { parseSDKStream } from '@/lib/stream';
import { MODELS } from '@/lib/config';

// ============================================================
// Shark Public API — tương thích 100% chuẩn OpenAI / Groq
//
//   POST /api/v1/chat/completions
//   Header: Authorization: Bearer sk-shark-free...
//   Body:   { model, messages: [{role, content}], stream? }
//
//   GET  /api/v1/models   → danh sách model
//   → Dùng được ngay với SDK OpenAI / LangChain / mọi tool
//     hiểu chuẩn OpenAI (chỉ cần đổi base_url + api_key)
// ============================================================

export const maxDuration = 300;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
};

function errJson(message: string, type: string, code: string, status: number) {
  return new Response(
    JSON.stringify({ error: { message, type, code } }),
    { status, headers: { 'Content-Type': 'application/json', ...CORS } }
  );
}

export async function OPTIONS() {
  return new Response(null, { status: 204, headers: CORS });
}

interface OAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OAIBody {
  model?: string;
  messages?: OAIMessage[];
  stream?: boolean;
  temperature?: number;
  max_tokens?: number;
}

export async function POST(req: NextRequest) {
  // ---------- 1. Xác thực Bearer key ----------
  const auth = req.headers.get('authorization') || '';
  const token = auth.replace(/^Bearer\s+/i, '').trim();
  if (!token.startsWith('sk-shark-free')) {
    return errJson(
      'Thiếu hoặc sai API key. Tạo key trong Shark → mục API, rồi gửi header "Authorization: Bearer sk-shark-free..."',
      'invalid_request_error',
      'missing_api_key',
      401
    );
  }
  const keyRow = await db.apiKey.findUnique({ where: { key: token } }).catch(() => null);
  if (!keyRow || keyRow.revoked) {
    return errJson('API key không hợp lệ hoặc đã bị thu hồi.', 'invalid_request_error', 'invalid_api_key', 401);
  }

  // ---------- 2. Đọc body ----------
  const body = (await req.json().catch(() => null)) as OAIBody | null;
  if (!body || !Array.isArray(body.messages) || body.messages.length === 0) {
    return errJson('Body phải có mảng "messages" (không rỗng).', 'invalid_request_error', 'invalid_messages', 400);
  }

  const messages = body.messages
    .filter((m) => m && typeof m.content === 'string')
    .slice(-40)
    .map((m) => ({ role: m.role === 'assistant' ? ('assistant' as const) : ('user' as const), content: m.content }));

  const modelId = MODELS.some((m) => m.id === body.model) ? (body.model as string) : 'shark-1';
  const modelDef = MODELS.find((m) => m.id === modelId)!;
  const stream = body.stream === true;

  // Gemini chạy client-side (trong app, browser gọi Google trực tiếp) — không phục vụ qua API công khai
  if (modelId.startsWith('gemini-')) {
    return errJson(
      `Model "${modelId}" chỉ dùng được trong app Shark (trình duyệt gọi trực tiếp Google API). Qua API công khai hãy chọn: shark-1, deepseek-v3, kimi-k2, deepseek-r1.`,
      'invalid_request_error',
      'gemini_client_only',
      400
    );
  }

  // đếm lượt dùng (bất đồng bộ, không chặn câu trả lời)
  const bumpUsage = () =>
    db.apiKey
      .update({ where: { id: keyRow.id }, data: { calls: { increment: 1 }, lastUsedAt: new Date() } })
      .catch(() => {});

  // ---------- 3. Gọi mô hình ----------
  try {
    const zai = await getZAI();
    const sys = { role: 'assistant' as const, content: `${modelDef.persona}\nBạn đang được gọi qua Shark Public API. Trả lời trực tiếp, đúng chuẩn Markdown, ưu tiên ngôn ngữ của người hỏi.` };

    const completion = await zai.chat.completions.create({
      messages: [sys, ...messages] as never,
      stream: stream ? true : false,
      thinking: { type: 'disabled' },
    });

    const id = `chatcmpl-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
    const created = Math.floor(Date.now() / 1000);

    // ---------- 3a. Không stream: trả JSON 1 khối như OpenAI ----------
    if (!stream) {
      const content = String((completion as { choices?: { message?: { content?: string } }[] })?.choices?.[0]?.message?.content || '');
      bumpUsage();
      return new Response(
        JSON.stringify({
          id,
          object: 'chat.completion',
          created,
          model: modelId,
          choices: [
            {
              index: 0,
              message: { role: 'assistant', content },
              finish_reason: 'stop',
            },
          ],
          usage: {
            prompt_tokens: Math.ceil(messages.reduce((a, m) => a + m.content.length, 0) / 4),
            completion_tokens: Math.ceil(content.length / 4),
            total_tokens: 0,
          },
        }),
        { headers: { 'Content-Type': 'application/json', ...CORS } }
      );
    }

    // ---------- 3b. Stream: SSE chunk như OpenAI ----------
    bumpUsage();
    const encoder = new TextEncoder();
    // SDK trả về ReadableStream NGAY TRONG completion khi stream: true
    // (không có property .body — trước đây đọc .body → stream rỗng, mất content chunks)
    const upstream = (stream
      ? (completion as unknown as ReadableStream<Uint8Array>)
      : null) ?? null;
    const sse = new ReadableStream<Uint8Array>({
      async start(controller) {
        const send = (payload: unknown) =>
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
        // chunk đầu: role
        send({
          id,
          object: 'chat.completion.chunk',
          created,
          model: modelId,
          choices: [{ index: 0, delta: { role: 'assistant', content: '' }, finish_reason: null }],
        });
        try {
          for await (const delta of parseSDKStream(upstream)) {
            if (!delta.content) continue;
            send({
              id,
              object: 'chat.completion.chunk',
              created,
              model: modelId,
              choices: [{ index: 0, delta: { content: delta.content }, finish_reason: null }],
            });
          }
        } catch {
          /* stream lỗi giữa chừng → vẫn đóng chuẩn OpenAI */
        }
        send({
          id,
          object: 'chat.completion.chunk',
          created,
          model: modelId,
          choices: [{ index: 0, delta: {}, finish_reason: 'stop' }],
        });
        controller.enqueue(encoder.encode('data: [DONE]\n\n'));
        controller.close();
      },
    });
    return new Response(sse, {
      headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache', ...CORS },
    });
  } catch (e) {
    return errJson(
      e instanceof Error ? e.message : 'Lỗi máy chủ khi gọi mô hình',
      'server_error',
      'internal_error',
      500
    );
  }
}
