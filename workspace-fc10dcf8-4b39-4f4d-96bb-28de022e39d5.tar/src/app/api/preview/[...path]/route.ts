import { NextRequest, NextResponse } from 'next/server';
import { WORKSPACE_ROOT, mimeOf, safeResolve } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

// GET /api/preview/<path> — phục vụ file từ workspace (inline) cho iframe xem trước
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path: segments } = await params;
  const rel = (segments || []).join('/');
  const abs = safeResolve(WORKSPACE_ROOT, rel);

  if (!abs) {
    return new NextResponse('Đường dẫn không hợp lệ', {
      status: 400,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
    return new NextResponse('Không tìm thấy tệp trong thư mục dự án', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }

  const buffer = fs.readFileSync(abs);
  const download = _req.nextUrl.searchParams.get('download') === '1';
  const headers: Record<string, string> = {
    'Content-Type': mimeOf(abs),
    'Cache-Control': 'no-store',
  };
  if (download) {
    headers['Content-Disposition'] = `attachment; filename="${encodeURIComponent(path.basename(abs))}"`;
  }
  return new NextResponse(new Uint8Array(buffer), { status: 200, headers });
}
