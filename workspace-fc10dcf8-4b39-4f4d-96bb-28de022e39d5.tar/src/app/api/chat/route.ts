import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { sseHeaders, createSSEResponse, SSEWriter, jsonBody } from '@/lib/sse';
import { getZAI } from '@/lib/zai';
import { parseSDKStream } from '@/lib/stream';
import { buildSystemPrompt, buildWorkerPrompt, buildBossPlanPrompt } from '@/lib/prompts';
import {
  executeTool,
  extractToolCall,
  webSearch,
  pageReader,
  normalizeToolName,
} from '@/lib/tools';
import { PERSONAS } from '@/lib/config';
import { getSessionUser } from '@/lib/auth';
import { cancelSession, clearCancel, isCancelled } from '@/lib/runner';
import fs from 'fs';
import path from 'path';

export const maxDuration = 300;

interface Attachment {
  type: 'image' | 'video' | 'document' | 'text';
  name: string;
  url: string; // /api/asset/<file>
  mime: string;
  size: number;
}

interface ChatBody {
  sessionId?: string;
  message: string;
  attachments?: Attachment[];
  model?: string;
  mode?: string;
  topic?: string;
  think?: string;
  speed?: string;
  enabledSkills?: string[];
  groupAI?: boolean;
  reuseUserMessageId?: string; // sửa/tạo lại tin nhắn: dùng lại dòng user đã có
  cancelSessionId?: string; // huỷ phiên đang chạy nền
}

const VISION_MODEL = 'glm-4.6v';
const UPLOAD_ROOT = '/home/z/my-project/upload';

function readUploadDataUrl(url: string): string | null {
  try {
    const name = decodeURIComponent(url.replace('/api/asset/', '')).replace(/\.\./g, '');
    const abs = path.join(UPLOAD_ROOT, name);
    if (!fs.existsSync(abs)) return null;
    const buf = fs.readFileSync(abs);
    const mime = guessMime(name);
    return `data:${mime};base64,${buf.toString('base64')}`;
  } catch {
    return null;
  }
}

function guessMime(name: string): string {
  const ext = path.extname(name).toLowerCase();
  const map: Record<string, string> = {
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
    '.webp': 'image/webp', '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime',
    '.pdf': 'application/pdf', '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.txt': 'text/plain', '.csv': 'text/csv', '.md': 'text/markdown',
  };
  return map[ext] || 'application/octet-stream';
}

export async function POST(req: NextRequest) {
  const body = (await jsonBody(req)) as ChatBody;

  // ---------- Huỷ phiên đang chạy nền ----------
  if (body.cancelSessionId) {
    cancelSession(body.cancelSessionId);
    return new Response(JSON.stringify({ ok: true }), { headers: { 'Content-Type': 'application/json' } });
  }

  const message = (body.message || '').trim();
  const attachments = body.attachments || [];
  const model = body.model || 'shark-1';
  const mode = body.mode || 'normal';
  const topic = body.topic || 'chung';
  const think = body.think || 'off';
  const speed = body.speed || 'medium';
  const enabledSkills = body.enabledSkills || [];
  const groupAI = !!body.groupAI;

  if (!message && attachments.length === 0) {
    return new Response(JSON.stringify({ error: 'Thiếu nội dung' }), { status: 400 });
  }

  // ---------- 1. Session ----------
  const authUser = await getSessionUser(req);
  let sessionId = body.sessionId;
  let isNewSession = false;
  if (!sessionId) {
    const s = await db.chatSession.create({
      data: { model, mode, topic, think, speed, groupAI, title: 'Phiên chat mới', userId: authUser?.id || null },
    });
    sessionId = s.id;
    isNewSession = true;
  } else {
    await db.chatSession.update({
      where: { id: sessionId },
      data: { model, mode, topic, think, speed, groupAI },
    });
  }
  const sid = sessionId as string;

  // ---------- 2. Lưu tin nhắn người dùng ----------
  let userMsg;
  if (body.reuseUserMessageId) {
    // Sửa tin nhắn / tạo lại: tái sử dụng dòng user gốc trong DB (đã được PATCH trước đó)
    const found = await db.message.findUnique({ where: { id: body.reuseUserMessageId } });
    if (!found || found.sessionId !== (sessionId as string) || found.role !== 'user') {
      return new Response(JSON.stringify({ error: 'Tin nhắn gốc không tồn tại' }), { status: 400 });
    }
    userMsg = found;
  } else {
    userMsg = await db.message.create({
      data: {
        sessionId: sid,
        role: 'user',
        content: message,
        attachments: JSON.stringify(attachments),
      },
    });
  }

  // ---------- 3. SSE ----------
  const { stream, writer } = createSSEResponse();

  const run = async () => {
    let assistantContent = '';
    let assistantThinking = '';
    const events: unknown[] = [];
    let assistantRowId: string | null = null;
    let progressTimer: ReturnType<typeof setInterval> | null = null;
    try {
      // Lịch sử hội thoại — đọc TRƯỚC khi tạo dòng assistant đang chạy
      const dbMsgs = await db.message.findMany({
        where: { sessionId: sid, status: { not: 'running' } },
        orderBy: { createdAt: 'asc' },
        take: 30,
      });
      const history = dbMsgs.slice(0, -1).map((m) => ({
        role: m.role as 'user' | 'assistant',
        content:
          m.role === 'user' && m.attachments && m.attachments !== '[]'
            ? `${m.content}\n(đã gửi kèm tệp ${m.attachments})`
            : m.content,
      }));

      // Dòng assistant "đang chạy" — giữ trạng thái để tiếp tục chạy nền khi user thoát chat
      const assistantRow = await db.message.create({
        data: { sessionId: sid, role: 'assistant', content: '', model, status: 'running' },
      });
      assistantRowId = assistantRow.id;

      // Lưu tiến trình tăng dần (mỗi ~2.5s) để UI poll thấy khi quay lại phiên
      let lastSave = 0;
      const persistProgress = async () => {
        const now = Date.now();
        if (now - lastSave < 2400) return;
        lastSave = now;
        try {
          await db.message.update({
            where: { id: assistantRow.id },
            data: {
              content: assistantContent,
              thinking: assistantThinking || null,
              events: JSON.stringify(events),
            },
          });
        } catch {}
      };
      progressTimer = setInterval(() => {
        persistProgress().catch(() => {});
      }, 2500);

      await writer.send({ type: 'meta', sessionId: sid, userMessageId: userMsg.id, assistantMessageId: assistantRow.id, isNewSession });

      const systemPrompt = buildSystemPrompt({ model, mode, topic, think, speed, enabledSkills });

      // Nạp skill tùy chỉnh đang bật từ DB (giống Claude Skills)
      const customSkillIds = enabledSkills
        .filter((s) => s.startsWith('custom:'))
        .map((s) => s.slice('custom:'.length));
      let customSkills: { id: string; name: string; desc: string; prompt: string }[] = [];
      if (customSkillIds.length > 0) {
        try {
          customSkills = await db.userSkill.findMany({ where: { id: { in: customSkillIds } } });
        } catch {}
      }

      // Ngữ cảnh dự án (nếu phiên thuộc 1 dự án)
      let projectName: string | undefined;
      let projectGoal: string | undefined;
      if (body.sessionId) {
        try {
          const sess = await db.chatSession.findUnique({
            where: { id: body.sessionId },
            include: { project: true },
          });
          if (sess?.project) {
            projectName = sess.project.name;
            projectGoal = sess.project.goal || undefined;
          }
        } catch {}
      }

      const fullSystemPrompt = buildSystemPrompt({
        model, mode, topic, think, speed, enabledSkills,
        customSkills, projectName, projectGoal,
      });

      const mediaAtts = attachments.filter((a) => ['image', 'video', 'document'].includes(a.type));
      const textAtts = attachments.filter((a) => a.type === 'text');

      let userText = message;
      for (const a of textAtts) {
        const dataUrl = readUploadDataUrl(a.url);
        if (dataUrl) {
          const b64 = dataUrl.split(',')[1] || '';
          const content = Buffer.from(b64, 'base64').toString('utf-8').slice(0, 40000);
          userText += `\n\n--- Tệp đính kèm: ${a.name} ---\n${content}`;
        }
      }

      // Gemini (Google): server KHÔNG gọi được Google API (bị chặn theo vị trí IP server)
      // → chat chạy CLIENT-SIDE: server lưu DB + phát event delegate, browser người dùng (VN — vùng được hỗ trợ)
      //   tự gọi Google streamGenerateContent rồi PATCH kết quả về DB
      const isGemini = !groupAI && mode === 'normal' && model.startsWith('gemini-') && mediaAtts.length === 0;

      const thinkingEnabled = think !== 'off';
      const zai = await getZAI();

      // ============ GEMINI — delegate cho client gọi Google trực tiếp ============
      if (isGemini) {
        // prompt KHÔNG kèm cú pháp <tool> (không có vòng tool server) và KHÔNG kèm <suy>
        // (Gemini 3.8 có thinking tích hợp — trả về riêng phần thought:true)
        const geminiSystem = buildSystemPrompt({
          model, mode, topic, think: 'off', speed, enabledSkills,
          customSkills, projectName, projectGoal, noTools: true,
        });
        await writer.send({
          type: 'delegate',
          target: 'gemini',
          model,
          system: geminiSystem,
          history: history.slice(-20).map((h) => ({ role: h.role, content: String(h.content).slice(0, 8000) })),
          userText,
        });
      }
      // ============ AGENT MODE ============
      else if (mode === 'agent') {
        const agentMsgs: { role: 'user' | 'assistant'; content: string }[] = [
          { role: 'user', content: fullSystemPrompt },
          ...history,
          { role: 'user', content: userText },
        ];
        const stripSuy = (s: string) => {
          const m = s.match(/<suy>([\s\S]*?)<\/suy>/);
          const suyText = m ? m[1].trim() : '';
          const rest = s.replace(/<suy>[\s\S]*?<\/suy>/g, '').trim();
          return { suyText, rest };
        };
        let toolsUsed = 0;
        let nudges = 0;
        for (let step = 1; step <= 12; step++) {
          if (isCancelled(sid)) break;
          await persistProgress().catch(() => {});
          await writer.send({ type: 'phase', phase: 'agent', detail: `Bước ${step}: đang suy nghĩ...` });
          const completion = await zai.chat.completions.create({
            messages: agentMsgs,
            thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' },
          });
          const raw = String(completion?.choices?.[0]?.message?.content || '');
          // Suy nghĩ gốc của mô hình (reasoning_content) — xuất TRƯỚC câu trả lời như DeepSeek
          const nativeReasoning = String(
            (completion?.choices?.[0]?.message as { reasoning_content?: string } | undefined)?.reasoning_content || ''
          );
          if (nativeReasoning.trim()) {
            await writer.send({ type: 'thinking', delta: nativeReasoning + '\n' });
            assistantThinking += nativeReasoning + '\n';
          }
          const { suyText, rest } = stripSuy(raw);
          if (suyText) {
            await writer.send({ type: 'thinking', delta: suyText + '\n' });
            assistantThinking += suyText + '\n';
          }
          const { tool, textBefore } = extractToolCall(rest);
          if (!tool) {
            const finalText = (textBefore || rest).trim();
            // Model chưa gọi tool nào mà đã dừng lời (hoặc gọi sai format) → nhắc lại (tối đa 3 lần)
            const triedToolSyntax = /<(tool|write_file|run_terminal|read_file|list_files|generate_image|generate_video|image_search|web_search|read_url)/.test(rest);
            if (toolsUsed === 0 && nudges < 3 && step < 12 && (triedToolSyntax || finalText.length < 600)) {
              nudges++;
              await writer.send({ type: 'phase', phase: 'agent', detail: triedToolSyntax ? 'Đang sửa định dạng gọi tool...' : 'Agent chưa thực thi — đang yêu cầu gọi công cụ...' });
              agentMsgs.push({ role: 'assistant', content: raw });
              agentMsgs.push({
                role: 'user',
                content:
                  'Lời vừa rồi của bạn SAI FORMAT — tool không được thực thi. Hãy gọi lại tool NGAY trong lượt này, CHỈ MỘT dòng duy nhất theo đúng format JSON: <tool>{"name":"write_file","args":{"path":"ten-file.html","content":"nội dung đầy đủ"}}</tool>. Lưu ý: "content" là GIÁ TRỊ JSON chuỗi bình thường (escape " bên trong thành \\"), KHÔNG dùng thẻ XML, KHÔNG dùng content="...". Nếu nhiệm vụ thực sự không cần tool (câu hỏi kiến thức), hãy trả lời đầy đủ chi tiết ngay.',
              });
              continue;
            }
            const final = (() => {
              let t = (textBefore || rest).trim();
              // strip khối tool rác khỏi văn bản hiển thị
              const ti = t.indexOf('<tool>');
              if (ti >= 0) t = t.slice(0, ti).trim();
              t = t.replace(/<tool>[\s\S]*?<\/tool>/g, '').trim();
              return t || (triedToolSyntax
                ? 'Không thực thi được công cụ sau nhiều lần thử. Bạn hãy thử lại yêu cầu, hoặc yêu cầu tôi tạo file bằng một câu đơn giản hơn.'
                : 'Đã hoàn thành.');
            })();
            for (const chunk of chunkText(final)) {
              await writer.send({ type: 'content', delta: chunk });
              assistantContent += chunk;
            }
            break;
          }
          toolsUsed++;
          agentMsgs.push({ role: 'assistant', content: raw });
          await writer.send({ type: 'tool', name: tool.name, args: tool.args, step });
          const result = await executeTool(tool);
          const ev = { kind: 'tool', name: tool.name, args: tool.args, result: result.data, ok: result.ok, step };
          events.push(ev);
          await writer.send({ type: 'tool_result', ...ev });
          agentMsgs.push({
            role: 'user',
            content: `KẾT QUẢ TOOL (${tool.name}):\n${result.display.slice(0, 8000)}\n\nTiếp tục nhiệm vụ. Nếu đã hoàn tất, viết câu tổng kết (không kèm <tool>, không kèm <suy>).`,
          });
        }
      }
      // ============ GROUP AI — đội 8 agent: Sếp giao việc → chuyên gia làm → Kết quả tổng hợp ============
      else if (groupAI) {
        const boss = PERSONAS.find((p) => p.id === 'boss')!;
        const workers = PERSONAS.filter((p) => p.id !== 'boss' && p.id !== 'result');
        const resultAg = PERSONAS.find((p) => p.id === 'result')!;

        // lưu 1 dòng persona xuống DB (để chạy nền / tải lại vẫn hiện đúng)
        const savePersonaMsg = async (p: (typeof PERSONAS)[number], text: string, extraEvents: unknown[] = []) => {
          await db.message
            .create({
              data: {
                sessionId: sid,
                role: 'assistant',
                content: text,
                model: `persona:${p.id}`,
                events: JSON.stringify([
                  { kind: 'persona', id: p.id, name: p.name, role: p.role, color: p.color, icon: p.icon },
                  ...extraEvents,
                ]),
              },
            })
            .catch(() => {});
        };

        // phát 1 persona message hoàn chỉnh xuống client (stream chữ + đóng)
        const emitPersona = async (p: (typeof PERSONAS)[number], text: string, extraEvents: unknown[] = []) => {
          await writer.send({ type: 'persona', id: p.id, name: p.name, role: p.role, color: p.color, icon: p.icon });
          for (const chunk of chunkText(text)) await writer.send({ type: 'content', delta: chunk });
          await writer.send({ type: 'persona_done', id: p.id });
          await savePersonaMsg(p, text, extraEvents);
          assistantContent += (assistantContent ? '\n\n' : '') + `[${p.name}]: ${text}`;
        };

        // ---------- 1) SẾP phân tích & chọn đội ----------
        await writer.send({ type: 'phase', phase: 'group-plan', detail: 'Sếp đang phân tích & giao việc...' });
        let chosen: string[] = [];
        let planText = '';
        try {
          const pc = await zai.chat.completions.create({
            messages: [
              { role: 'assistant', content: buildBossPlanPrompt(workers) },
              ...history.slice(-4),
              { role: 'user', content: userText },
            ] as never,
            thinking: { type: 'disabled' },
          });
          const raw = String(pc?.choices?.[0]?.message?.content || '');
          const m = raw.match(/\{[\s\S]*\}/);
          if (m) {
            const parsed = JSON.parse(m[0].replace(/```json|```/g, ''));
            if (Array.isArray(parsed.agents)) {
              chosen = parsed.agents
                .map(String)
                .filter((id) => workers.some((w) => w.id === id))
                .slice(0, 4);
            }
            if (typeof parsed.plan === 'string') planText = parsed.plan.trim();
          }
        } catch {
          /* fallback chọn theo từ khoá bên dưới */
        }
        if (!chosen.length) {
          const t = userText.toLowerCase();
          const has = (...ws: string[]) => ws.some((w) => t.includes(w));
          if (has('code', 'lập trình', 'website', 'web', 'app', 'game', 'html', 'css', 'python', 'javascript', 'bug', 'lỗi', 'fix', 'chương trình', 'phần mềm', 'trang web')) {
            chosen = ['code', 'terminal', 'check', 'test'];
          } else if (has('slide', 'thuyết trình', 'powerpoint', 'present')) {
            chosen = ['slide'];
          } else if (has('kiểm tra', 'kiểm thử', 'test', 'chạy thử', 'soát')) {
            chosen = ['check', 'test'];
          } else {
            chosen = ['agent'];
          }
        }
        const chosenNames = chosen
          .map((id) => workers.find((w) => w.id === id)?.name)
          .filter(Boolean)
          .join(', ');
        if (!planText) planText = `Đã rõ yêu cầu! Tôi giao việc cho: ${chosenNames}. Mời các chuyên gia bắt đầu.`;
        if (!isCancelled(sid)) await emitPersona(boss, planText);

        // ---------- 2) TỪNG CHUYÊN GIA làm việc ----------
        for (const id of chosen) {
          if (isCancelled(sid)) break;
          const p = workers.find((w) => w.id === id)!;
          await writer.send({ type: 'phase', phase: `agent-${p.id}`, detail: `${p.name} đang làm việc...` });
          const prevContext = assistantContent
            ? `\n\n[Diễn biến của team đến giờ (không lặp lại phần này, chỉ làm phần của bạn):\n${assistantContent.slice(-2600)}]`
            : '';
          const baseMsgs = [
            { role: 'assistant', content: buildWorkerPrompt(p.name, p.role, p.desc, !!p.tools) },
            ...history,
            { role: 'user', content: userText + prevContext },
          ];
          let text = '';
          const personaEvents: unknown[] = [];
          try {
            if (p.tools) {
              // chuyên gia thao tác máy: vòng 1 cho phép gọi 1 tool
              const c1 = await zai.chat.completions.create({
                messages: baseMsgs as never,
                thinking: { type: 'disabled' },
              });
              const raw1 = String(c1?.choices?.[0]?.message?.content || '').trim();
              const tool = extractToolCall(raw1).tool;
              await writer.send({ type: 'persona', id: p.id, name: p.name, role: p.role, color: p.color, icon: p.icon });
              const cleanLead = raw1.replace(/<tool>[\s\S]*?(<\/tool>|$)/g, '').replace(/<suy>[\s\S]*?(<\/suy>|$)/g, '').trim();
              if (cleanLead) for (const chunk of chunkText(cleanLead)) await writer.send({ type: 'content', delta: chunk });
              if (tool && !isCancelled(sid)) {
                await writer.send({ type: 'tool', name: tool.name, args: tool.args, step: 1 });
                const result = await executeTool(tool);
                const ev = { kind: 'tool', name: tool.name, args: tool.args, result: result.data, ok: result.ok, step: 1 };
                personaEvents.push(ev);
                events.push(ev);
                await writer.send({ type: 'tool_result', ...ev });
                if (['write_file', 'run_terminal', 'generate_image'].includes(tool.name)) {
                  /* client sẽ tự bump cây file qua tool_result */
                }
                // vòng 2: tổng kết sau khi tool đã chạy (cho phép thêm 1 tool nữa nếu thật sự cần)
                const msgs2 = [
                  ...baseMsgs,
                  { role: 'assistant', content: raw1 },
                  {
                    role: 'user',
                    content: `KẾT QUẢ TOOL (${tool.name}):
${result.display.slice(0, 6000)}

Hãy trình bày phần việc của bạn (Markdown ngắn gọn). Chỉ gọi thêm tool nếu BẮT BUỘC — khi đó xuất đúng một dòng <tool>JSON</tool> và dừng.`,
                  },
                ];
                const streamBody = await zai.chat.completions.create({
                  messages: msgs2 as never,
                  stream: true,
                  thinking: { type: 'disabled' },
                });
                const res2 = await streamToClient(streamBody, writer, {
                  collect: (c) => { text += c; },
                  stop: () => isCancelled(sid),
                });
                if (res2.tool && !isCancelled(sid)) {
                  await writer.send({ type: 'tool', name: res2.tool.name, args: res2.tool.args, step: 2 });
                  const r2 = await executeTool(res2.tool);
                  const ev2 = { kind: 'tool', name: res2.tool.name, args: res2.tool.args, result: r2.data, ok: r2.ok, step: 2 };
                  personaEvents.push(ev2);
                  events.push(ev2);
                  await writer.send({ type: 'tool_result', ...ev2 });
                }
              } else {
                text = cleanLead;
              }
            } else {
              // chuyên gia nội dung: stream thẳng
              await writer.send({ type: 'persona', id: p.id, name: p.name, role: p.role, color: p.color, icon: p.icon });
              const streamBody = await zai.chat.completions.create({
                messages: baseMsgs as never,
                stream: true,
                thinking: { type: 'disabled' },
              });
              await streamToClient(streamBody, writer, {
                collect: (c) => { text += c; },
                stop: () => isCancelled(sid),
              });
            }
          } catch {
            if (!text) text = 'Xin lỗi, tôi gặp sự cố kỹ thuật khi xử lý phần việc này.';
          }
          await writer.send({ type: 'persona_done', id: p.id });
          if (text) {
            await savePersonaMsg(p, text, personaEvents);
            assistantContent += (assistantContent ? '\n\n' : '') + `[${p.name}]: ${text}`;
          }
        }

        // ---------- 3) KẾT QUẢ tổng hợp cuối ----------
        if (!isCancelled(sid)) {
          await writer.send({ type: 'phase', phase: 'group-result', detail: 'Kết quả đang tổng hợp...' });
          let sumText = '';
          await writer.send({ type: 'persona', id: resultAg.id, name: resultAg.name, role: resultAg.role, color: resultAg.color, icon: resultAg.icon });
          try {
            const streamBody = await zai.chat.completions.create({
              messages: [
                { role: 'assistant', content: buildWorkerPrompt(resultAg.name, resultAg.role, resultAg.desc, false) },
                {
                  role: 'user',
                  content: `Nhiệm vụ gốc của người dùng: ${userText}

Toàn bộ làm việc của đội:
${assistantContent.slice(0, 9000)}

Viết phần TỔNG KẾT KẾT QUẢ cuối cùng: những điều quan trọng nhất cần biết, sản phẩm đã tạo (file/ảnh/nếu có), và bước tiếp theo đề xuất. Có cấu trúc, ngắn gọn.`,
                },
              ] as never,
              stream: true,
              thinking: { type: 'disabled' },
            });
            await streamToClient(streamBody, writer, {
              collect: (c) => { sumText += c; },
              stop: () => isCancelled(sid),
            });
          } catch {
            sumText = 'Đội đã hoàn thành nhiệm vụ. Bạn có thể xem các phần việc ở trên.';
          }
          await writer.send({ type: 'persona_done', id: resultAg.id });
          await savePersonaMsg(resultAg, sumText, []);
          assistantContent += (assistantContent ? '\n\n' : '') + `[${resultAg.name}]: ${sumText}`;
        }
      }
      // ============ RESEARCH / ULTRA ============
      else if (mode === 'research' || mode === 'ultra') {
        const isUltra = mode === 'ultra';
        await writer.send({ type: 'phase', phase: 'queries', detail: 'Đang tạo truy vấn tìm kiếm...' });
        let queries: string[] = [userText.slice(0, 200)];
        try {
          const q = await zai.chat.completions.create({
            messages: [
              { role: 'assistant', content: 'Bạn tạo truy vấn tìm kiếm. Trả về MỘT mảng JSON các chuỗi, không giải thích.' },
              { role: 'user', content: `Câu hỏi: ${userText}\nTạo ${isUltra ? 4 : 3} truy vấn tìm kiếm tiếng Việt đa góc độ. Chỉ trả JSON mảng.` },
            ],
            thinking: { type: 'disabled' },
          });
          const parsed = JSON.parse(String(q?.choices?.[0]?.message?.content || '[]').replace(/```json|```/g, '').trim());
          if (Array.isArray(parsed) && parsed.length) queries = parsed.map(String).slice(0, isUltra ? 4 : 3);
        } catch { /* giữ fallback */ }

        await writer.send({ type: 'phase', phase: 'searching', detail: `Đang tìm kiếm ${queries.length} truy vấn...` });
        const searchResults = await Promise.all(queries.map((q) => webSearch(q, 6).catch(() => [])));
        const seen = new Set<string>();
        const sources: { url: string; name: string; snippet: string }[] = [];
        for (const list of searchResults) {
          for (const s of list) {
            if (seen.has(s.url)) continue;
            seen.add(s.url);
            sources.push(s);
          }
        }
        const topSources = sources.slice(0, isUltra ? 10 : 6);
        const ev = { kind: 'sources', sources: topSources };
        events.push(ev);
        await writer.send({ type: 'sources', sources: topSources });

        await writer.send({ type: 'phase', phase: 'reading', detail: `Đang đọc ${Math.min(topSources.length, isUltra ? 5 : 3)} trang...` });
        const pages = await Promise.all(
          topSources.slice(0, isUltra ? 5 : 3).map((s) =>
            Promise.race([
              pageReader(s.url),
              new Promise<{ title: string; text: string; url: string }>((res) =>
                setTimeout(() => res({ title: s.name, text: '', url: s.url }), 25000)
              ),
            ]).catch(() => ({ title: s.name, text: '', url: s.url }))
          )
        );
        const sourceText = pages
          .map((p, i) => `[${i + 1}] ${p.title} (${p.url})\n${p.text.slice(0, isUltra ? 6000 : 4000)}`)
          .join('\n\n');

        await writer.send({ type: 'phase', phase: 'synthesizing', detail: 'Đang tổng hợp báo cáo...' });
        const sys = buildSystemPrompt({ model, mode: 'normal', topic, think, speed, enabledSkills, customSkills });
        const msgs = [
          { role: 'assistant', content: sys },
          ...history,
          {
            role: 'user',
            content: `${userText}\n\nNGUỒN TÌM ĐƯỢC (đánh số):\n${sourceText}\n\nHãy viết báo cáo tổng hợp chi tiết, trích dẫn nguồn dạng [1], [2]...${isUltra ? ' Có mục "Đối chiếu & kiểm chứng" so sánh các nguồn.' : ''}`,
          },
        ];
        const streamBody = await zai.chat.completions.create({
          messages: msgs as never,
          stream: true,
          thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' },
        });
        const res = await streamToClient(streamBody, writer, { collect: (c, t) => { assistantContent += c; assistantThinking += t; }, stop: () => isCancelled(sid) });
        if (res.tool && !isCancelled(sid)) {
          await runToolRounds(
            writer,
            (m) => zai.chat.completions.create({ messages: m as never, stream: true, thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' } }),
            { tool: res.tool, rawAll: res.rawAll },
            msgs,
            {
              collect: (c, t) => { assistantContent += c; assistantThinking += t; },
              stop: () => isCancelled(sid),
              onEvent: async (ev) => { events.push(ev); await writer.send({ type: 'tool_result', ...ev }); },
            }
          );
        }
      }
      // ============ NORMAL / BEST / THINK ============
      else {
        if (mediaAtts.length > 0) {
          // Vision — gửi kèm ảnh/video/tệp
          const visionContent: Record<string, unknown>[] = [
            {
              type: 'text',
              text: `${fullSystemPrompt}\n\n---\nLỊCH SỬ HỘI THOẠI GẦN NHẤT:\n${history.slice(-6).map((h) => `${h.role === 'user' ? 'Người dùng' : 'AI'}: ${h.content.slice(0, 800)}`).join('\n')}\n---\nTIN NHẮN MỚI: ${userText}`,
            },
          ];
          for (const a of mediaAtts) {
            const dataUrl = readUploadDataUrl(a.url);
            if (!dataUrl) continue;
            if (a.type === 'image') visionContent.push({ type: 'image_url', image_url: { url: dataUrl } });
            else if (a.type === 'video') visionContent.push({ type: 'video_url', video_url: { url: dataUrl } });
            else visionContent.push({ type: 'file_url', file_url: { url: dataUrl } });
          }
          const visionBody = await zai.chat.completions.createVision({
            model: VISION_MODEL,
            messages: [{ role: 'user', content: visionContent }] as never,
            stream: true,
            thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' },
          });
          const res = await streamToClient(visionBody, writer, { collect: (c, t) => { assistantContent += c; assistantThinking += t; }, stop: () => isCancelled(sid) });
          if (res.tool && !isCancelled(sid)) {
            // vòng phản hồi tool: baseMsgs dạng text (vision không phát lại được ảnh đính kèm)
            const vMsgs = [
              { role: 'assistant', content: fullSystemPrompt },
              ...history,
              {
                role: 'user',
                content: userText + (mediaAtts.length ? `\n\n(Kèm tệp đính kèm: ${mediaAtts.map((a) => a.name).join(', ')})` : ''),
              },
            ];
            await runToolRounds(
              writer,
              (m) => zai.chat.completions.create({ messages: m as never, stream: true, thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' } }),
              { tool: res.tool, rawAll: res.rawAll },
              vMsgs,
              {
                collect: (c, t) => { assistantContent += c; assistantThinking += t; },
                stop: () => isCancelled(sid),
                onEvent: async (ev) => { events.push(ev); await writer.send({ type: 'tool_result', ...ev }); },
              }
            );
          }
        } else {
          const msgs = [
            { role: 'assistant', content: fullSystemPrompt },
            ...history,
            { role: 'user', content: userText },
          ];
          if (mode === 'best') {
            // BEST: bản nháp âm thầm → phản biện → bản cuối
            await writer.send({ type: 'phase', phase: 'draft', detail: 'Đang viết bản nháp...' });
            const draftCompletion = await zai.chat.completions.create({
              messages: msgs as never,
              thinking: { type: 'disabled' },
            });
            const draft = String(draftCompletion?.choices?.[0]?.message?.content || '');
            await writer.send({ type: 'phase', phase: 'reflecting', detail: 'Đang tự phản biện lại lập luận...' });
            const critique = await zai.chat.completions.create({
              messages: [
                { role: 'assistant', content: 'Bạn là người phản biện khắt khe của Shark. Nhiệm vụ: đọc bản nháp, tìm lỗi sai, chỗ chưa rõ, thiếu sót, rồi xuất PHIÊN BẢN HOÀN THIỆN CUỐI CÙNG (viết lại toàn bộ, giữ format Markdown, tiếng Việt). Không giải thích quá trình, chỉ xuất bản cuối.' },
                { role: 'user', content: `Câu hỏi gốc: ${userText}\n\nBẢN NHÁP:\n${draft}` },
              ] as never,
              thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' },
            });
            const critText = String(critique?.choices?.[0]?.message?.content || '');
            if (critText.trim()) {
              const rev = { kind: 'reflection', text: critText };
              events.push(rev);
              await writer.send({ type: 'reflection', text: critText });
            }
            for (const chunk of chunkText(critText || draft)) {
              await writer.send({ type: 'content', delta: chunk });
              assistantContent += chunk;
            }
          } else {
            const streamBody = await zai.chat.completions.create({
              messages: msgs as never,
              stream: true,
              thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' },
            });
            const res = await streamToClient(streamBody, writer, { collect: (c, t) => { assistantContent += c; assistantThinking += t; }, stop: () => isCancelled(sid) });
            if (res.tool && !isCancelled(sid)) {
              await runToolRounds(
                writer,
                (m) => zai.chat.completions.create({ messages: m as never, stream: true, thinking: { type: thinkingEnabled ? 'enabled' : 'disabled' } }),
                { tool: res.tool, rawAll: res.rawAll },
                msgs,
                {
                  collect: (c, t) => { assistantContent += c; assistantThinking += t; },
                  stop: () => isCancelled(sid),
                  onEvent: async (ev) => { events.push(ev); await writer.send({ type: 'tool_result', ...ev }); },
                }
              );
            }
          }
        }
      }

      // ---------- Hoàn tất: cập nhật dòng assistant ----------
      const stopped = isCancelled(sid);
      clearCancel(sid);
      if (isGemini) {
        // Gemini: GIỮ dòng assistant 'running' — client stream trực tiếp từ Google,
        // xong sẽ PATCH content/thinking/status về /api/messages/<id>
      } else if (!groupAI && assistantRowId) {
        await db.message
          .update({
            where: { id: assistantRowId },
            data: {
              content: assistantContent,
              thinking: assistantThinking || null,
              model,
              events: JSON.stringify(events),
              status: stopped ? 'stopped' : 'done',
            },
          })
          .catch(() => {});
      } else if (assistantRowId) {
        // Group AI: nội dung nằm ở từng dòng persona — bỏ dòng chạy nền trống
        await db.message.delete({ where: { id: assistantRowId } }).catch(() => {});
      }

      // ---------- Tiêu đề ----------
      const session = await db.chatSession.findUnique({ where: { id: sid } });
      if (session && (session.title === 'Phiên chat mới' || isNewSession)) {
        if (isGemini) {
          // Gemini chạy client-side — server chưa có nội dung trả lời: tiêu đề tạm từ tin nhắn
          const title = userText.slice(0, 40) || 'Phiên chat mới';
          await db.chatSession.update({ where: { id: sid }, data: { title } }).catch(() => {});
          await writer.send({ type: 'title', title });
        } else {
          try {
            const t = await zai.chat.completions.create({
              messages: [
                { role: 'assistant', content: 'Tạo tiêu đề ngắn gọn (tối đa 6 từ, tiếng Việt, không dấu ngoặc kép) cho hội thoại. Chỉ trả tiêu đề.' },
                { role: 'user', content: `Người dùng: ${userText.slice(0, 300)}\nAI: ${assistantContent.slice(0, 300)}` },
              ],
              thinking: { type: 'disabled' },
            });
            const title = String(t?.choices?.[0]?.message?.content || '').replace(/["\n]/g, '').trim().slice(0, 60) || userText.slice(0, 40);
            await db.chatSession.update({ where: { id: sid }, data: { title } });
            await writer.send({ type: 'title', title });
          } catch {
            const title = userText.slice(0, 40) || 'Phiên chat mới';
            await db.chatSession.update({ where: { id: sid }, data: { title } }).catch(() => {});
            await writer.send({ type: 'title', title });
          }
        }
      }

      await writer.send({ type: 'done' });
    } catch (e) {
      console.error('chat error:', e);
      await writer.send({ type: 'error', message: e instanceof Error ? e.message : 'Lỗi không xác định' });
      clearCancel(sid);
      if (!groupAI && assistantRowId) {
        await db.message
          .update({
            where: { id: assistantRowId },
            data: {
              content: assistantContent || '_(lỗi giữa chừng)_',
              thinking: assistantThinking || null,
              model,
              events: JSON.stringify(events),
              status: 'error',
            },
          })
          .catch(() => {});
      }
      await writer.send({ type: 'done' });
    } finally {
      if (progressTimer) clearInterval(progressTimer);
      writer.close();
    }
  };

  run().catch(() => {});
  return new Response(stream, { headers: sseHeaders() });
}

// ---------- helpers ----------

function chunkText(text: string, size = 48): string[] {
  if (!text) return [];
  const chunks: string[] = [];
  for (let i = 0; i < text.length; i += size) chunks.push(text.slice(i, i + size));
  return chunks;
}

interface StreamResult {
  fullText: string;
  fullThinking: string;
  rawAll: string;
  tool: { name: string; args: Record<string, unknown> } | null;
}

// Stream LLM → đẩy content/thinking events cho client
// State machine xử lý: <think>...</think> (suy nghĩ) và <tool>...</tool> (tool call)
async function streamToClient(
  body: ReadableStream<Uint8Array> | null,
  writer: SSEWriter,
  opts: { collect: (content: string, thinking: string) => void; stop?: () => boolean }
): Promise<StreamResult> {
  const OPEN_T = '<suy>';
  const CLOSE_T = '</suy>';
  const OPEN_TOOL = '<tool>';
  const CLOSE_TOOL = '</tool>';
  const MAX_HOLD = Math.max(OPEN_T.length, CLOSE_T.length, OPEN_TOOL.length) - 1;

  let buf = '';
  let fullText = ''; // text hiển thị (đã lọc bỏ khối <tool> JSON)
  let rawAll = ''; // TOÀN BỘ raw model output (kể cả <tool> JSON) — nguồn cho extractToolCall
  let fullThinking = '';
  let inThink = false;
  let inTool = false;

  const safePrefixLength = (s: string, tags: string[]): number => {
    for (let i = s.length - 1; i >= Math.max(0, s.length - MAX_HOLD); i--) {
      const tail = s.slice(i);
      if (tags.some((t) => t.startsWith(tail))) return i;
    }
    return s.length;
  };

  const processBuffer = async (flush: boolean) => {
    while (buf.length > 0) {
      // đang nằm trong khối <tool>...</tool> — ẩn JSON khỏi hiển thị
      // (rawAll vẫn giữ nguyên để extractToolCall đọc được tool call)
      if (inTool) {
        const closeIdx = buf.indexOf(CLOSE_TOOL);
        if (closeIdx >= 0) {
          // hết khối tool — text sau </tool> hiển thị bình thường trở lại
          buf = buf.slice(closeIdx + CLOSE_TOOL.length);
          inTool = false;
          continue;
        }
        // chưa thấy </tool>: giữ nguyên trong buf chờ tag đóng
        // (flush mà vẫn chưa đóng → tool JSON dở, vứt phần hiển thị)
        if (flush) buf = '';
        return;
      }
      if (inThink) {
        const closeIdx = buf.indexOf(CLOSE_T);
        if (closeIdx >= 0) {
          const seg = buf.slice(0, closeIdx);
          if (seg) {
            fullThinking += seg;
            await writer.send({ type: 'thinking', delta: seg });
          }
          buf = buf.slice(closeIdx + CLOSE_T.length);
          inThink = false;
          continue;
        }
        if (flush) {
          fullThinking += buf;
          await writer.send({ type: 'thinking', delta: buf });
          buf = '';
        } else {
          const safe = safePrefixLength(buf, [CLOSE_T]);
          if (safe > 0) {
            const seg = buf.slice(0, safe);
            fullThinking += seg;
            await writer.send({ type: 'thinking', delta: seg });
            buf = buf.slice(safe);
          }
          return;
        }
        continue;
      }
      // ngoài think: tìm <tool> và <suy>
      const gi = buf.indexOf(OPEN_TOOL);
      const ti = buf.indexOf(OPEN_T);
      if (gi >= 0 && (ti < 0 || gi < ti)) {
        const seg = buf.slice(0, gi);
        if (seg) {
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
        }
        buf = buf.slice(gi + OPEN_TOOL.length);
        inTool = true;
        continue;
      }
      if (ti >= 0) {
        const seg = buf.slice(0, ti);
        if (seg) {
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
        }
        buf = buf.slice(ti + OPEN_T.length);
        inThink = true;
        continue;
      }
      if (flush) {
        fullText += buf;
        await writer.send({ type: 'content', delta: buf });
        buf = '';
      } else {
        const safe = safePrefixLength(buf, [OPEN_T, OPEN_TOOL]);
        if (safe > 0) {
          const seg = buf.slice(0, safe);
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
          buf = buf.slice(safe);
        }
        return;
      }
    }
  };

  for await (const delta of parseSDKStream(body)) {
    // Tiếp tục đọc stream kể cả khi client ngắt kết nối (chạy nền),
    // nhưng dừng ngay nếu người dùng chủ động huỷ
    if (opts.stop?.()) break;
    // Suy nghĩ gốc (reasoning_content) — đẩy xuống client NGAY, xuất hiện TRƯỚC câu trả lời (kiểu DeepSeek)
    if (delta.thinking) {
      fullThinking += delta.thinking;
      await writer.send({ type: 'thinking', delta: delta.thinking });
    }
    rawAll += delta.content; // bản gốc chưa lọc — tool call sống ở đây
    buf += delta.content;
    await processBuffer(false);
  }
  await processBuffer(true);
  opts.collect(fullText, fullThinking);

  // FIX QUAN TRỌNG: extractToolCall phải chạy trên BẢN GỐC đầy đủ (rawAll)
  // — trước đây chạy trên fullText (đã lọc bỏ <tool> JSON) nên tool không bao giờ
  // được tìm thấy → tạo ảnh / tạo video qua chat luôn thất bại.
  const { tool } = extractToolCall(rawAll);
  return { fullText, fullThinking, rawAll, tool: tool ?? null };
}

// ---------- Vòng phản hồi tool cho chế độ thường / vision / research ----------
// Trước đây tool chạy 1 lần rồi kết thúc — dẫn đến 2 lỗi:
//   1) generate_video thiếu prompt → API 400, model không có cơ hội gọi lại
//   2) web_search / read_url chạy xong model KHÔNG thấy kết quả → "không biết gì"
// Giờ: kết quả tool được đẩy về model để tổng hợp câu trả lời; tool lỗi thiếu
// tham số → model được nhắc gọi lại đúng format. Tối đa `maxRounds` vòng tool.
const TOOL_FEEDBACK = new Set(['web_search', 'read_url', 'read_file', 'run_terminal', 'list_files']);

async function runToolRounds(
  writer: SSEWriter,
  makeStream: (msgs: unknown[]) => Promise<unknown>,
  first: { tool: { name: string; args: Record<string, unknown> }; rawAll: string },
  baseMsgs: unknown[],
  hooks: {
    collect: (c: string, t: string) => void;
    stop: () => boolean;
    onEvent: (ev: { kind: 'tool'; name: string; args: Record<string, unknown>; result: unknown; ok: boolean }) => Promise<void>;
  },
  maxRounds = 3
): Promise<void> {
  let msgs: unknown[] = [...baseMsgs, { role: 'assistant', content: first.rawAll }];
  let tool = first.tool;
  for (let round = 1; round <= maxRounds && tool && !hooks.stop(); round++) {
    const r = await executeTool(tool);
    await hooks.onEvent({ kind: 'tool', name: tool.name, args: tool.args, result: r.data, ok: r.ok });
    // chỉ cần vòng tiếp nếu: tool lỗi (model phải sửa) HOẶC tool trả dữ liệu model cần tổng hợp
    const needsMore = !r.ok || TOOL_FEEDBACK.has(normalizeToolName(tool.name));
    if (!needsMore) break;
    const isLast = round >= maxRounds;
    const feedback = r.ok
      ? `KẾT QUẢ TOOL (${tool.name}):\n${r.display.slice(0, 9000)}\n\n${isLast
          ? 'Dựa vào kết quả trên, viết NGAY câu trả lời trọn vẹn cho người dùng (Markdown, tiếng Việt, trích nguồn dạng [1] khi dùng link). KHÔNG gọi tool thêm.'
          : 'Hãy dùng kết quả trên để làm tiếp yêu cầu. Nếu CẦN thêm thông tin, gọi MỘT tool theo format <tool>{"name":"...","args":{...}}</tool> rồi dừng; nếu đủ thông tin, viết câu trả lời trọn vẹn.'}`
      : `LỆNH GỌI TOOL (${tool.name}) KHÔNG THỰC THI ĐƯỢC:\n${r.display.slice(0, 2000)}\n\n${isLast
          ? 'Không gọi tool được nữa — hãy trả lời người dùng với thông tin sẵn có và nói rõ thao tác nào chưa làm được.'
          : 'Gọi lại tool NGAY theo đúng hướng dẫn trên (một dòng <tool>JSON</tool> với ĐỦ tham số) rồi dừng.'}`;
    msgs = [...msgs, { role: 'user', content: feedback }];
    // ngăn cách câu trả lời mới với phần text đã stream trước đó
    await writer.send({ type: 'content', delta: '\n\n' });
    hooks.collect('\n\n', '');
    const body = (await makeStream(msgs)) as ReadableStream<Uint8Array> | null;
    const res = await streamToClient(body, writer, { collect: hooks.collect, stop: hooks.stop });
    if (!res.tool) break;
    msgs = [...msgs, { role: 'assistant', content: res.rawAll }];
    tool = res.tool;
  }
}

