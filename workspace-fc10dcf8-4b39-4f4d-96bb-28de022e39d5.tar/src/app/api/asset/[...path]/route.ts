import { NextRequest, NextResponse } from 'next/server';
import { UPLOAD_ROOT, mimeOf, safeResolve } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

// GET /api/asset/<file> — phục vụ file từ thư mục upload (ảnh đã tạo, tệp đính kèm)
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  const { path: segments } = await params;
  const rel = (segments || []).join('/');
  const abs = safeResolve(UPLOAD_ROOT, rel);
  if (!abs || !fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
    return new NextResponse('Không tìm thấy tệp', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  const buffer = fs.readFileSync(abs);
  const download = _req.nextUrl.searchParams.get('download') === '1';
  const headers: Record<string, string> = {
    'Content-Type': mimeOf(abs),
    'Cache-Control': 'public, max-age=31536000, immutable',
  };
  if (download) {
    headers['Content-Disposition'] = `attachment; filename="${encodeURIComponent(path.basename(abs))}"`;
  }
  return new NextResponse(new Uint8Array(buffer), { status: 200, headers });
}
