import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { getSessionUser } from '@/lib/auth';

// ============================================================
// Quản lý API key (giống Gemini / Groq / OpenAI console)
//  GET    /api/keys        → danh sách key (đã che bớt)
//  POST   /api/keys        → tạo key mới "sk-shark-free..."
//  DELETE /api/keys?id=... → thu hồi / xoá key
//  Yêu cầu: đã đăng nhập (phiên cookie)
// ============================================================

const KEY_PREFIX = 'sk-shark-free';

/** Sinh key dạng: sk-shark-free + 8 số + 4 chữ in hoa (vd: sk-shark-free99297290FJKX) */
function generateApiKey(): string {
  let digits = '';
  for (let i = 0; i < 8; i++) digits += crypto.randomInt(0, 10);
  let letters = '';
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // bỏ I/O dễ nhầm
  for (let i = 0; i < 4; i++) letters += A[crypto.randomInt(0, A.length)];
  return `${KEY_PREFIX}${digits}${letters}`;
}

/** Che key khi hiển thị: sk-shark-free9929•••••FJ */
function maskKey(key: string): string {
  if (key.length <= 16) return key.slice(0, 8) + '••••';
  return key.slice(0, 14) + '•••••' + key.slice(-2);
}

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

export async function GET(req: NextRequest) {
  const user = await getSessionUser(req);
  if (!user) return jsonError('Cần đăng nhập để quản lý API key', 401);
  const keys = await db.apiKey.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json(
    keys.map((k) => ({
      id: k.id,
      name: k.name,
      masked: maskKey(k.key),
      calls: k.calls,
      lastUsedAt: k.lastUsedAt,
      revoked: k.revoked,
      createdAt: k.createdAt,
    }))
  );
}

export async function POST(req: NextRequest) {
  const user = await getSessionUser(req);
  if (!user) return jsonError('Cần đăng nhập để tạo API key', 401);

  const body = (await req.json().catch(() => ({}))) as { name?: string };
  const name = (body.name || '').toString().trim().slice(0, 60) || 'API key của tôi';

  // giới hạn 20 key / tài khoản
  const count = await db.apiKey.count({ where: { userId: user.id } });
  if (count >= 20) return jsonError('Bạn đã có 20 API key — xoá bớt trước khi tạo mới', 400);

  const key = generateApiKey();
  const row = await db.apiKey.create({
    data: { name, key, userId: user.id },
  });

  // trả key ĐẦY ĐỦ đúng 1 lần duy nhất (như OpenAI/Gemini)
  return NextResponse.json({
    id: row.id,
    name: row.name,
    key, // chỉ hiện lần này — sau đó chỉ còn bản che
    createdAt: row.createdAt,
  });
}

export async function DELETE(req: NextRequest) {
  const user = await getSessionUser(req);
  if (!user) return jsonError('Cần đăng nhập', 401);
  const id = new URL(req.url).searchParams.get('id');
  if (!id) return jsonError('Thiếu id', 400);

  // chỉ xoá được key thuộc về user (hoặc key ẩn danh gắn id này)
  const row = await db.apiKey.findUnique({ where: { id } });
  if (!row || (row.userId && row.userId !== user.id)) return jsonError('Không tìm thấy key', 404);

  await db.apiKey.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
