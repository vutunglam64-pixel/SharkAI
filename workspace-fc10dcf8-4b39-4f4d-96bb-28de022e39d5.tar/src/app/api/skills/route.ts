import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';

export const maxDuration = 30;

// GET — danh sách skill tùy chỉnh
export async function GET() {
  const skills = await db.userSkill.findMany({ orderBy: { createdAt: 'desc' } });
  return NextResponse.json(skills);
}

// POST — tạo skill mới {name, desc, prompt}
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const name = String(body.name || '').trim().slice(0, 60);
  const desc = String(body.desc || '').trim().slice(0, 200);
  const prompt = String(body.prompt || '').trim().slice(0, 4000);
  if (!name) return NextResponse.json({ error: 'Thiếu tên skill' }, { status: 400 });
  if (!prompt) return NextResponse.json({ error: 'Thiếu hướng dẫn cho skill' }, { status: 400 });
  const skill = await db.userSkill.create({ data: { name, desc, prompt } });
  return NextResponse.json(skill);
}

// DELETE ?id= — xoá skill
export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get('id');
  if (!id) return NextResponse.json({ error: 'Thiếu id' }, { status: 400 });
  try {
    await db.userSkill.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: 'Không tìm thấy skill' }, { status: 404 });
  }
}
