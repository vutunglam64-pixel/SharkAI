import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';

export async function GET() {
  const projects = await db.project.findMany({
    orderBy: { updatedAt: 'desc' },
    include: { _count: { select: { sessions: true } } },
  });
  return NextResponse.json(projects);
}

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const project = await db.project.create({
    data: { name: body.name || 'Dự án mới', goal: body.goal || '' },
  });
  return NextResponse.json(project);
}
