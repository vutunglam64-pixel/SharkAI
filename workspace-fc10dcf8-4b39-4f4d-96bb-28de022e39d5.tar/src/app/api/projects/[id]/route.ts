import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const project = await db.project.findUnique({
    where: { id },
    include: { sessions: { orderBy: { updatedAt: 'desc' } } },
  });
  if (!project) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 });
  return NextResponse.json(project);
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await jsonBody(req);
  const project = await db.project.update({
    where: { id },
    data: { name: body.name, goal: body.goal },
  });
  return NextResponse.json(project);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await db.project.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
