import { NextResponse } from 'next/server';
import { getSecret } from '@/lib/secrets';

/**
 * Phát khoá Google Gemini cho CLIENT (chỉ dùng để browser gọi trực tiếp Google).
 *
 * Vì sao client-side: server này nằm ở khu vực bị Google chặn geo
 * ("User location is not supported") với generativelanguage.googleapis.com,
 * còn browser người dùng (Việt Nam) thì ở vùng được hỗ trợ → browser tự gọi
 * streamGenerateContent rồi PATCH kết quả về /api/messages/<id>.
 *
 * Key đọc từ db/secrets.json (bền vững qua sandbox recycle — .env bị
 * gitignore nên bị reset mỗi lần restart); env GEMINI_API_KEY vẫn ưu tiên nếu có.
 *
 * KHUYẾN NGHỊ bảo mật: chủ app nên giới hạn (restrict) key này theo origin
 * của app trong Google AI Studio (Application restrictions → HTTP referrers).
 */
export function GET() {
  const key = getSecret('GEMINI_API_KEY');
  if (!key) {
    return NextResponse.json(
      { ok: false, error: 'Máy chủ chưa cấu hình GEMINI_API_KEY' },
      { status: 500 }
    );
  }
  return NextResponse.json({ ok: true, key, defaultModel: 'gemini-3.8-flash' });
}
