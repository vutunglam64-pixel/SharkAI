import { NextRequest, NextResponse } from 'next/server';
import { ensureWorkspace, buildTree, safeResolve, WORKSPACE_ROOT } from '@/lib/workspace';
import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';

export const maxDuration = 60;

// GET /api/zip?paths=a.html,style.css  → zip toàn bộ hoặc các file chỉ định
export async function GET(req: NextRequest) {
  ensureWorkspace();
  const zip = new JSZip();
  const pathsParam = req.nextUrl.searchParams.get('paths');

  const addFile = (rel: string, abs: string) => {
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      zip.file(rel, fs.readFileSync(abs));
    }
  };

  if (pathsParam) {
    const paths = pathsParam.split(',').map((p) => p.trim()).filter(Boolean);
    for (const p of paths) {
      const abs = safeResolve(WORKSPACE_ROOT, p);
      if (abs) addFile(p, abs);
    }
  } else {
    const walk = (rel: string, abs: string) => {
      const items = fs.readdirSync(abs, { withFileTypes: true });
      for (const item of items) {
        if (item.name.startsWith('.') || item.name === 'node_modules') continue;
        const r = rel ? `${rel}/${item.name}` : item.name;
        const a = path.join(abs, item.name);
        if (item.isDirectory()) walk(r, a);
        else addFile(r, a);
      }
    };
    walk('', WORKSPACE_ROOT);
  }

  const buffer = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  const name = `shark-du-an-${Date.now()}.zip`;
  return new NextResponse(new Uint8Array(buffer), {
    status: 200,
    headers: {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${name}"`,
    },
  });
}
