import { NextRequest, NextResponse } from 'next/server';
import { runTerminal } from '@/lib/tools';
import { jsonBody } from '@/lib/sse';

export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const command = String(body.command || '').trim();
  if (!command) return NextResponse.json({ error: 'Thiếu lệnh' }, { status: 400 });
  const r = await runTerminal(command, 30000);
  return NextResponse.json(r);
}
