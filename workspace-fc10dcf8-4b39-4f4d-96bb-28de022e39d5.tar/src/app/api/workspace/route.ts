import { NextRequest, NextResponse } from 'next/server';
import { jsonBody } from '@/lib/sse';
import { buildTree, ensureWorkspace, safeResolve, WORKSPACE_ROOT, isTextFile } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

export const maxDuration = 30;

export async function GET() {
  ensureWorkspace();
  const tree = buildTree(WORKSPACE_ROOT, '');
  return NextResponse.json({ tree, root: 'workspace' });
}

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const action = String(body.action || '');
  ensureWorkspace();

  const resolveSafe = (p: string) => safeResolve(WORKSPACE_ROOT, p);

  try {
    if (action === 'read') {
      const abs = resolveSafe(String(body.path || ''));
      if (!abs || !fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
        return NextResponse.json({ error: 'Không tìm thấy tệp' }, { status: 404 });
      }
      if (isTextFile(abs) || fs.statSync(abs).size < 512 * 1024) {
        const content = fs.readFileSync(abs, 'utf-8');
        return NextResponse.json({ ok: true, path: body.path, content: content.slice(0, 200000) });
      }
      return NextResponse.json({ error: 'Tệp nhị phân — hãy tải xuống để xem' }, { status: 415 });
    }

    if (action === 'write') {
      const rel = String(body.path || '').replace(/^[/\\]+/, '');
      const abs = resolveSafe(rel);
      if (!abs || !rel) return NextResponse.json({ error: 'Đường dẫn không hợp lệ' }, { status: 400 });
      fs.mkdirSync(path.dirname(abs), { recursive: true });
      fs.writeFileSync(abs, String(body.content ?? ''));
      return NextResponse.json({ ok: true });
    }

    if (action === 'delete') {
      const abs = resolveSafe(String(body.path || ''));
      if (!abs || abs === WORKSPACE_ROOT) {
        return NextResponse.json({ error: 'Không thể xoá' }, { status: 400 });
      }
      fs.rmSync(abs, { recursive: true, force: true });
      return NextResponse.json({ ok: true });
    }

    if (action === 'mkdir') {
      const abs = resolveSafe(String(body.path || ''));
      if (!abs) return NextResponse.json({ error: 'Đường dẫn không hợp lệ' }, { status: 400 });
      fs.mkdirSync(abs, { recursive: true });
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi hệ thống tệp' },
      { status: 500 }
    );
  }
}
