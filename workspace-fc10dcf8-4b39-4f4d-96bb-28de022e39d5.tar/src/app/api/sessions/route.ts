import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';
import { getSessionUser } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const user = await getSessionUser(req);
  // Đã đăng nhập → chỉ phiên của tài khoản; chưa → phiên ẩn danh trên máy chủ
  const sessions = await db.chatSession.findMany({
    where: { userId: user?.id ?? null },
    orderBy: [{ pinned: 'desc' }, { updatedAt: 'desc' }],
    take: 100,
    include: {
      _count: { select: { messages: true } },
      messages: { where: { status: 'running' }, select: { id: true } },
    },
  });
  const mapped = sessions.map((s) => {
    const { messages, ...rest } = s;
    return { ...rest, running: messages.length > 0 };
  });
  return NextResponse.json(mapped);
}

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const user = await getSessionUser(req);
  const session = await db.chatSession.create({
    data: {
      title: body.title || 'Phiên chat mới',
      model: body.model || 'shark-1',
      mode: body.mode || 'normal',
      topic: body.topic || 'chung',
      think: body.think || 'off',
      speed: body.speed || 'medium',
      groupAI: !!body.groupAI,
      projectId: body.projectId || null,
      userId: user?.id || null,
    },
  });
  return NextResponse.json(session);
}
