import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';
import { cancelSession } from '@/lib/runner';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await db.chatSession.findUnique({
    where: { id },
    include: { messages: { orderBy: { createdAt: 'asc' } } },
  });
  if (!session) return NextResponse.json({ error: 'Không tìm thấy' }, { status: 404 });
  return NextResponse.json(session);
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await jsonBody(req);
  const data: Record<string, unknown> = {};
  for (const k of ['title', 'model', 'mode', 'topic', 'think', 'speed', 'projectId']) {
    if (k in body) data[k] = body[k];
  }
  if ('pinned' in body) data.pinned = !!body.pinned;
  if ('groupAI' in body) data.groupAI = !!body.groupAI;
  const session = await db.chatSession.update({ where: { id }, data });
  return NextResponse.json(session);
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  cancelSession(id); // huỷ luôn tác vụ đang chạy nền của phiên này
  await db.chatSession.delete({ where: { id } }).catch(() => {});
  return NextResponse.json({ ok: true });
}
