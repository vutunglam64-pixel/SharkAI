import { NextRequest, NextResponse } from 'next/server';
import { appOrigin, googleConfigured } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const origin = appOrigin(req);
  if (!googleConfigured()) {
    // Chưa cấu hình Google OAuth → về trang chủ, mở modal đăng nhập nhanh
    return NextResponse.redirect(`${origin}/?login=quick`);
  }
  const redirectUri = `${origin}/api/auth/google/callback`;
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID as string,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'openid email profile',
    prompt: 'select_account',
    access_type: 'online',
  });
  return NextResponse.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
}
