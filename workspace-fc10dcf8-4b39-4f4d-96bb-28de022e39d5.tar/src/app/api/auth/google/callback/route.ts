import { NextRequest, NextResponse } from 'next/server';
import { appOrigin, createSessionToken, googleConfigured, loginOrRegister, setSessionCookie } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const origin = appOrigin(req);
  const url = new URL(req.url);
  const code = url.searchParams.get('code');
  if (!code || !googleConfigured()) {
    return NextResponse.redirect(`${origin}/?login=error`);
  }
  try {
    const redirectUri = `${origin}/api/auth/google/callback`;
    // Đổi code lấy token
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID as string,
        client_secret: process.env.GOOGLE_CLIENT_SECRET as string,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });
    const tokenData = (await tokenRes.json()) as { access_token?: string };
    if (!tokenData.access_token) throw new Error('Không lấy được access token từ Google');
    // Lấy thông tin hồ sơ
    const infoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const info = (await infoRes.json()) as { sub?: string; email?: string; name?: string; picture?: string };
    if (!info.email) throw new Error('Google không trả về email');
    const user = await loginOrRegister({
      email: info.email,
      name: info.name || info.email.split('@')[0],
      image: info.picture || null,
      googleId: info.sub || null,
    });
    const res = NextResponse.redirect(`${origin}/?login=ok`);
    setSessionCookie(res, createSessionToken(user.id), req);
    return res;
  } catch {
    return NextResponse.redirect(`${origin}/?login=error`);
  }
}
