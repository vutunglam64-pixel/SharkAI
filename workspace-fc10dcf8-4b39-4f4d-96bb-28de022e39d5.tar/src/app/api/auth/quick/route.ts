import { NextRequest, NextResponse } from 'next/server';
import { jsonBody } from '@/lib/sse';
import {
  createSessionToken,
  setSessionCookie,
  loginOrRegister,
  normalizeEmail,
  isValidEmail,
} from '@/lib/auth';
import { db } from '@/lib/db';

// Đăng nhập nhanh kiểu CŨ (chỉ email + tên) — GIỮ LẠI để tương thích tài khoản
// tạo trước khi có mật khẩu, nhưng đã bị khoá chặt:
//  - email chưa có tài khoản        → từ chối, hướng dẫn sang tab Tạo tài khoản
//  - email đã có mật khẩu           → từ chối, phải đăng nhập bằng mật khẩu
//  - email là tài khoản quick cũ    → cho vào (không có mật khẩu để xác thực)
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const email = normalizeEmail(body.email);
  const name = String(body.name || '').trim() || email.split('@')[0];
  if (!isValidEmail(email)) {
    return NextResponse.json({ error: 'Email không hợp lệ' }, { status: 400 });
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (!existing) {
    return NextResponse.json(
      { error: 'Email chưa có tài khoản — hãy sang tab "Tạo tài khoản" để đăng ký với mật khẩu' },
      { status: 401 }
    );
  }
  if (existing.passwordHash) {
    return NextResponse.json(
      { error: 'Tài khoản này đã có mật khẩu — hãy đăng nhập bằng mật khẩu' },
      { status: 401 }
    );
  }

  const user = await loginOrRegister({ email, name });
  const res = NextResponse.json({ ok: true, user });
  setSessionCookie(res, createSessionToken(user.id), req);
  return res;
}
