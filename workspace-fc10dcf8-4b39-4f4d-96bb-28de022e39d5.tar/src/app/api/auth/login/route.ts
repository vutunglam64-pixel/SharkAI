import { NextRequest, NextResponse } from 'next/server';
import { jsonBody } from '@/lib/sse';
import {
  createSessionToken,
  setSessionCookie,
  verifyPassword,
  normalizeEmail,
} from '@/lib/auth';
import { db } from '@/lib/db';

// Đăng nhập bằng email + mật khẩu (scrypt). Đúng mật khẩu → cookie phiên 60 ngày,
// mọi thiết bị dùng chung tài khoản này đều thấy cùng lịch sử chat.
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const email = normalizeEmail(body.email);
  const password = String(body.password || '');

  if (!email || !password) {
    return NextResponse.json({ error: 'Nhập đủ email và mật khẩu' }, { status: 400 });
  }

  try {
    const user = await db.user.findUnique({ where: { email } });
    if (!user) {
      return NextResponse.json({ error: 'Email hoặc mật khẩu không đúng' }, { status: 401 });
    }
    // Tài khoản tạo từ thời chưa có mật khẩu (quick/Google) → hướng dẫn đặt mật khẩu
    // code no_password để frontend tự chuyển sang tab Tạo tài khoản với email đã điền sẵn
    if (!user.passwordHash) {
      return NextResponse.json(
        {
          error:
            'Tài khoản này chưa đặt mật khẩu. Hãy đặt mật khẩu ở tab "Tạo tài khoản" — dùng đúng email này, lịch sử chat được giữ nguyên.',
          code: 'no_password',
        },
        { status: 401 }
      );
    }
    if (!verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: 'Email hoặc mật khẩu không đúng' }, { status: 401 });
    }

    // nhận các phiên chat ẩn danh đang mở về tài khoản (chat trước khi đăng nhập)
    await db.chatSession.updateMany({ where: { userId: null }, data: { userId: user.id } });

    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, email: user.email, name: user.name, image: user.image },
    });
    setSessionCookie(res, createSessionToken(user.id), req);
    return res;
  } catch (e) {
    console.error('login error', e);
    return NextResponse.json({ error: 'Không đăng nhập được — thử lại' }, { status: 500 });
  }
}
