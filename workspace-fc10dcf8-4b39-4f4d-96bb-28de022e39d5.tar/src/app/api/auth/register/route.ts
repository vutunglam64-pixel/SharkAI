import { NextRequest, NextResponse } from 'next/server';
import { jsonBody } from '@/lib/sse';
import {
  createSessionToken,
  setSessionCookie,
  hashPassword,
  validatePasswordStrength,
  normalizeEmail,
  isValidEmail,
} from '@/lib/auth';
import { db } from '@/lib/db';

// Tạo tài khoản (email + mật khẩu). Nếu email đã tồn tại từ thời quick-login
// chưa có mật khẩu → nâng cấp: đặt mật khẩu luôn cho tài khoản đó.
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const email = normalizeEmail(body.email);
  const password = String(body.password || '');
  const name = String(body.name || '').trim() || email.split('@')[0];

  if (!isValidEmail(email)) {
    return NextResponse.json({ error: 'Email không hợp lệ' }, { status: 400 });
  }
  const pwError = validatePasswordStrength(password);
  if (pwError) {
    return NextResponse.json({ error: pwError }, { status: 400 });
  }

  try {
    const existing = await db.user.findUnique({ where: { email } });

    if (existing && existing.passwordHash) {
      return NextResponse.json(
        { error: 'Email này đã có tài khoản — hãy chuyển sang tab Đăng nhập' },
        { status: 409 }
      );
    }

    // Tài khoản Google (chưa từng có mật khẩu) không cho đặt mật khẩu qua email
    // — nếu cho phép, ai biết email là chiếm được tài khoản → phải vào bằng Google
    if (existing && existing.googleId && !existing.passwordHash) {
      return NextResponse.json(
        { error: 'Tài khoản này đăng nhập bằng Google — hãy bấm nút "Đăng nhập bằng Google"' },
        { status: 409 }
      );
    }

    const passwordHash = hashPassword(password);
    const user = existing
      ? await db.user.update({
          where: { id: existing.id },
          data: { name: name || existing.name, passwordHash },
        })
      : await db.user.create({ data: { email, name, passwordHash } });

    // nhận các phiên chat ẩn danh đang mở về tài khoản vừa tạo
    await db.chatSession.updateMany({ where: { userId: null }, data: { userId: user.id } });

    const res = NextResponse.json({
      ok: true,
      user: { id: user.id, email: user.email, name: user.name, image: user.image },
      upgraded: !!existing, // true nếu nâng cấp từ quick-login cũ sang có mật khẩu
    });
    setSessionCookie(res, createSessionToken(user.id), req);
    return res;
  } catch (e) {
    console.error('register error', e);
    return NextResponse.json({ error: 'Không tạo được tài khoản — thử lại' }, { status: 500 });
  }
}
