import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { jsonBody } from '@/lib/sse';
import { WORKSPACE_ROOT, ensureWorkspace, isTextFile } from '@/lib/workspace';
import fs from 'fs';
import path from 'path';

export const maxDuration = 60;

// Thu thập toàn bộ tệp trong workspace → map JSON { "<relPath>": { c: <base64>, bin: 0|1 } }
function collectWorkspaceFiles(): { files: Record<string, { c: string; bin: number }>; count: number } {
  ensureWorkspace();
  const out: Record<string, { c: string; bin: number }> = {};
  let count = 0;
  const walk = (rel: string, abs: string) => {
    if (count >= 200) return; // giới hạn số tệp
    const items = fs.readdirSync(abs, { withFileTypes: true });
    for (const item of items) {
      if (item.name.startsWith('.') || item.name === 'node_modules') continue;
      const r = rel ? `${rel}/${item.name}` : item.name;
      const a = path.join(abs, item.name);
      if (item.isDirectory()) {
        walk(r, a);
        continue;
      }
      const st = fs.statSync(a);
      if (!st.isFile() || st.size > 2 * 1024 * 1024) continue; // bỏ tệp quá lớn
      const buf = fs.readFileSync(a);
      out[r] = { c: buf.toString('base64'), bin: isTextFile(a) ? 0 : 1 };
      count++;
      if (count >= 200) return;
    }
  };
  walk('', WORKSPACE_ROOT);
  return { files: out, count };
}

// Tìm tệp HTML nhập cảnh: ưu tiên index.html, rồi *.html ở gốc, rồi *.html sâu nhất
function findEntry(files: Record<string, unknown>): string | null {
  const paths = Object.keys(files);
  const rootIndex = paths.find((p) => /^index\.html?$/i.test(p));
  if (rootIndex) return rootIndex;
  const rootHtml = paths.find((p) => /^[^/]+\.html?$/i.test(p));
  if (rootHtml) return rootHtml;
  const anyIndex = paths.find((p) => /(^|\/)index\.html?$/i.test(p));
  if (anyIndex) return anyIndex;
  return paths.find((p) => /\.html?$/i.test(p)) || null;
}

function decodeEntry(files: Record<string, { c: string; bin: number }>, entry: string | null): string {
  if (!entry || !files[entry]) return '';
  try {
    return Buffer.from(files[entry].c, 'base64').toString('utf-8');
  } catch {
    return '';
  }
}

// POST: đăng trang web — 3 chế độ:
//  1) { multi: true }           → thu thập CẢ THƯ MỤC dự án thành 1 site nhiều tệp (html + css + js + ảnh)
//  2) { path: "index.html" }    → đăng 1 tệp trong workspace
//  3) { html: "<html>..." }      → đăng trực tiếp chuỗi HTML (từ khối code)
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const name = String(body.name || 'Trang web của Shark').slice(0, 80);

  // ---- Chế độ đa tệp: cả thư mục thành 1 trang web ----
  if (body.multi) {
    const { files, count } = collectWorkspaceFiles();
    if (count === 0) {
      return NextResponse.json(
        { error: 'Thư mục dự án đang trống — hãy để Shark tạo file trước đã' },
        { status: 400 }
      );
    }
    const entry = findEntry(files);
    if (!entry) {
      return NextResponse.json(
        { error: 'Chưa có tệp .html nào làm trang chính — Shark cần tạo ít nhất 1 file HTML' },
        { status: 400 }
      );
    }
    const site = await db.publishedSite.create({
      data: {
        name,
        html: decodeEntry(files, entry),
        files: JSON.stringify(files),
      },
    });
    return NextResponse.json({
      ok: true,
      id: site.id,
      url: `/api/sites/${site.id}/`,
      multi: true,
      entry,
      fileCount: count,
    });
  }

  // ---- Chế độ 1 tệp (giữ tương thích cũ) ----
  let html = String(body.html || '');
  const path_ = String(body.path || '');
  if (!html && path_) {
    const abs = `${WORKSPACE_ROOT}/${path_.replace(/\.\./g, '')}`;
    if (fs.existsSync(abs)) html = fs.readFileSync(abs, 'utf-8');
  }
  if (!html.trim()) return NextResponse.json({ error: 'Thiếu nội dung HTML' }, { status: 400 });

  const site = await db.publishedSite.create({ data: { name, html } });
  return NextResponse.json({ ok: true, id: site.id, url: `/api/sites/${site.id}` });
}

// GET: danh sách trang đã đăng
export async function GET() {
  const sites = await db.publishedSite.findMany({
    orderBy: { createdAt: 'desc' },
    take: 50,
    select: { id: true, name: true, views: true, createdAt: true, files: true },
  });
  return NextResponse.json(
    sites.map((s) => ({
      id: s.id,
      name: s.name,
      views: s.views,
      createdAt: s.createdAt,
      // site đa tệp → đánh dấu để UI hiển thị "đa tệp"
      multi: !!s.files,
      fileCount: s.files ? Object.keys(JSON.parse(s.files)).length : 0,
    }))
  );
}
