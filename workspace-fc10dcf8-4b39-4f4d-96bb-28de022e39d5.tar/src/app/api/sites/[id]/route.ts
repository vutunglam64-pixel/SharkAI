import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Chèn <base href> ngay sau <head> (hoặc đầu file) để mọi link tương đối
// (style.css, js/app.js, images/...) trỏ vào /api/sites/<id>/... của chính site
export function injectBase(html: string, baseHref: string): string {
  if (/<base\s/i.test(html)) return html; // đã có base rồi thì thôi
  const tag = `<base href="${baseHref}">`;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, (m) => `${m}\n  ${tag}`);
  if (/<html[^>]*>/i.test(html)) return html.replace(/<html[^>]*>/i, (m) => `${m}\n  ${tag}`);
  return `${tag}\n${html}`;
}

// GET /api/sites/<id> — phục vụ trang đã đăng (nhập cảnh index cho site đa tệp)
export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const site = await db.publishedSite.findUnique({ where: { id } });
  if (!site) {
    return new NextResponse('<h1>404 — Không tìm thấy trang</h1>', {
      status: 404,
      headers: { 'Content-Type': 'text/html; charset=utf-8' },
    });
  }
  // tăng lượt xem (không chặn)
  db.publishedSite.update({ where: { id }, data: { views: { increment: 1 } } }).catch(() => {});

  // ---- Site đa tệp: phục vụ index kèm <base> để css/js/ảnh load đúng ----
  if (site.files) {
    let files: Record<string, { c: string; bin: number }> = {};
    try {
      files = JSON.parse(site.files);
    } catch {}
    const entry =
      Object.keys(files).find((p) => /^index\.html?$/i.test(p)) ||
      Object.keys(files).find((p) => /^[^/]+\.html?$/i.test(p)) ||
      Object.keys(files).find((p) => /(^|\/)index\.html?$/i.test(p)) ||
      Object.keys(files).find((p) => /\.html?$/i.test(p));
    if (entry && files[entry]) {
      let html = '';
      try {
        html = Buffer.from(files[entry].c, 'base64').toString('utf-8');
      } catch {}
      return new NextResponse(injectBase(html, `/api/sites/${id}/`), {
        status: 200,
        headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
      });
    }
  }

  // ---- Site 1 tệp (cũ) ----
  return new NextResponse(site.html, {
    status: 200,
    headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

// DELETE — xoá trang đã đăng
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    await db.publishedSite.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: 'Không tìm thấy trang' }, { status: 404 });
  }
}
