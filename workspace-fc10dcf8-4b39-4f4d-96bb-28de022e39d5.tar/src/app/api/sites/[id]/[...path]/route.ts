import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { mimeOf } from '@/lib/workspace';

// GET /api/sites/<id>/<đường dẫn tệp> — phục vụ css/js/ảnh... của site đa tệp đã đăng
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string; path: string[] }> }
) {
  const { id, path: segments } = await params;
  const rel = (segments || []).join('/');
  const site = await db.publishedSite.findUnique({ where: { id } });
  if (!site || !site.files) {
    return new NextResponse('404 — Không tìm thấy tệp', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  let files: Record<string, { c: string; bin: number }> = {};
  try {
    files = JSON.parse(site.files);
  } catch {}
  const f = files[rel];
  if (!f) {
    return new NextResponse('404 — Không tìm thấy tệp trong trang web', {
      status: 404,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
  try {
    const buf = Buffer.from(f.c, 'base64');
    const isBin = f.bin === 1;
    return new NextResponse(isBin ? new Uint8Array(buf) : buf.toString('utf-8'), {
      status: 200,
      headers: {
        'Content-Type': mimeOf(rel) || 'application/octet-stream',
        'Cache-Control': 'no-store',
      },
    });
  } catch {
    return new NextResponse('Lỗi đọc tệp', {
      status: 500,
      headers: { 'Content-Type': 'text/plain; charset=utf-8' },
    });
  }
}
