import { NextRequest, NextResponse } from 'next/server';
import { getZAI } from '@/lib/zai';

export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get('audio') as File | null;
    if (!file) return NextResponse.json({ error: 'Không có tệp âm thanh' }, { status: 400 });
    const buffer = Buffer.from(await file.arrayBuffer());
    const zai = await getZAI();
    const response = await zai.audio.asr.create({ file_base64: buffer.toString('base64') });
    const text = response?.text || '';
    return NextResponse.json({ ok: true, text });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi nhận dạng giọng nói' },
      { status: 500 }
    );
  }
}
