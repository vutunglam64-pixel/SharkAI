import { NextRequest, NextResponse } from 'next/server';
import { generateImage, imageSearch, editImage } from '@/lib/tools';
import { jsonBody } from '@/lib/sse';

export const maxDuration = 120;

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  try {
    const action = body.action || 'generate';
    if (action === 'generate') {
      const r = await generateImage(String(body.prompt || ''), String(body.size || '1024x1024'));
      return NextResponse.json({ ok: true, ...r });
    }
    if (action === 'search') {
      const items = await imageSearch(String(body.query || ''), Number(body.count) || 4);
      return NextResponse.json({ ok: true, items });
    }
    if (action === 'edit') {
      const r = await editImage(String(body.prompt || ''), String(body.image || ''));
      return NextResponse.json({ ok: true, ...r });
    }
    return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi xử lý ảnh' },
      { status: 500 }
    );
  }
}
