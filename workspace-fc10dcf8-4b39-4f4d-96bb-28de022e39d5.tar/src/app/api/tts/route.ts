import { NextRequest, NextResponse } from 'next/server';
import { getZAI } from '@/lib/zai';
import { jsonBody } from '@/lib/sse';

export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  const text = String(body.text || '').slice(0, 1000);
  const voice = String(body.voice || 'tongtong');
  const speed = Math.min(Math.max(Number(body.speed) || 1.0, 0.5), 2.0);
  if (!text.trim()) return NextResponse.json({ error: 'Thiếu văn bản' }, { status: 400 });
  try {
    const zai = await getZAI();
    const response = await zai.audio.tts.create({
      input: text,
      voice,
      speed,
      response_format: 'wav',
      stream: false,
    });
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(new Uint8Array(arrayBuffer));
    return new NextResponse(buffer, {
      status: 200,
      headers: {
        'Content-Type': 'audio/wav',
        'Content-Length': buffer.length.toString(),
        'Cache-Control': 'no-cache',
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi tạo giọng đọc' },
      { status: 500 }
    );
  }
}
