import { NextRequest, NextResponse } from 'next/server';
import { createVideoTask, pollVideoTask } from '@/lib/tools';
import { jsonBody } from '@/lib/sse';

export const maxDuration = 60;

// POST: tạo tác vụ video mới
export async function POST(req: NextRequest) {
  const body = await jsonBody(req);
  try {
    const taskId = await createVideoTask(String(body.prompt || ''));
    if (!taskId) return NextResponse.json({ error: 'Không tạo được tác vụ video' }, { status: 500 });
    return NextResponse.json({ ok: true, taskId });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi tạo video' },
      { status: 500 }
    );
  }
}

// GET ?taskId=... : kiểm tra trạng thái
export async function GET(req: NextRequest) {
  const taskId = req.nextUrl.searchParams.get('taskId');
  if (!taskId) return NextResponse.json({ error: 'Thiếu taskId' }, { status: 400 });
  try {
    const r = await pollVideoTask(taskId);
    return NextResponse.json(r);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : 'Lỗi kiểm tra video' },
      { status: 500 }
    );
  }
}
