import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowLeft, ScrollText, ShieldCheck, Cloud, HeartHandshake, FileText, UserCheck } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Điều khoản & Dịch vụ — Shark',
  description: 'Điều khoản sử dụng, điều khoản dịch vụ và chính sách quyền riêng tư của Shark AI',
};

const SECTIONS = [
  {
    id: 'dieu-khoan-su-dung',
    icon: ScrollText,
    title: '1. Điều khoản sử dụng',
    items: [
      'Shark là trợ lý AI miễn phí 100%, vận hành trên các mô hình ngôn ngữ lớn mixture-of-experts mã nguồn mở. Khi sử dụng ứng dụng, bạn đồng ý tuân thủ các điều khoản dưới đây.',
      'Bạn đồng ý chỉ sử dụng Shark cho các mục đích hợp pháp: học tập, nghiên cứu, lập trình, sáng tạo nội dung và giải quyết công việc hàng ngày. Không sử dụng ứng dụng để tạo nội dung vi phạm pháp luật, xâm phạm quyền sở hữu trí tuệ hoặc gây hại cho người khác.',
      'Bạn không được cố tình tấn công hệ thống, dò quét lỗ hổng bảo mật, spam hoặc cố gắng làm gián đoạn dịch vụ cho người dùng khác.',
      'Shark do vutunglam08 phát triển và duy trì. Mọi câu hỏi, góp ý về dịch vụ xin gửi về địa chỉ liên hệ trong ứng dụng.',
      'Chức năng Agent và Terminal cho phép AI chạy lệnh trên môi trường máy chủ cách ly. Hoạt động này được giám sát và giới hạn trong thư mục làm việc riêng của mỗi phiên.',
    ],
  },
  {
    id: 'dieu-khoan-dich-vu',
    icon: FileText,
    title: '2. Điều khoản dịch vụ',
    items: [
      'Dịch vụ được cung cấp hoàn toàn miễn phí, không giới hạn số lượt trò chuyện, không tính credit hay bất kỳ khoản phí nào.',
      'Các tính năng bao gồm: trò chuyện đa mô hình, chế độ Agent (tạo file, chạy terminal), Deep Research, tạo ảnh/video AI, phân tích tệp, xuất ZIP/HTML, đăng web tĩnh và tạo skill tùy chỉnh.',
      'Chúng tôi không cam kết thời gian hoạt động (uptime) tuyệt đối. Dịch vụ có thể tạm gián đoạn để bảo trì, nâng cấp mà không cần báo trước.',
      'Nội dung do AI tạo ra có thể không chính xác. Bạn chịu trách nhiệm kiểm chứng thông tin quan trọng trước khi sử dụng vào mục đích học tập, công việc hay phát hành.',
      'Các trang web bạn đăng lên internet qua tính năng "Lên web" là trang tĩnh công khai; đừng đưa thông tin cá nhân nhạy cảm vào nội dung được đăng.',
      'Chúng tôi có quyền cải tiến, thêm hoặc bớt tính năng của dịch vụ theo thời gian nhằm mang lại trải nghiệm tốt nhất.',
    ],
  },
  {
    id: 'quyen-rieng-tu',
    icon: ShieldCheck,
    title: '3. Quyền riêng tư',
    items: [
      'Các phiên chat được lưu trên máy chủ để bạn có thể quay lại xem lịch sử. Khi bạn đăng nhập, phiên chat được gắn với tài khoản và đồng bộ trên mọi thiết bị dùng chung tài khoản đó.',
      'Tệp bạn tải lên (ảnh, video, văn bản) chỉ được dùng để phân tích trong phiên chat tương ứng và lưu trong thư mục riêng trên máy chủ.',
      'Chúng tôi không bán, không chia sẻ dữ liệu của bạn cho bên thứ ba vì mục đích thương mại.',
      'Bạn có toàn quyền xoá bất kỳ phiên chat nào trong lịch sử; dữ liệu xoá sẽ không thể khôi phục.',
      'Đăng nhập bằng Google chỉ dùng để xác thực danh tính: chúng tôi chỉ nhận tên hiển thị, email và ảnh đại diện — không đọc email, lịch hay bất kỳ dữ liệu Google nào khác của bạn.',
    ],
  },
  {
    id: 'tai-khoan',
    icon: UserCheck,
    title: '4. Tài khoản & đồng bộ',
    items: [
      'Đăng nhập giúp lưu trữ và đồng bộ phiên chat giữa các thiết bị: điện thoại, máy tính, tablet — mọi thiết bị dùng chung một tài khoản đều thấy cùng lịch sử chat.',
      'Bạn có trách nhiệm bảo mật tài khoản của mình. Không chia sẻ mật khẩu hoặc quyền truy cập Google cho người khác.',
      'Nếu phát hiện tài khoản bị truy cập trái phép, hãy đăng xuất trên các thiết bị và liên hệ với chúng tôi.',
      'Tài khoản không hoạt động trong thời gian dài có thể được dọn dẹp dữ liệu để tối ưu máy chủ; chúng tôi sẽ thông báo trước khi thực hiện khi có kênh liên hệ.',
    ],
  },
  {
    id: 'chay-nen',
    icon: Cloud,
    title: '5. Chế độ chạy nền',
    items: [
      'Khi bạn thoát khỏi một đoạn chat đang được AI xử lý, tác vụ vẫn tiếp tục chạy trên máy chủ. Bạn có thể quay lại sau để xem kết quả đã hoàn thành.',
      'Kết quả chạy nền được lưu tự động vào phiên chat tương ứng, kể cả khi bạn đã chuyển sang đoạn chat khác hoặc tắt trình duyệt.',
      'Bạn có thể huỷ bất kỳ tác vụ đang chạy nào bằng nút "Dừng" trong khung chat.',
    ],
  },
  {
    id: 'lien-he',
    icon: HeartHandshake,
    title: '6. Liên hệ & ghi nhận',
    items: [
      'Ứng dụng được phát triển bởi vutunglam08 với tinh thần mã nguồn mở và miễn phí cho cộng đồng.',
      'Shark vận hành trên các mô hình mixture-of-experts mã nguồn mở: Shark 1.0, DeepSeek-V3, Mixtral 8x22B, Qwen3-235B-A22B, GPT-OSS-120B, Qwen3-30B-A3B và Phi-3.5-MoE.',
      'Mọi đóng góp ý kiến, báo lỗi hoặc đề xuất tính năng mới đều được chào đón và ghi nhận.',
    ],
  },
];

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/80 backdrop-blur sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft size={16} /> Về Shark
          </Link>
          <span className="text-sm font-semibold ml-auto">Điều khoản &amp; Dịch vụ</span>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Điều khoản &amp; Dịch vụ</h1>
          <p className="text-muted-foreground mt-2 text-[15px]">
            Điều khoản sử dụng, điều khoản dịch vụ và chính sách quyền riêng tư của Shark — có hiệu lực từ ngày công bố ứng dụng.
            Shark miễn phí 100% và được tạo ra bởi <span className="font-semibold text-foreground">vutunglam08</span>.
          </p>
        </div>

        <nav className="mb-8 rounded-2xl border bg-card p-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Mục lục</p>
          <ul className="grid sm:grid-cols-2 gap-1.5">
            {SECTIONS.map((s) => (
              <li key={s.id}>
                <a href={`#${s.id}`} className="text-[13.5px] text-primary hover:underline">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="space-y-10">
          {SECTIONS.map((s) => (
            <section key={s.id} id={s.id} className="scroll-mt-20">
              <h2 className="flex items-center gap-2.5 text-xl font-semibold mb-4">
                <span className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <s.icon size={17} className="text-primary" />
                </span>
                {s.title}
              </h2>
              <div className="space-y-3 text-[15px] leading-relaxed text-foreground/90">
                {s.items.map((item, i) => (
                  <p key={i} className="pl-1">
                    {item}
                  </p>
                ))}
              </div>
            </section>
          ))}
        </div>

        <footer className="mt-12 pt-6 border-t text-center text-[13px] text-muted-foreground">
          Shark · Miễn phí 100% · Phát triển bởi vutunglam08
        </footer>
      </main>
    </div>
  );
}
