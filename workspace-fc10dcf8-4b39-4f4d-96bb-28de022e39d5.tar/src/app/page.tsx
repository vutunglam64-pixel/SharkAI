'use client';

import { useEffect, useRef } from 'react';
import { Sidebar } from '@/components/app/sidebar';
import { ChatHeader } from '@/components/app/header';
import { WelcomeScreen } from '@/components/app/welcome';
import { ChatInput } from '@/components/app/input';
import { MessageBubble } from '@/components/app/messages';
import { RightPanel } from '@/components/app/panel';
import { Modals } from '@/components/app/modals';
import { GroupPage } from '@/components/app/group-page';
import { useAppStore } from '@/store/app-store';

export default function Home() {
  const messages = useAppStore((s) => s.messages);
  const streaming = useAppStore((s) => s.streaming);
  const pendingPhase = useAppStore((s) => s.pendingPhase);
  const sidebarOpen = useAppStore((s) => s.sidebarOpen);
  const groupAI = useAppStore((s) => s.groupAI);
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // tự cuộn xuống cuối khi có tin nhắn mới
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: streaming ? 'auto' : 'smooth' });
  }, [messages, streaming]);

  return (
    <div className="h-screen flex overflow-hidden bg-background">
      <Sidebar />

      <div className="flex-1 flex min-w-0">
        {/* BẬT Group AI → sang trang group (đội 8 agent); TẮT → về chat thường */}
        {groupAI ? (
          <GroupPage key="group" />
        ) : (
          <main key="chat" className="flex-1 flex flex-col min-w-0 anim-fade-in">
            <ChatHeader />

            {messages.length === 0 ? (
              <div className="flex-1 overflow-y-auto flex flex-col">
                <div className="flex-1 flex flex-col justify-center">
                  <WelcomeScreen />
                </div>
                <ChatInput />
              </div>
            ) : (
              <>
                <div ref={scrollRef} className="flex-1 overflow-y-auto">
                  <div className="max-w-3xl mx-auto px-4 py-6 space-y-7">
                    {messages.map((m) => (
                      <MessageBubble key={m.id} msg={m} />
                    ))}
                    {streaming && pendingPhase && (
                      <div className="flex items-center gap-2 text-[13px] text-muted-foreground pl-0.5 anim-fade-in">
                        <span className="inline-block h-3.5 w-3.5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                        {pendingPhase}
                      </div>
                    )}
                    <div ref={bottomRef} className="h-2" />
                  </div>
                </div>
                <ChatInput />
              </>
            )}
          </main>
        )}

        {/* panel phải: Thư mục / Terminal / Xem trước */}
        <RightPanel />
      </div>

      <Modals />

      {/* che sidebar trên mobile */}
      {!sidebarOpen && <div className="hidden" />}
    </div>
  );
}
