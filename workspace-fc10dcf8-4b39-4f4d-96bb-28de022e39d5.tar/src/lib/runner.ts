// Registry các phiên chat bị người dùng huỷ (chạy nền phía server)
// Dùng chung giữa /api/chat (kiểm tra) và /api/sessions/[id] (huỷ khi xoá phiên)
const cancelledSessions = new Set<string>();

export function cancelSession(sid: string) {
  cancelledSessions.add(sid);
}

export function isCancelled(sid: string): boolean {
  return cancelledSessions.has(sid);
}

export function clearCancel(sid: string) {
  cancelledSessions.delete(sid);
}
