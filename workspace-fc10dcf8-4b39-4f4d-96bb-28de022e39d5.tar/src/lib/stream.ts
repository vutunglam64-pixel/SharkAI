// Parse ReadableStream do z-ai-web-dev-sdk trả về khi stream: true
// Stream là SSE dạng: data: {"choices":[{"delta":{"content":"...","reasoning_content":"..."}}]}

export interface StreamDelta {
  content: string;
  thinking: string;
}

export async function* parseSDKStream(
  body: ReadableStream<Uint8Array> | null
): AsyncGenerator<StreamDelta> {
  if (!body) return;
  const reader = body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // xử lý từng dòng "data: ..." hoàn chỉnh
      let idx: number;
      while ((idx = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === '[DONE]') continue;
        try {
          const json = JSON.parse(payload);
          const delta = json?.choices?.[0]?.delta ?? {};
          const content: string =
            delta.content ?? delta.text ?? json?.choices?.[0]?.message?.content ?? '';
          const thinking: string =
            delta.reasoning_content ??
            delta.thinking_content ??
            delta.reasoning ??
            delta.thinking ??
            '';
          if (content || thinking) {
            yield { content: String(content), thinking: String(thinking) };
          }
        } catch {
          // dòng không phải JSON — bỏ qua
        }
      }
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // ignore
    }
  }
}

// Giữ lại phần đuôi có thể là tiền tố của "<tool>" để không render lộn xộn
const TAG = '<tool>';
export function splitTagPrefix(text: string): { safe: string; held: string } {
  // tìm vị trí "<" gần nhất sao cho phần sau nó là tiền tố của TAG
  const maxCheck = Math.min(text.length, TAG.length - 1);
  for (let len = maxCheck; len > 0; len--) {
    const tail = text.slice(text.length - len);
    if (TAG.startsWith(tail)) {
      return { safe: text.slice(0, text.length - len), held: tail };
    }
  }
  return { safe: text, held: '' };
}
