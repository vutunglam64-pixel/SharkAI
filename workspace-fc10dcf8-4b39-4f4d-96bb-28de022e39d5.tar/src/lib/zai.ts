import ZAI from 'z-ai-web-dev-sdk';

// kiểu instance đúng: Awaited<ReturnType<...>> mới unwrap được Promise<ZAI>
// (trước đây dùng Awaited<typeof ZAI.create> — là kiểu HÀM, gây lỗi type toàn hệ thống)
type ZAIInstance = Awaited<ReturnType<typeof ZAI.create>>;

let zaiInstance: ZAIInstance | null = null;

export async function getZAI(): Promise<ZAIInstance> {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export default getZAI;
