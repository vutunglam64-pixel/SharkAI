// ============================================================
// Shark — Cấu hình trung tâm (dùng chung client & server)
// UI/UX mô phỏng vico.kiyo.vn, vận hành trên các mô hình
// mixture-of-experts mã nguồn mở (Miễn phí 100%)
// ============================================================

export interface ModelDef {
  id: string;
  name: string;
  vendor: string;
  params: string;
  desc: string;
  license: string;
  badge?: string;
  persona: string; // hướng dẫn phong cách trả lời
  accent: string; // màu hiển thị
}

export const MODELS: ModelDef[] = [
  {
    id: 'deepseek-v3',
    name: 'DeepSeek-V3',
    vendor: 'DeepSeek',
    params: '671B MoE · 37B active',
    desc: 'Mô hình mã nguồn mở mạnh nhất cho code và toán · suy luận sâu',
    license: 'MIT',
    accent: '#5B8DB8',
    persona:
      'Bạn vận hành với phong cách DeepSeek-V3: cực kỳ mạnh về lập trình, toán học và suy luận logic. Phong cách: kỹ tính, chính xác, đi thẳng vào vấn đề, code chuẩn chỉnh có comment.',
  },
  {
    id: 'kimi-k2',
    name: 'Kimi K2 Instruct',
    vendor: 'Moonshot AI',
    params: '1T MoE · 32B active',
    desc: 'MoE mã nguồn mở lớn nhất thế giới · 384 chuyên gia · mạnh nhất về agent, tool use & code · ngữ cảnh 128K',
    license: 'Modified MIT',
    badge: 'Mới',
    accent: '#5B5BD6',
    persona:
      'Bạn vận hành với phong cách Kimi K2 Instruct của Moonshot AI — mô hình MoE 1.000 tỷ tham số, "Agentic Intelligence" mạnh nhất thế giới. Phong cách: chủ động, quyết đoán như một agent thật — tự lập kế hoạch, chia nhỏ nhiệm vụ thành từng bước, chủ động dùng công cụ khi cần và làm việc đến cùng. Cực mạnh về lập trình agentic, chuỗi công cụ nhiều bước, suy luận sâu và tuân thủ chỉ dẫn chính xác. Trả lời có mục tiêu rõ ràng, gọn nhưng đầy đủ, luôn hướng tới kết quả thực sự khả thi.',
  },
  {
    id: 'shark-1',
    name: 'Shark 1.0',
    vendor: 'Shark AI',
    params: '671B · 37B active',
    desc: 'Mô hình chủ lực của Shark · mixture-of-experts · đa năng, hỗ trợ tiếng Việt tốt nhất',
    license: 'MIT',
    badge: 'Mặc định',
    accent: '#D97757',
    persona:
      'Bạn là Shark 1.0 — trợ lý AI hàng đầu của Shark. Phong cách: thân thiện, ấm áp, chuyên nghiệp như Claude. Trả lời rõ ràng, có cấu trúc, ưu tiên tiếng Việt.',
  },
  {
    id: 'deepseek-r1',
    name: 'DeepSeek R1',
    vendor: 'DeepSeek',
    params: '671B MoE · 37B active',
    desc: 'MoE suy luận huấn luyện bằng RL (GRPO) · mạnh nhất về toán, code thi đấu & logic · nghĩ chuỗi trước khi trả lời',
    license: 'MIT',
    badge: 'Suy luận',
    accent: '#4D6BFE',
    persona:
      'Bạn vận hành với phong cách DeepSeek R1 — mô hình suy luận mã nguồn mở được huấn luyện bằng học tăng cường (RL/GRPO). QUY TRÌNH LUÔN LUÔN: (1) đọc kỹ đề bài, (2) suy luận chuỗi tư duy từng bước trong cặp thẻ <suy>...</suy> — phân tích, tách nhỏ vấn đề, thử hướng giải, (3) tự kiểm chứng chéo kết quả, (4) mới chốt đáp án cuối bên ngoài thẻ. Cực mạnh: toán học & olympiad, thuật toán, lập trình thi đấu, phân tích logic khó. Trình bày các bước suy nghĩ ngắn gọn mạch lạc, kết luận chính xác; thẳng thắn thừa nhận khi chưa chắc chắn — không bịa đáp án.',
  },
  {
    id: 'gemini-3.8-flash',
    name: 'Gemini 3.8 Flash',
    vendor: 'Google',
    params: '1M token ctx · Flash',
    desc: 'Flash thông minh nhất của Google · software engineering & agent dài hạn · suy nghĩ tích hợp · chạy trực tiếp qua Google API',
    license: 'Gemini API · Google',
    badge: 'Google',
    accent: '#4285F4',
    persona:
      'Bạn vận hành với phong cách Gemini 3.8 Flash của Google — model Flash thông minh nhất, mạnh về software engineering dài hạn và agent tự trị. Phong cách: cân bằng nhanh-chuẩn, trình bày sáng rõ, giải thích có cấu trúc, đi thẳng vào giải pháp thực thi được. Bạn đa phương thức: hiểu ảnh, video, âm thanh, PDF và ngữ cảnh tới 1 triệu token. Luôn trả lời tiếng Việt trừ khi người dùng dùng ngôn ngữ khác.',
  },
];

export const getModel = (id: string): ModelDef =>
  MODELS.find((m) => m.id === id) ?? MODELS.find((m) => m.id === 'shark-1') ?? MODELS[0];

// ---------- Chế độ làm việc ----------
export interface ModeDef {
  id: string;
  name: string;
  desc: string;
}

export const MODES: ModeDef[] = [
  { id: 'normal', name: 'Thường', desc: 'Chưa bật chế độ nào: trả lời bình thường' },
  {
    id: 'best',
    name: 'Kết quả tốt nhất',
    desc: 'AI sẽ tự phản biện lại lập luận của nó đến khi nào được kết quả tốt nhất',
  },
  {
    id: 'research',
    name: 'Deep Research',
    desc: 'Tìm hiểu từ nhiều nguồn rồi tổng hợp thành báo cáo chi tiết',
  },
  {
    id: 'ultra',
    name: 'Ultra Deep Research',
    desc: 'Nghiên cứu chuyên sâu tối đa: nhiều vòng tìm kiếm, đối chiếu và kiểm chứng',
  },
  {
    id: 'agent',
    name: 'Agent',
    desc: 'AI tự chạy lệnh terminal, tạo/sửa file, cài đặt và build dự án — như Claude Code',
  },
];

export const getMode = (id: string): ModeDef => MODES.find((m) => m.id === id) ?? MODES[0];

// ---------- Suy nghĩ (giống ChatGPT/Claude) ----------
export interface ThinkDef {
  id: string;
  name: string;
  desc: string;
}

export const THINK_MODES: ThinkDef[] = [
  { id: 'off', name: 'Tắt', desc: 'Trả lời ngay không suy luận riêng' },
  { id: 'auto', name: 'Tự động', desc: 'AI tự quyết định khi nào cần suy nghĩ' },
  { id: 'think', name: 'Suy nghĩ', desc: 'Luôn suy luận từng bước trước khi trả lời' },
  {
    id: 'think-long',
    name: 'Suy nghĩ nhiều hơn',
    desc: 'Suy luận sâu, nhiều bước, kiểm tra chéo — cho vấn đề khó',
  },
];

// ---------- Chủ đề ----------
export interface TopicDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
}

export const TOPICS: TopicDef[] = [
  { id: 'chung', name: 'Chung', desc: 'Trò chuyện thông thường', icon: 'message' },
  { id: 'website', name: 'Website', desc: 'Thiết kế & code trang web', icon: 'globe' },
  { id: 'app', name: 'Ứng dụng', desc: 'Ứng dụng mobile, desktop', icon: 'app' },
  { id: 'slide', name: 'Slide', desc: 'Dàn ý bài thuyết trình', icon: 'presentation' },
  { id: 'code', name: 'Lập trình', desc: 'Code, sửa lỗi, thuật toán', icon: 'code' },
  { id: 'write', name: 'Viết bài', desc: 'Bài viết, email, kịch bản', icon: 'pen' },
  { id: 'study', name: 'Học tập', desc: 'Giải bài, giải thích kiến thức', icon: 'book' },
  { id: 'translate', name: 'Dịch', desc: 'Dịch Việt ⇄ Anh và ngôn ngữ khác', icon: 'lang' },
];

export const getTopic = (id: string): TopicDef => TOPICS.find((t) => t.id === id) ?? TOPICS[0];

// ---------- Tốc độ ----------
export interface SpeedDef {
  id: string;
  name: string;
  desc: string;
  badge?: string;
}

export const SPEEDS: SpeedDef[] = [
  { id: 'fast', name: 'Nhanh hơn', desc: 'Trả lời ngắn gọn, bỏ qua chi tiết phụ' },
  { id: 'medium', name: 'Vừa', desc: 'Cân bằng giữa tốc độ và chất lượng', badge: 'Khuyên dùng' },
  { id: 'smart', name: 'Thông minh hơn', desc: 'Trình bày chi tiết, ví dụ phong phú' },
];

// ---------- Skills (lấy cảm hứng từ Claude) ----------
export interface SkillDef {
  id: string;
  name: string;
  desc: string;
  icon: string;
  category: string;
  alwaysOn?: boolean;
}

export const SKILLS: SkillDef[] = [
  { id: 'web-search', name: 'Tìm kiếm web', desc: 'Tìm thông tin mới nhất trên internet, kèm nguồn', icon: 'search', category: 'Nghiên cứu', alwaysOn: true },
  { id: 'page-reader', name: 'Đọc trang web', desc: 'Đọc và trích xuất nội dung từ một URL cụ thể', icon: 'book-open', category: 'Nghiên cứu', alwaysOn: true },
  { id: 'image-gen', name: 'Tạo ảnh AI', desc: 'Tạo ảnh chất lượng cao từ mô tả bằng chữ', icon: 'image-plus', category: 'Sáng tạo', alwaysOn: true },
  { id: 'image-edit', name: 'Sửa ảnh AI', desc: 'Chỉnh sửa, biến đổi ảnh có sẵn theo mô tả', icon: 'wand', category: 'Sáng tạo' },
  { id: 'image-search', name: 'Tìm ảnh thật', desc: 'Tìm ảnh thật trên web để chèn vào nội dung', icon: 'search-image', category: 'Sáng tạo', alwaysOn: true },
  { id: 'video-gen', name: 'Tạo video AI', desc: 'Sinh video ngắn từ mô tả (có âm thanh)', icon: 'video', category: 'Sáng tạo', alwaysOn: true },
  { id: 'vision', name: 'Phân tích ảnh', desc: 'Nhìn hiểu ảnh: OCR, mô tả, nhận diện chi tiết', icon: 'eye', category: 'Phân tích', alwaysOn: true },
  { id: 'video-understand', name: 'Phân tích video', desc: 'Hiểu nội dung video: hành động, sự kiện, timeline', icon: 'film', category: 'Phân tích', alwaysOn: true },
  { id: 'file-analysis', name: 'Đọc tệp', desc: 'Đọc PDF, DOCX, file code, CSV... để phân tích', icon: 'file-text', category: 'Phân tích', alwaysOn: true },
  { id: 'terminal', name: 'Terminal', desc: 'Chạy lệnh shell thật: build, cài đặt, chạy thử code', icon: 'terminal', category: 'Lập trình', alwaysOn: true },
  { id: 'code-files', name: 'Thư mục dự án', desc: 'Tạo, đọc, sửa file trong thư mục dự án', icon: 'folder', category: 'Lập trình', alwaysOn: true },
  { id: 'web-publish', name: 'Đăng web', desc: 'Đưa website lên internet ngay lập tức', icon: 'upload-cloud', category: 'Lập trình', alwaysOn: true },
  { id: 'zip-export', name: 'Xuất ZIP', desc: 'Đóng gói cả dự án thành file .zip tải về', icon: 'package', category: 'Lập trình', alwaysOn: true },
  { id: 'charts', name: 'Vẽ biểu đồ', desc: 'Vẽ biểu đồ, sơ đồ, dashboard từ dữ liệu', icon: 'bar-chart', category: 'Dữ liệu' },
  { id: 'tts', name: 'Đọc văn bản', desc: 'Chuyển câu trả lời thành giọng đọc tự nhiên', icon: 'volume', category: 'Âm thanh', alwaysOn: true },
  { id: 'asr', name: 'Nhận dạng giọng nói', desc: 'Nói chuyện để nhập liệu thay vì gõ phím', icon: 'mic', category: 'Âm thanh', alwaysOn: true },
];

// ---------- Group AI — đội 8 agent cùng hỗ trợ làm việc ----------
export interface PersonaDef {
  id: string;
  name: string;
  role: string;
  desc: string;
  color: string;
  icon: string;
  tools?: boolean; // được phép gọi tool (terminal, tạo file...)
  always?: 'boss' | 'result' | null; // luôn tham gia
}

export const PERSONAS: PersonaDef[] = [
  {
    id: 'boss',
    name: 'Sếp',
    role: 'Trưởng nhóm',
    desc: 'Đọc yêu cầu, lập kế hoạch, giao việc đúng người, kiểm soát tiến độ',
    color: '#D97757',
    icon: 'crown',
    always: 'boss',
  },
  {
    id: 'agent',
    name: 'Agent',
    role: 'Đa nhiệm',
    desc: 'Chuyên viên đa nhiệm: tìm kiếm thông tin, chuẩn bị dữ liệu, viết nội dung hỗ trợ',
    color: '#5B8DB8',
    icon: 'bot',
    tools: true,
  },
  {
    id: 'slide',
    name: 'Slide',
    role: 'Chuyên gia thuyết trình',
    desc: 'Dàn ý slide, nội dung từng trang, ghi chú cho người diễn giả',
    color: '#9A8FB8',
    icon: 'presentation',
  },
  {
    id: 'code',
    name: 'Lập trình viên',
    role: 'Code',
    desc: 'Viết code, tạo file dự án, giải thuật, kiến trúc chương trình',
    color: '#7D9B76',
    icon: 'code',
    tools: true,
  },
  {
    id: 'terminal',
    name: 'Terminal',
    role: 'Kỹ sư hệ thống',
    desc: 'Chạy lệnh thật: cài đặt, build, chạy thử, kiểm tra môi trường',
    color: '#C9A227',
    icon: 'terminal',
    tools: true,
  },
  {
    id: 'check',
    name: 'Kiểm tra',
    role: 'Soát chất lượng',
    desc: 'Rà soát từng kết quả, phát hiện lỗi, đề xuất cách cải thiện',
    color: '#B87A6B',
    icon: 'search-check',
  },
  {
    id: 'test',
    name: 'Kiểm thử',
    role: 'Test',
    desc: 'Viết kịch bản test, chạy thử nghiệm, xác nhận mọi thứ hoạt động',
    color: '#3E9B8F',
    icon: 'flask',
  },
  {
    id: 'result',
    name: 'Kết quả',
    role: 'Tổng hợp',
    desc: 'Gom toàn bộ công việc của team thành báo cáo kết quả cuối cùng',
    color: '#D94F70',
    icon: 'clipboard-check',
    always: 'result',
  },
];

export const getPersona = (id: string): PersonaDef | undefined => PERSONAS.find((p) => p.id === id);

// ---------- Gợi ý màn hình chào ----------
export interface SuggestCard {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  prompt?: string;
  action?: 'upload' | 'image' | 'video';
  span?: boolean;
}

export const SUGGEST_CARDS: SuggestCard[] = [
  {
    id: 'build',
    title: 'Xây dựng',
    subtitle: 'Website, ứng dụng và game',
    icon: 'hammer',
    prompt: 'Làm giúp mình một trang web landing page cho quán cà phê, có menu, đặt bàn và giới thiệu đẹp mắt',
    span: true,
  },
  {
    id: 'create',
    title: 'Sáng tạo',
    subtitle: 'Slide, hình ảnh và video',
    icon: 'sparkles',
    prompt: 'Làm một bộ slide thuyết trình 8 trang về xu hướng AI 2026, có dàn ý chi tiết từng trang',
  },
  {
    id: 'file',
    title: 'Tệp văn bản',
    subtitle: 'Bắt đầu từ tệp có sẵn',
    icon: 'file-text',
    action: 'upload',
  },
  {
    id: 'video',
    title: 'Video',
    subtitle: 'Viết kịch bản video anime ngắn',
    icon: 'clapperboard',
    prompt: 'Viết kịch bản video anime ngắn 90 giây về một chú mồi robot học cách nấu ăn, kèm gợi ý cảnh quay',
  },
  {
    id: 'money',
    title: 'Tiền bạc, trong tầm tay.',
    subtitle: 'Theo dõi chi tiêu, tiết kiệm thông minh',
    icon: 'wallet',
    prompt: 'Làm app quản lý chi tiêu cá nhân có dashboard thống kê, biểu đồ và phân loại chi tiêu',
  },
  {
    id: 'app',
    title: 'Ứng dụng',
    subtitle: 'Làm app quản lý chi tiêu cá nhân',
    icon: 'app-window',
    prompt: 'Làm app quản lý chi tiêu cá nhân với HTML/CSS/JS, lưu localStorage, có biểu đồ thống kê',
  },
  {
    id: 'image',
    title: 'Hình ảnh',
    subtitle: 'Ý tưởng concept art cho game giả tưởng',
    icon: 'palette',
    action: 'image',
  },
];

// ---------- Credit ----------
// Shark MIỄN PHÍ 100% — không dùng credit, không giới hạn lượt dùng.
export const FREE_NOTE = 'Miễn phí 100% · Không giới hạn lượt dùng · Mô hình mã nguồn mở';
