import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';
import { db } from '@/lib/db';
import { getSecret } from '@/lib/secrets';

// ============================================================
// Auth: cookie phiên ký HMAC-SHA256 (không cần thư viện ngoài)
// Hỗ trợ Google OAuth + email/mật khẩu (scrypt) + quick cũ (không mật khẩu)
// Cookie 60 ngày, SameSite=None+Secure khi qua HTTPS → dùng được cả
// trong iframe preview (đóng tab / vào lại vẫn giữ đăng nhập)
// Secret ký lấy từ db/secrets.json — bền vững qua sandbox recycle
// (.env bị gitignore nên bị reset mỗi lần restart, làm chết cookie)
// ============================================================

const COOKIE_NAME = 'shark_session';
const MAX_AGE = 60 * 60 * 24 * 60; // 60 ngày

function secret(): string {
  // generate:true → tự sinh + ghi vào db/secrets.json đúng 1 lần
  return getSecret('AUTH_SECRET', { generate: true });
}

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  image: string | null;
}

function sign(data: string): string {
  return crypto.createHmac('sha256', secret()).update(data).digest('base64url');
}

export function createSessionToken(userId: string): string {
  const payload = Buffer.from(JSON.stringify({ uid: userId, exp: Date.now() + MAX_AGE * 1000 })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string | undefined | null): string | null {
  if (!token) return null;
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  try {
    if (sign(payload) !== sig) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8'));
    if (!data.uid || !data.exp || data.exp < Date.now()) return null;
    return data.uid as string;
  } catch {
    return null;
  }
}

/** Đọc user hiện tại từ cookie phiên */
export async function getSessionUser(req: NextRequest): Promise<SessionUser | null> {
  const uid = verifySessionToken(req.cookies.get(COOKIE_NAME)?.value);
  if (!uid) return null;
  try {
    const u = await db.user.findUnique({ where: { id: uid } });
    if (!u) return null;
    return { id: u.id, email: u.email, name: u.name, image: u.image };
  } catch {
    return null;
  }
}

function isHttps(req: NextRequest): boolean {
  const proto = (req.headers.get('x-forwarded-proto') || '').split(',')[0].trim();
  if (proto) return proto === 'https';
  try {
    return new URL(req.url).protocol === 'https:';
  } catch {
    return false;
  }
}

export function setSessionCookie(res: NextResponse, token: string, req?: NextRequest) {
  const https = req ? isHttps(req) : process.env.NODE_ENV === 'production';
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    // HTTPS (qua proxy preview) → None+Secure để cookie sống trong iframe;
    // HTTP nội bộ (localhost) → lax
    sameSite: https ? 'none' : 'lax',
    secure: https,
    maxAge: MAX_AGE,
    path: '/',
  });
}

export function clearSessionCookie(res: NextResponse, req?: NextRequest) {
  const https = req ? isHttps(req) : process.env.NODE_ENV === 'production';
  res.cookies.set(COOKIE_NAME, '', {
    httpOnly: true,
    sameSite: https ? 'none' : 'lax',
    secure: https,
    maxAge: 0,
    path: '/',
  });
}

// ================== Mật khẩu (scrypt, không dependency ngoài) ==================

const SCRYPT_N = 16384; // 2^14
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEY_LEN = 64;

/** Băm mật khẩu → "salt:hash" (hex) */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, KEY_LEN, { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P });
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

/** So khớp mật khẩu với bản băm — hằng thời gian, an toàn thứ tự byte */
export function verifyPassword(password: string, stored: string | null | undefined): boolean {
  if (!stored) return false;
  const [saltHex, hashHex] = stored.split(':');
  if (!saltHex || !hashHex) return false;
  try {
    const salt = Buffer.from(saltHex, 'hex');
    const expected = Buffer.from(hashHex, 'hex');
    const actual = crypto.scryptSync(password, salt, expected.length, {
      N: SCRYPT_N,
      r: SCRYPT_R,
      p: SCRYPT_P,
    });
    return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export function validatePasswordStrength(pw: unknown): string | null {
  const s = String(pw || '');
  if (s.length < 6) return 'Mật khẩu cần tối thiểu 6 ký tự';
  if (s.length > 100) return 'Mật khẩu quá dài (tối đa 100 ký tự)';
  if (/\s/.test(s)) return 'Mật khẩu không được chứa khoảng trắng';
  return null;
}

export function normalizeEmail(e: unknown): string {
  return String(e || '').trim().toLowerCase();
}

export function isValidEmail(e: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}

/** Nhận/chưa nhận Google OAuth */
export function googleConfigured(): boolean {
  return !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

/** Origin công khai của app (đằng sau proxy) */
export function appOrigin(req: NextRequest): string {
  const proto = req.headers.get('x-forwarded-proto') || new URL(req.url).protocol.replace(':', '');
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host') || new URL(req.url).host;
  return `${proto}://${host}`;
}

/** Upsert user + nhận các phiên ẩn danh vào tài khoản (đồng bộ mọi thiết bị) */
export async function loginOrRegister(profile: {
  email: string;
  name: string;
  image?: string | null;
  googleId?: string | null;
  passwordHash?: string | null;
}): Promise<SessionUser> {
  const email = profile.email.trim().toLowerCase();
  let user = await db.user.findUnique({ where: { email } });
  if (!user && profile.googleId) {
    user = await db.user.findUnique({ where: { googleId: profile.googleId } });
  }
  if (user) {
    user = await db.user.update({
      where: { id: user.id },
      data: {
        name: profile.name || user.name,
        image: profile.image || user.image,
        googleId: profile.googleId || user.googleId,
        passwordHash: profile.passwordHash || user.passwordHash,
      },
    });
  } else {
    user = await db.user.create({
      data: {
        email,
        name: profile.name || email.split('@')[0],
        image: profile.image || null,
        googleId: profile.googleId || null,
        passwordHash: profile.passwordHash || null,
      },
    });
  }
  // Nhận các phiên chat tạo trước khi đăng nhập về tài khoản này
  await db.chatSession.updateMany({ where: { userId: null }, data: { userId: user.id } });
  return { id: user.id, email: user.email, name: user.name, image: user.image };
}
