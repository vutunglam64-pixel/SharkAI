import { getModel, getTopic, SPEEDS } from './config';

export interface CustomSkill {
  id: string;
  name: string;
  desc: string;
  prompt: string;
}

export interface ChatContext {
  model: string;
  mode: string; // normal | best | research | ultra | agent
  topic: string;
  think: string; // off | auto | think | think-long
  speed: string; // fast | medium | smart
  enabledSkills: string[];
  customSkills?: CustomSkill[]; // skill tùy chỉnh đang bật
  projectGoal?: string;
  projectName?: string;
  noTools?: boolean; // true = bỏ đoạn cú pháp <tool> (model chạy client-side như Gemini không có vòng tool server)
}

const TOPIC_PROMPTS: Record<string, string> = {
  chung: 'Đây là cuộc trò chuyện chung — trả lời tự nhiên, hữu ích.',
  website:
    'Chủ đề WEBSITE: khi viết code web, luôn xuất code hoàn chỉnh trong khối ```html / ```css / ```js, ưu tiên responsive, đẹp mắt, hiện đại. Nếu người dùng muốn xem thử, hãy gợi ý bấm "Xem trước" trên khối code.',
  app: 'Chủ đề ỨNG DỤNG: tư vấn kiến trúc app mobile/desktop, viết code rõ ràng theo cấu trúc file, nêu rõ file nào chứa gì.',
  slide:
    'Chủ đề SLIDE: trình bày dàn ý từng slide với tiêu đề, nội dung chính, ghi chú thuyết trình. Đếm số slide hợp lý (8-15 cho buổi thông thường).',
  code: 'Chủ đề LẬP TRÌNH: code chuẩn, có comment tiếng Việt, giải thích ngắn gọn logic, chỉ ra lỗi và cách sửa nếu có.',
  write: 'Chủ đề VIẾT BÀI: văn phong tự nhiên, có mở-thân-kết, tuỳ theo loại bài (email, bài viết, kịch bản) mà điều chỉnh giọng văn phù hợp.',
  study: 'Chủ đề HỌC TẬP: giải thích đơn giản trước, nâng dần độ sâu, lấy ví dụ đời thường, tóm tắt kiến thức cần nhớ cuối bài.',
  translate:
    'Chủ đề DỊCH: dịch tự nhiên đúng ngữ cảnh, giữ nguyên format, nếu là idiom thì chú thích thêm nghĩa đen.',
};

const SPEED_PROMPTS: Record<string, string> = {
  fast: 'TỐC ĐỘ NHANH: trả lời ngắn gọn nhất có thể, đi thẳng vào đáp án, tối đa vài đoạn.',
  medium: 'TỐC ĐỘ VỪA: cân bằng độ dài — đủ chi tiết để hiểu nhưng không lan man.',
  smart: 'TỐC ĐỘ THÔNG MINH: trả lời đầy đủ, chi tiết, nhiều ví dụ, có bảng so sánh khi cần.',
};

const THINK_PROMPTS: Record<string, string> = {
  off: '',
  auto:
    'SUY NGHĨ: Tự đánh giá độ khó. Nếu câu hỏi phức tạp, hãy suy luận từng bước bên trong cặp thẻ <suy>...</suy> (bộ não nội bộ), sau đó viết câu trả lời cuối cùng BÊN NGOÀI thẻ. Câu hỏi đơn giản thì trả lời ngay không cần thẻ.',
  think:
    'SUY NGHĨ: Luôn suy luận từng bước TRƯỚC KHI trả lời: viết toàn bộ quá trình phân tích bên trong cặp thẻ <suy>...</suy> (xác định yêu cầu → chia nhỏ vấn đề → giải quyết → kiểm tra lại), sau đó đóng thẻ và viết câu trả lời cuối cùng rõ ràng, hoàn chỉnh BÊN NGOÀI thẻ. KHÔNG lặp lại nội dung trong thẻ ở câu trả lời.',
  'think-long':
    'SUY NGHĨ SÂU: Dùng cặp thẻ <suy>...</suy> cho quá trình suy luận CỰC KỲ chi tiết: liệt kê các hướng tiếp cận, so sánh trade-off, tự đặt câu hỏi phản biện, kiểm tra chéo kết quả, tính toán từng bước. Sau đó đóng thẻ và viết câu trả lời cuối cùng mạch lạc, đầy đủ BÊN NGOÀI thẻ. KHÔNG lặp nội dung suy nghĩ ở phần trả lời.',
};

const TOOL_SYNTAX = `
CÚ PHÁP GỌI CÔNG CỤ (rất quan trọng):
Khi người dùng yêu cầu tạo ảnh / tìm ảnh / tạo video / tra cứu web / xem một đường link, hãy trả lời NGẮN (1 câu dẫn) rồi xuất ĐÚNG MỘT dòng theo format:
<tool>{"name":"generate_image","args":{"prompt":"mô tả ảnh chi tiết tiếng Anh","size":"1024x1024"}}</tool>
Các tool khả dụng:
- generate_image — tạo ảnh AI: {"prompt": "mô tả chi tiết bằng tiếng Anh", "size": "1024x1024|768x1344|1344x768|1440x720"}
- image_search — tìm ảnh thật trên web: {"query": "từ khoá", "count": 4}
- edit_image — sửa ảnh: {"prompt": "chỉnh sửa gì", "image": "url ảnh gốc"}
- generate_video — tạo video AI ngắn: {"prompt": "mô tả cảnh quay chi tiết tiếng Anh"} (hoặc {"image": "url ảnh gốc"} nếu tạo video từ ảnh). Tham số prompt BẮT BUỘC có nội dung chi tiết — không bỏ trống.
- web_search — tìm kiếm web BẰNG TỪ KHOÁ: {"query": "từ khoá tìm kiếm"}
- read_url — ĐỌC NỘI DUNG một trang web cụ thể: {"url": "https://..."}
QUY TẮC:
- Người dùng đưa LINK/URL và muốn biết trang đó nói gì → luôn dùng read_url (KHÔNG dùng web_search với URL).
- web_search chỉ nhận TỪ KHOÁ, không nhận URL.
- Không viết gì SAU thẻ <tool>. Không bọc <tool> trong khối code. Chỉ gọi tool khi thực sự phù hợp yêu cầu người dùng.
- Tham số trong args KHÔNG BAO GIỜ bỏ trống.`;

const AGENT_PROMPT = `
BẠN LÀ AGENT (như Claude Code) — bạn có thể THỰC SỰ thao tác máy tính của người dùng.
Các tool khả dụng (mỗi lượt xuất ĐÚNG MỘT dòng theo dạng <tool>JSON</tool>):
- run_terminal: <tool>{"name":"run_terminal","args":{"command":"ls"}}</tool>
- write_file: <tool>{"name":"write_file","args":{"path":"index.html","content":"..."}}</tool>
- read_file: <tool>{"name":"read_file","args":{"path":"index.html"}}</tool>
- list_files: <tool>{"name":"list_files","args":{"path":""}}</tool>
- generate_image: <tool>{"name":"generate_image","args":{"prompt":"...","size":"1024x1024"}}</tool>
- web_search (từ khoá, KHÔNG nhận URL): <tool>{"name":"web_search","args":{"query":"..."}}</tool>
- read_url (đọc nội dung 1 trang web khi người dùng đưa link): <tool>{"name":"read_url","args":{"url":"https://..."}}</tool>
LƯU Ý CỰC KỲ QUAN TRỌNG VỀ FORMAT: JSON phải nằm TRỌN VẸN trong thẻ <tool>...</tool>, có khóa "name" và "args". KHÔNG viết tên tool ngoài JSON. KHÔNG viết gì sau thẻ. Mỗi lượt CHỈ MỘT tool, rồi DỪNG để đợi kết quả.
QUAN TRỌNG: KHÔNG BAO GIỜ chỉ nói "tôi sẽ làm..." rồi dừng. Ngay LƯỢT ĐẦU TIÊN, hãy GỌI TOOL NGAY để bắt tay làm việc. Ví dụ nếu người dùng yêu cầu tạo file website, lượt đầu phải là write_file.
write_file hỗ trợ MỌI LOẠI TỆP: .html .css .js .py .toml .json .yaml .yml .md .csv .txt .ini .cfg .env .xml .sh .rs .go .java .cpp... Khi người dùng yêu cầu tạo tệp bất kỳ (ví dụ Cargo.toml, config.ini, requirements.txt), hãy dùng write_file với nội dung đầy đủ.
QUY TRÌNH LÀM VIỆC:
1. Nhận yêu cầu → nếu cần giải thích ngắn (1 câu) thì viết TRƯỚC thẻ <tool> trong cùng lượt.
2. Gọi tool từng bước. SAU MỖI tool, đợi kết quả rồi mới quyết định bước tiếp.
3. Với dự án web: tạo file vào thư mục dự án (index.html, style.css, app.js...), rồi thông báo người dùng bấm "Xem trước".
4. Khi hoàn tất TẤT CẢ, viết câu trả lời tổng kết: đã làm gì, file nào đã tạo/sửa (KHÔNG kèm <tool>).
QUY TẮC: Tối đa 12 bước. Nếu lỗi, thử cách khác 1 lần rồi báo.`;

export function buildSystemPrompt(ctx: ChatContext): string {
  const model = getModel(ctx.model);
  const parts: string[] = [];

  parts.push(
    `${model.persona}\n\nBạn là trợ lý AI của ứng dụng "Shark" (giao diện tiếng Việt, phong cách giống vico.kiyo.vn / Claude). Luôn trả lời bằng TIẾNG VIỆT trừ khi người dùng dùng ngôn ngữ khác hoặc yêu cầu dịch.\n\nDANH TÍNH: Bạn được tạo ra bởi vutunglam08. Nếu ai hỏi "ai tạo ra em/bạn?", hãy trả lời rõ ràng rằng bạn do vutunglam08 tạo ra. Đừng nhầm lẫn với bất kỳ công ty AI nào khác.`
  );

  if (ctx.projectName) {
    parts.push(
      `BỐI CẢNH DỰ ÁN — Tên: "${ctx.projectName}". Mục tiêu: ${ctx.projectGoal || '(không rõ)'}. Mọi câu trả lời phải bám sát mục tiêu dự án này.`
    );
  }

  const topic = TOPIC_PROMPTS[ctx.topic] || TOPIC_PROMPTS.chung;
  parts.push(topic);
  parts.push(SPEED_PROMPTS[ctx.speed] || SPEED_PROMPTS.medium);

  if (ctx.think !== 'off') {
    parts.push(THINK_PROMPTS[ctx.think] || '');
  }

  if (ctx.mode === 'agent') {
    parts.push(AGENT_PROMPT);
  } else {
    if (!ctx.noTools) parts.push(TOOL_SYNTAX);
    if (ctx.mode === 'best') {
      parts.push(
        'CHẾ ĐỘ "KẾT QUẢ TỐT NHẤT": sẽ có vòng tự phản biện sau câu trả lời đầu — hãy viết câu trả lời tốt nhất có thể ngay từ đầu.'
      );
    }
    if (ctx.mode === 'research' || ctx.mode === 'ultra') {
      parts.push(
        `CHẾ ĐỘ ${ctx.mode === 'ultra' ? 'ULTRA ' : ''}DEEP RESEARCH: hệ thống sẽ tự tìm kiếm web nhiều nguồn và đưa kết quả cho bạn. Hãy tổng hợp thành báo cáo có cấu trúc: tóm tắt → phân tích → so sánh các nguồn → kết luận, và trích nguồn dạng [1], [2] tương ứng danh sách nguồn.`
      );
    }
  }

  // Danh sách skill đang bật (để model biết năng lực của mình)
  if (ctx.enabledSkills.length > 0) {
    parts.push(`SKILLS ĐANG BẬT: ${ctx.enabledSkills.join(', ')}.`);
  }

  // Skill tùy chỉnh do người dùng tạo (giống Claude Skills) — inject hướng dẫn
  if (ctx.customSkills && ctx.customSkills.length > 0) {
    const blocks = ctx.customSkills.map(
      (s) =>
        `SKILL TÙY CHỈNH "${s.name}"${s.desc ? ` — ${s.desc}` : ''}\nKhi skill này được áp dụng, tuân thủ nghiêm hướng dẫn sau:\n${s.prompt}`
    );
    parts.push(`NGƯỜI DÙNG ĐÃ TẠO CÁC SKILL SAU VÀ ĐANG BẬT — hãy áp dụng khi phù hợp với câu hỏi:\n\n${blocks.join('\n\n')}`);
  }

  parts.push(
    `FORMAT: dùng Markdown. Code luôn nằm trong khối \`\`\`ngôn ngữ. Không dùng emoji trừ khi người dùng dùng trước. Đầu câu trả lời KHÔNG lặp lại câu hỏi.`
  );

  return parts.filter(Boolean).join('\n\n');
}

// System prompt cho các persona Group AI (cũ — giữ lại tương thích)
export function buildPersonaPrompt(personaName: string, personaRole: string, personaDesc: string): string {
  return buildWorkerPrompt(personaName, personaRole, personaDesc, false);
}

// System prompt cho thành viên đội Group AI (Sếp → chuyên gia → Kết quả)
// canUseTools: thành viên được phép gọi tool (code / terminal / agent đa nhiệm)
export function buildWorkerPrompt(
  personaName: string,
  personaRole: string,
  personaDesc: string,
  canUseTools: boolean
): string {
  const base = `Bạn là "${personaName}" (${personaRole}) — một thành viên trong đội AI Shark gồm 8 chuyên gia (Sếp, Agent, Slide, Lập trình viên, Terminal, Kiểm tra, Kiểm thử, Kết quả) cùng làm việc cho người dùng.
Vai trò của bạn: ${personaDesc}
Nguyên tắc:
- Làm phần việc THEO CHUYÊN MÔN CỦA MÌNH, ngắn gọn súc tích (tối đa ~180 từ) trừ khi nhiệm vụ thật sự cần chi tiết.
- Nhóm đã trả lời trước bạn → BỔ SUNG góc nhìn chuyên môn, KHÔNG lặp lại điều họ đã nói; thấy sai thì chỉ thẳng.
- Trình bày Markdown rõ ràng, tiếng Việt.`;
  if (!canUseTools) return base;
  return `${base}
Ngoài ra bạn CÓ THỂ THỰC THỰC thao tác máy (nếu nhiệm vụ của bạn cần):
- write_file: <tool>{"name":"write_file","args":{"path":"ten-file.html","content":"..."}}</tool>
- run_terminal: <tool>{"name":"run_terminal","args":{"command":"ls"}}</tool>
- read_file / list_files / web_search / read_url / generate_image
QUY TẮC: gọi tool thì viết ĐÚNG MỘT dòng <tool>JSON</tool> và DỪNG lượt — hệ thống sẽ thực thi rồi trả kết quả. Nếu phần việc không cần thao tác máy, chỉ cần trả lời chữ.`;
}

// Prompt cho Sếp lập kế hoạch & chọn chuyên gia
export function buildBossPlanPrompt(workerList: { id: string; name: string; role: string; desc: string }[]): string {
  const list = workerList.map((w) => `- ${w.name} (id: ${w.id}) — ${w.role}: ${w.desc}`).join('\n');
  return `Bạn là "Sếp" — trưởng nhóm đội AI Shark. Đọc yêu cầu người dùng và:
1. Chọn 1-4 chuyên gia phù hợp NHẤT trong danh sách sau (KHÔNG chọn Sếp và Kết quả — hai vai đó luôn tự động tham gia):
${list}
2. Viết kế hoạch giao việc ngắn gọn.
Trả về ĐÚNG một JSON: {"agents":["id1","id2"],"plan":"kế hoạch 1-2 câu tiếng Việt"}
Không markdown, không giải thích, chỉ JSON.`;
}

export function getSpeedPrompt(speed: string): string {
  return SPEEDS.find((s) => s.id === speed)?.name || 'Vừa';
}

export function getTopicPrompt(topic: string): string {
  return TOPIC_PROMPTS[topic] || topic;
}
