import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import crypto from 'crypto';
import getZAI from './zai';
import { WORKSPACE_ROOT, UPLOAD_ROOT, ensureWorkspace, isTextFile } from './workspace';

export interface ToolCall {
  name: string;
  args: Record<string, unknown>;
}

export interface ToolResult {
  ok: boolean;
  data: unknown; // tuỳ tool
  display: string; // text hiển thị trong UI
  retryable?: boolean; // lỗi do thiếu tham số → model có thể gọi lại đúng format
}

// Lấy giá trị chuỗi đầu tiên khác rỗng từ nhiều tên biến thể của cùng 1 tham số
// (model hay viết "description" thay cho "prompt", "q" thay cho "query"...)
function strArg(args: Record<string, unknown>, keys: string[]): string {
  for (const k of keys) {
    const v = args[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
    if (typeof v === 'number' && !Number.isNaN(v)) return String(v);
  }
  return '';
}

// Có vẻ là đường link? (http(s)://... hoặc tenmien/duong-dan không có dấu cách)
function isProbablyUrl(s: string): boolean {
  const t = String(s || '').trim();
  if (!t || t.includes(' ')) return false;
  if (/^https?:\/\/\S+$/i.test(t)) return true;
  return /^[\w-]+(\.[\w-]+)+(\/\S*)?$/i.test(t) && /\.[a-z]{2,}/i.test(t);
}

// Tool thiếu tham số bắt buộc → trả lỗi kèm HƯỚNG DẪN model gọi lại đúng
function missingArg(name: string, arg: string, hint: string, example?: string): ToolResult {
  return {
    ok: false,
    retryable: true,
    data: { type: 'error', error: `thiếu "${arg}"` },
    display: `LỖI: ${name} KHÔNG THỰC THI vì thiếu tham số "${arg}" (${hint}). Gọi lại NGAY đúng format: <tool>{"name":"${name}","args":{"${arg}":"${example || 'giá trị đầy đủ'}"}}</tool> — rồi dừng, không viết gì sau thẻ.`,
  };
}

// Trích tool call từ text — chấp nhận nhiều biến thể:
//   <tool>{"name":"write_file","args":{...}}</tool>          (chuẩn)
//   <tool>write_file {"path": ...}</tool>                     (tên tool + JSON)
//   <tool>write_file</tool> <tool>{"name":...}</tool>          (tag rác + tag chuẩn)
//   <tool>write_file</tool> <tool>{"path": ...}</tool>          (tag tên + tag args)
// Sửa JSON lỗi: model thường để xuống dòng thô (không escape) bên trong chuỗi
// content — hàm này escape lại đúng chuẩn rồi mới parse.
function repairJson(s: string): string {
  let out = '';
  let inStr = false;
  let esc = false;
  for (const ch of s) {
    if (inStr) {
      if (esc) {
        out += ch;
        esc = false;
        continue;
      }
      if (ch === '\\') {
        out += ch;
        esc = true;
        continue;
      }
      if (ch === '"') {
        inStr = false;
        out += ch;
        continue;
      }
      if (ch === '\n') {
        out += '\\n';
        continue;
      }
      if (ch === '\r') {
        out += '\\r';
        continue;
      }
      if (ch === '\t') {
        out += '\\t';
        continue;
      }
      out += ch;
      continue;
    }
    if (ch === '"') {
      inStr = true;
      out += ch;
      continue;
    }
    out += ch;
  }
  return out;
}

function parseJsonLoose(raw: string): Record<string, unknown> | null {
  const m = raw.match(/\{[\s\S]*\}/);
  if (!m) return null;
  const candidates = [m[0], repairJson(m[0])];
  for (const c of candidates) {
    try {
      const j = JSON.parse(c);
      if (j && typeof j === 'object') return j as Record<string, unknown>;
    } catch {}
  }
  return null;
}

// Unescape chuỗi kiểu JSON mà model hay nhét vào pseudo-XML (" → ", \n → xuống dòng)
function maybeUnescape(s: string): string {
  if (!s.includes('\\"')) return s;
  return s
    .replace(/\\\\/g, '\\')
    .replace(/\\"/g, '"')
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\\t/g, '\t');
}

export function extractToolCall(text: string): { tool?: ToolCall; textBefore: string } {
  const firstIdx = text.indexOf('<tool>');
  if (firstIdx < 0) return { textBefore: text };
  const before = text.slice(0, firstIdx).trim();

  // thu thập nội dung tất cả các tag ĐÃ ĐÓNG
  const re = /<tool>([\s\S]*?)<\/tool>/g;
  const tags: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    tags.push(m[1].replace(/```[a-zA-Z]*\n?/g, '').trim());
  }
  // <tool> KHÔNG ĐÓNG (model hay quên </tool>): lấy từ mỗi <tool> tới <tool> kế tiếp hoặc cuối văn bản
  if (tags.length === 0) {
    const starts: number[] = [];
    let si = firstIdx;
    while (si >= 0) {
      starts.push(si);
      si = text.indexOf('<tool>', si + 6);
    }
    for (let i = 0; i < starts.length; i++) {
      const end = i + 1 < starts.length ? starts[i + 1] : text.length;
      tags.push(text.slice(starts[i] + 6, end).replace(/```[a-zA-Z]*\n?/g, '').trim());
    }
  }
  if (tags.length === 0) return { textBefore: before };

  const lenientJson = (raw: string): Record<string, unknown> | null => parseJsonLoose(raw);

  const parseTag = (raw: string): ToolCall | null => {
    // 1) JSON chuẩn (hoặc đã repair) có name
    const j = parseJsonLoose(raw);
    if (j) {
      const name = String((j as { name?: unknown }).name || (j as { tool?: unknown }).tool || (j as { function?: unknown }).function || '');
      if (name) {
        return {
          name,
          args: ((j as { args?: unknown }).args || (j as { arguments?: unknown }).arguments || (j as { parameters?: unknown }).parameters || {}) as Record<string, unknown>,
        };
      }
      // JSON hợp lệ nhưng chỉ là args thuần (không có name) → trả args để ghép với tag tên kế bên
      return { name: '', args: j };
    }
    const m2 = raw.match(/^([\w.-]+)\s*[:\n]?\s*(\{[\s\S]*\})\s*$/);
    if (m2) {
      try {
        return { name: m2[1], args: JSON.parse(m2[2]) as Record<string, unknown> };
      } catch {}
    }
    // 3) chỉ có tên tool
    if (/^[\w.-]+$/.test(raw)) return { name: raw, args: {} };
    return null;
  };

  const parsed = tags.map(parseTag);

  // 4) tìm tool hoàn chỉnh (có args)
  for (const t of parsed) {
    if (t && t.name && Object.keys(t.args).length > 0) return { tool: t, textBefore: before };
  }

  // 4b) XML style: <tool><write_file><path>..</path><content>..</content></write_file></tool>
  const argsFromXml = (inner: string, name: string): Record<string, unknown> | null => {
    const known: Record<string, string[]> = {
      write_file: ['path', 'content'],
      read_file: ['path', 'file'],
      run_terminal: ['command', 'cmd'],
      list_files: ['path'],
      generate_image: ['prompt', 'size'],
      web_search: ['query'],
      generate_video: ['prompt', 'image'],
      image_search: ['query', 'count'],
      edit_image: ['prompt', 'image'],
      read_url: ['url'],
      open_url: ['url'],
      page_reader: ['url'],
      fetch_url: ['url'],
      web_fetch: ['url'],
    };
    const fields = known[name] || [];
    const args: Record<string, unknown> = {};
    for (const f of fields) {
      // mở thẻ cho phép có attribute: <content type="html">
      const re = new RegExp(`<${f}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${f}>`, 'i');
      const m = inner.match(re);
      if (m) args[f] = maybeUnescape(m[1]);
    }
    // write_file mà thiếu content là vô dụng — trả null để các parser sau (4c) thử lấy content kiểu khác
    if (name === 'write_file' && (args.content === undefined || String(args.content).trim() === '')) return null;
    if (Object.keys(args).length > 0) return args;
    return null;
  };
  for (const rawTag of tags) {
    const xm = rawTag.match(/<([\w.-]+)>([\s\S]*)<\/\1>/);
    if (xm && !['suy', 'think', 'tool'].includes(xm[1])) {
      const args = argsFromXml(xm[2], xm[1]);
      if (args) return { tool: { name: xm[1], args }, textBefore: before };
    }
  }

  // 4c) pseudo-XML: <tool><write_file><path>x</path>content="...html đa dòng..."</tool>
  //     (content dạng attribute, không có thẻ đóng — model hay mắc lỗi này)
  for (const rawTag of tags) {
    const nm = rawTag.match(/^\s*<([\w.-]+)>/);
    if (!nm || ['suy', 'think', 'tool'].includes(nm[1])) continue;
    const name = nm[1];
    const inner = rawTag.replace(/^\s*<[\w.-]+>/, '').trim();
    const args: Record<string, unknown> = {};
    // các field ngắn dạng <field>value</field> (cho phép thẻ có attribute)
    for (const f of ['path', 'file', 'command', 'cmd', 'prompt', 'size', 'query', 'image', 'count', 'url', 'link', 'image_url']) {
      const re = new RegExp(`<${f}(?:\\s[^>]*)?>([^<]*)<\\/${f}>`, 'i');
      const fm = inner.match(re);
      if (fm) args[f] = fm[1].trim();
    }
    // content: 1) thẻ <content>...</content> (chấp nhận content> thiếu dấu <), 2) attribute content="...", 3) fallback sau </path>
    const ctag = inner.match(/(?:<|\b)content(?:\s[^>]*)?>([\s\S]*?)<\/content>/i);
    if (ctag && ctag[1].trim()) {
      args.content = maybeUnescape(ctag[1]);
    } else {
      const cm = inner.match(/\bcontent\s*=\s*"([\s\S]*)"\s*$/);
      if (cm) {
        args.content = maybeUnescape(cm[1]);
      } else if (name === 'write_file') {
        // fallback: mọi thứ sau thẻ path/file chính là content
        const pm = inner.match(/<\/(?:path|file)>\s*([\s\S]*)$/);
        if (pm && pm[1].trim()) {
          let val = pm[1].trim();
          val = val.replace(/^(content\s*=\s*)?"/, '').replace(/"\s*$/, '');
          args.content = maybeUnescape(val);
        }
      }
    }
    if (Object.keys(args).length > 0) return { tool: { name, args }, textBefore: before };
  }

  // 5) ghép tag chỉ-tên với tag JSON kế tiếp, hoặc tag-args thuần với tag tên
  for (let i = 0; i < tags.length; i++) {
    const t = parsed[i];
    if (t && !t.name && Object.keys(t.args).length > 0) {
      // args thuần — tìm tên tool ở tag trước hoặc sau
      const prev = parsed[i - 1];
      if (prev && prev.name && Object.keys(prev.args).length === 0) return { tool: { name: prev.name, args: t.args }, textBefore: before };
      const jm = tags[i].match(/"(?:name|tool)"\s*:\s*"([\w.-]+)"/);
      if (jm) return { tool: { name: jm[1], args: t.args }, textBefore: before };
    }
    if (t && t.name && Object.keys(t.args).length === 0) {
      for (let j = i + 1; j < tags.length; j++) {
        const obj = lenientJson(tags[j]);
        if (obj) {
          const innerName = String((obj as { name?: unknown }).name || '');
          const args = ((obj as { args?: unknown }).args || obj) as Record<string, unknown>;
          return { tool: { name: innerName || t.name, args }, textBefore: before };
        }
      }
      // không có JSON đi kèm — trả tool không args (vd list_files)
      return { tool: t, textBefore: before };
    }
  }

  return { textBefore: before };
}

const BLOCKED_PATTERNS: RegExp[] = [
  /rm\s+-rf?\s+\/(?:\s|$)/,
  /rm\s+-rf?\s+\/home/,
  /rm\s+-rf\s+\*\s*$/,
  /sudo/,
  /shutdown/,
  /reboot/,
  /mkfs/,
  /:\(\)\s*\{.*\}\s*;/,
  /\bdsync\b/,
  /dd\s+if=/,
  />\s*\/dev\/sd[a-z]/,
  /chmod\s+-R\s+777\s+\//,
  /curl[^|]*\|\s*(ba)?sh/,
  /wget[^|]*\|\s*(ba)?sh/,
  /rm[^;|&]*\/home\/z\/my-project\/(src|node_modules|prisma|db|\.zscripts|mini-services)/,
];

export function isCommandBlocked(command: string): boolean {
  return BLOCKED_PATTERNS.some((p) => p.test(command));
}

export function runTerminal(command: string, timeoutMs = 30000): Promise<{ stdout: string; stderr: string; code: number | null; blocked?: boolean }> {
  ensureWorkspace();
  if (isCommandBlocked(command)) {
    return Promise.resolve({
      stdout: '',
      stderr: '⛔ Lệnh bị chặn vì lý do an toàn (không thể phá hủy hệ thống).',
      code: 126,
      blocked: true,
    });
  }
  return new Promise((resolve) => {
    exec(
      command,
      { cwd: WORKSPACE_ROOT, timeout: timeoutMs, maxBuffer: 512 * 1024, shell: '/bin/bash' },
      (error, stdout, stderr) => {
        resolve({
          stdout: (stdout || '').toString().slice(0, 20000),
          stderr: (stderr || '').toString().slice(0, 20000),
          code: error ? ((error as { code?: number }).code ?? 1) : 0,
        });
      }
    );
  });
}

export function writeFileWs(relPath: string, content: string): { ok: boolean; error?: string } {
  ensureWorkspace();
  const clean = (relPath || '').replace(/^[/\\]+/, '').replace(/\.\./g, '');
  if (!clean) return { ok: false, error: 'Đường dẫn không hợp lệ' };
  const abs = path.join(WORKSPACE_ROOT, clean);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content || '');
  return { ok: true };
}

export function readFileWs(relPath: string): { ok: boolean; content?: string; error?: string } {
  const abs = path.join(WORKSPACE_ROOT, relPath.replace(/\.\./g, ''));
  if (!fs.existsSync(abs) || !fs.statSync(abs).isFile()) {
    return { ok: false, error: `Không tìm thấy file: ${relPath}` };
  }
  const content = fs.readFileSync(abs, 'utf-8');
  return { ok: true, content: content.slice(0, 60000) };
}

export function saveUploadFile(buffer: Buffer, originalName: string): string {
  ensureWorkspace();
  const ext = path.extname(originalName) || '';
  const id = crypto.randomBytes(8).toString('hex');
  const name = `${Date.now()}-${id}${ext}`;
  fs.writeFileSync(path.join(UPLOAD_ROOT, name), buffer);
  return name; // path tương đối trong upload/
}

export async function generateImage(prompt: string, size = '1024x1024'): Promise<{ url: string; fileName: string }> {
  const zai = await getZAI();
  const validSizes = ['1024x1024', '768x1344', '864x1152', '1344x768', '1152x864', '1440x720', '720x1440'];
  const finalSize = validSizes.includes(size) ? size : '1024x1024';
  const response = await zai.images.generations.create({ prompt, size: finalSize as '1024x1024' });
  const base64 = response?.data?.[0]?.base64;
  if (!base64) throw new Error('Không tạo được ảnh (phản hồi trống)');
  const buf = Buffer.from(base64, 'base64');
  // phát hiện định dạng thật từ magic bytes (API trả JPEG nhưng trước đây lưu .png)
  const isJpg = buf[0] === 0xff && buf[1] === 0xd8;
  const fileName = saveUploadFile(buf, `gen-${Date.now()}.${isJpg ? 'jpg' : 'png'}`);
  return { url: `/api/asset/${fileName}`, fileName };
}

export async function editImage(prompt: string, imageUrl: string): Promise<{ url: string; fileName: string }> {
  const zai = await getZAI();
  // nếu là url nội bộ → đọc file chuyển base64
  let image = imageUrl;
  if (imageUrl.startsWith('/api/asset/')) {
    const name = imageUrl.replace('/api/asset/', '');
    const abs = path.join(UPLOAD_ROOT, name);
    if (fs.existsSync(abs)) {
      const b64 = fs.readFileSync(abs).toString('base64');
      image = `data:image/png;base64,${b64}`;
    }
  }
  const response = await zai.images.generations.edit({ prompt, image, size: '1024x1024' });
  const base64 = response?.data?.[0]?.base64;
  if (!base64) throw new Error('Không sửa được ảnh (phản hồi trống)');
  const buf = Buffer.from(base64, 'base64');
  const isJpg = buf[0] === 0xff && buf[1] === 0xd8;
  const fileName = saveUploadFile(buf, `edit-${Date.now()}.${isJpg ? 'jpg' : 'png'}`);
  return { url: `/api/asset/${fileName}`, fileName };
}

export async function imageSearch(query: string, count = 4) {
  const zai = await getZAI();
  const res = await zai.images.search.create({ query, count: Math.min(Math.max(count, 1), 8) });
  if (!res?.success) throw new Error('Tìm ảnh thất bại');
  return (res.results || []).map((r: { original_url: string; caption?: string; source?: string }) => ({
    url: r.original_url,
    caption: r.caption || '',
    source: r.source || '',
  }));
}

export async function webSearch(query: string, num = 5) {
  const zai = await getZAI();
  const results = await zai.functions.invoke('web_search', { query, num });
  return (results || []).map((r: { url: string; name: string; snippet: string; host_name?: string; date?: string }) => ({
    url: r.url,
    name: r.name,
    snippet: r.snippet,
    host: r.host_name || '',
    date: r.date || '',
  }));
}

// HTML thô → text sạch (giữ xuống dòng theo khối, giải mã entity thường gặp)
function htmlToText(html: string): { title: string; text: string } {
  const tm = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  const title = tm ? tm[1].trim() : '';
  let t = html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ');
  t = t
    .replace(/<\/(p|div|li|h[1-6]|tr|td|section|article|header|footer|nav|blockquote|pre|table|ul|ol|dd|dt)>/gi, '\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&[a-z]+;/gi, ' ')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
  return { title, text: t };
}

// Đọc nội dung 1 trang web:
// 1) SDK page_reader (headless — đọc được trang render bằng JS)
// 2) fallback: fetch trực tiếp theo redirect (xử lý link rút gọn kiểu spoo.me/bit.ly)
export async function pageReader(url: string): Promise<{ title: string; text: string; url: string; finalUrl?: string }> {
  const clean = String(url || '').trim();
  const withProto = /^https?:\/\//i.test(clean) ? clean : `https://${clean}`;

  // --- 1) SDK page_reader ---
  try {
    const zai = await getZAI();
    const res = await zai.functions.invoke('page_reader', { url: withProto });
    const html = res?.data?.html || '';
    if (html && html.length > 150) {
      const parsed = htmlToText(html);
      const title = String(res?.data?.title || parsed.title || withProto).trim();
      if (parsed.text.length > 60) {
        return { title: title || withProto, text: parsed.text.slice(0, 12000), url: withProto };
      }
    }
  } catch {
    /* thử cách 2 bên dưới */
  }

  // --- 2) fetch trực tiếp theo redirect ---
  try {
    const r = await fetch(withProto, {
      redirect: 'follow',
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
        'Accept-Language': 'vi,en;q=0.9',
      },
      signal: AbortSignal.timeout(20000),
    });
    const ct = r.headers.get('content-type') || '';
    const raw = await r.text();
    const finalUrl = r.url && r.url !== withProto ? r.url : undefined;
    if (ct.includes('json') || /^\s*[\[{].*[}\]]\s*$/.test(raw)) {
      return { title: withProto, text: raw.replace(/\s+/g, ' ').slice(0, 12000), url: withProto, finalUrl };
    }
    const parsed = htmlToText(raw);
    const text = parsed.text || raw.replace(/\s+/g, ' ');
    if (text.length < 20) {
      throw new Error('trả về rỗng (có thể cần JavaScript hoặc bị chặn bot)');
    }
    return { title: parsed.title || withProto, text: text.slice(0, 12000), url: withProto, finalUrl };
  } catch (e) {
    throw new Error(
      `Không đọc được trang "${withProto}" (có thể trang chặn bot, yêu cầu đăng nhập hoặc chỉ hiển thị khi chạy JavaScript). ${e instanceof Error ? e.message : ''}`.trim()
    );
  }
}

export async function createVideoTask(prompt: string, imageUrl?: string): Promise<string | null> {
  const zai = await getZAI();
  const p = (prompt || '').trim();
  const img = (imageUrl || '').trim();
  // API trả 400 "prompt và image_url không thể đồng thời trống" nếu cả hai bỏ trống
  if (!p && !img) {
    throw new Error('Thiếu mô tả video (prompt) hoặc ảnh gốc (image) — không thể tạo video');
  }
  const body: { quality: 'speed'; with_audio: boolean; prompt?: string; image_url?: string } = {
    quality: 'speed',
    with_audio: true,
  };
  if (p) body.prompt = p;
  if (img) body.image_url = img;
  const res = await zai.video.generations.create(body);
  return res?.id || null;
}

export async function pollVideoTask(taskId: string) {
  const zai = await getZAI();
  const res = await zai.async.result.query(taskId);
  if (res?.task_status === 'SUCCESS') {
    const url = res?.video_result?.[0]?.url || res?.video_url || res?.url || '';
    return { status: 'done' as const, url };
  }
  if (res?.task_status === 'FAIL') return { status: 'fail' as const, url: '' };
  return { status: 'processing' as const, url: '' };
}

// Chuẩn hoá đường dẫn file do model xuất ra (bỏ /workspace/ prefix, slash đầu, ..)
function cleanWsPath(p: string): string {
  let s = String(p || '').trim().replace(/\\/g, '/');
  s = s.replace(/^\/+/, '');
  s = s.replace(/^workspace\//i, '');
  s = s.replace(/\.\./g, '');
  return s;
}

// Model hay viết sai/chuẩn hoá kiểu tên tool (writeFile, save_file, shell...) → map về tên chuẩn
const TOOL_ALIASES: Record<string, string> = {
  writefile: 'write_file', savefile: 'write_file', save: 'write_file', createfile: 'write_file',
  makefile: 'write_file', newfile: 'write_file', write: 'write_file',
  editfile: 'write_file', updatefile: 'write_file', applyfile: 'write_file',
  readfile: 'read_file', openfile: 'read_file', read: 'read_file', viewfile: 'read_file', cat: 'read_file',
  runterminal: 'run_terminal', terminal: 'run_terminal', runcommand: 'run_terminal', executecommand: 'run_terminal',
  exec: 'run_terminal', shell: 'run_terminal', bash: 'run_terminal', shellcommand: 'run_terminal',
  run: 'run_terminal', command: 'run_terminal', execute: 'run_terminal',
  listfiles: 'list_files', listdirectory: 'list_files', listdir: 'list_files', ls: 'list_files',
  list: 'list_files', readdir: 'list_files', tree: 'list_files', directorylisting: 'list_files',
  websearch: 'web_search', search: 'web_search', searchweb: 'web_search', searchinternet: 'web_search',
  internetsearch: 'web_search', onlinesearch: 'web_search', google: 'web_search',
  generateimage: 'generate_image', imagegen: 'generate_image', createimage: 'generate_image',
  texttoimage: 'generate_image', drawimage: 'generate_image', draw: 'generate_image',
  imagesearch: 'image_search', searchimage: 'image_search', findimage: 'image_search',
  searchimages: 'image_search', googleimages: 'image_search',
  editimage: 'edit_image', imageedit: 'edit_image', modifyimage: 'edit_image', inpaint: 'edit_image',
  generatevideo: 'generate_video', videogenerate: 'generate_video', videogentask: 'generate_video',
  createvideo: 'generate_video', makevideo: 'generate_video',
  // đọc URL / trang web
  readurl: 'read_url', pagereader: 'read_url', openurl: 'read_url', readpage: 'read_url',
  fetchurl: 'read_url', webfetch: 'read_url', readweb: 'read_url', readwebsite: 'read_url',
  visit: 'read_url', visiturl: 'read_url', browse: 'read_url', browseurl: 'read_url',
  geturl: 'read_url', viewurl: 'read_url', readlink: 'read_url', openlink: 'read_url',
  fetchpage: 'read_url', openpage: 'read_url', urlreader: 'read_url',
  url: 'read_url', link: 'read_url',
};

export function normalizeToolName(name: string): string {
  const key = String(name || '').trim().replace(/[\s_\-.]/g, '').toLowerCase();
  return TOOL_ALIASES[key] || String(name || '').trim();
}

// Thực thi 1 tool call — trả về ToolResult chuẩn hoá cho UI
export async function executeTool(tool: ToolCall): Promise<ToolResult> {
  const normalized: ToolCall = { ...tool, name: normalizeToolName(tool.name) };
  try {
    switch (normalized.name) {
      case 'generate_image': {
        const prompt = strArg(tool.args, ['prompt', 'description', 'text', 'mo_ta', 'content', 'image_prompt']);
        const size = strArg(tool.args, ['size', 'resolution']) || '1024x1024';
        if (!prompt) return missingArg('generate_image', 'prompt', 'mô tả ảnh chi tiết bằng tiếng Anh', 'a cute orange cat sitting on a windowsill');
        const r = await generateImage(prompt, size);
        return { ok: true, data: { type: 'image', url: r.url, prompt }, display: `Đã tạo ảnh: ${prompt}` };
      }
      case 'edit_image': {
        const prompt = strArg(tool.args, ['prompt', 'description', 'edit', 'text', 'mo_ta']);
        const image = strArg(tool.args, ['image', 'image_url', 'url', 'anh', 'img', 'src']);
        if (!image) return missingArg('edit_image', 'image', 'url/đường dẫn ảnh gốc cần sửa', '/api/asset/ten-file.png');
        const r = await editImage(prompt || 'chỉnh sửa ảnh theo yêu cầu', image);
        return { ok: true, data: { type: 'image', url: r.url, prompt }, display: `Đã sửa ảnh theo yêu cầu` };
      }
      case 'image_search': {
        const query = strArg(tool.args, ['query', 'q', 'keyword', 'keywords', 'text', 'tu_khoa', 'search']);
        if (!query) return missingArg('image_search', 'query', 'từ khoá tìm ảnh', 'mèo cute');
        const items = await imageSearch(query, Number(tool.args.count) || 4);
        return { ok: true, data: { type: 'image_search', items }, display: `Đã tìm thấy ${items.length} ảnh cho "${query}"` };
      }
      case 'generate_video': {
        const prompt = strArg(tool.args, ['prompt', 'description', 'video', 'video_prompt', 'scene', 'script', 'text', 'content', 'query', 'mo_ta']);
        const image = strArg(tool.args, ['image', 'image_url', 'anh', 'img']);
        // API trả 400 nếu cả prompt lẫn image_url đều rỗng → chặn trước, kèm hướng dẫn model gọi lại
        if (!prompt && !image) {
          return missingArg('generate_video', 'prompt', 'mô tả cảnh quay video chi tiết bằng tiếng Anh', 'a shark swimming through coral reef, cinematic, sun rays');
        }
        const taskId = await createVideoTask(prompt, image);
        if (!taskId) throw new Error('Không tạo được tác vụ video (API không trả về task id)');
        const label = prompt || `video tạo từ ảnh ${image}`;
        return { ok: true, data: { type: 'video_task', taskId, prompt: label, status: 'processing' }, display: `Đã gửi yêu cầu tạo video (task ${taskId}): ${label}. Video đang được tạo ở hậu trường — KHÔNG gọi lại tool, không cần chờ.` };
      }
      case 'read_url': {
        const url = strArg(tool.args, ['url', 'link', 'href', 'page', 'website', 'web', 'address', 'query', 'text', 'path', 'target']);
        if (!url) return missingArg('read_url', 'url', 'đường dẫn trang web cần đọc nội dung', 'https://example.com/bai-viet');
        if (!isProbablyUrl(url)) {
          return {
            ok: false,
            retryable: true,
            data: { type: 'error', error: 'url không hợp lệ' },
            display: `LỖI: read_url nhận "${url}" không phải đường dẫn web. Hãy gọi lại với url đầy đủ: <tool>{"name":"read_url","args":{"url":"https://..."}}</tool> hoặc dùng web_search với TỪ KHOÁ nếu muốn tra cứu thông tin.`,
          };
        }
        try {
          const page = await pageReader(url);
          const snippet = page.text.slice(0, 240).replace(/\s+/g, ' ');
          return {
            ok: true,
            data: {
              type: 'sources',
              sources: [{ url: page.finalUrl || page.url, name: page.title, snippet }],
            },
            display: `Đã đọc thành công trang "${page.title}"${page.finalUrl ? ` (link rút gọn dẫn tới ${page.finalUrl})` : ''}. Nội dung chính:\n\n${page.text.slice(0, 8000)}`,
          };
        } catch (e) {
          return {
            ok: false,
            retryable: true,
            data: { type: 'error', error: String(e) },
            display: `Không đọc được trang ${url}: ${e instanceof Error ? e.message : String(e)}\nHãy thử web_search với TỪ KHOÁ (không phải URL) về chủ đề trang đó: <tool>{"name":"web_search","args":{"query":"từ khoá"}}</tool>`,
          };
        }
      }
      case 'web_search': {
        // nhận biến thể tên tham số (model hay viết q/keyword/text thay cho query)
        const query = strArg(tool.args, ['query', 'q', 'keyword', 'keywords', 'search', 'tim_kiem', 'tu_khoa', 'text', 'content']);
        const urlArg = strArg(tool.args, ['url', 'link', 'href', 'page', 'website', 'address']);
        // model nhét URL vào web_search → TỰ CHUYỂN sang đọc trang trực tiếp
        // (trước đây query rỗng → API 422 "Invalid empty query")
        const url = isProbablyUrl(urlArg) ? urlArg : isProbablyUrl(query) ? query : '';
        if (url) {
          try {
            const page = await pageReader(url);
            const snippet = page.text.slice(0, 240).replace(/\s+/g, ' ');
            return {
              ok: true,
              data: {
                type: 'sources',
                sources: [{ url: page.finalUrl || page.url, name: page.title, snippet }],
              },
              display: `Người dùng đưa link nên tôi đã ĐỌC TRANG "${page.title}"${page.finalUrl ? ` (đích: ${page.finalUrl})` : ''} thay vì tìm kiếm. Nội dung chính:\n\n${page.text.slice(0, 8000)}`,
            };
          } catch (e) {
            return {
              ok: false,
              retryable: true,
              data: { type: 'error', error: String(e) },
              display: `Không đọc được trang ${url}: ${e instanceof Error ? e.message : String(e)}\nHãy thử lại với TỪ KHOÁ tìm kiếm: <tool>{"name":"web_search","args":{"query":"từ khoá về chủ đề"}}</tool>`,
            };
          }
        }
        if (!query) return missingArg('web_search', 'query', 'từ khoá tìm kiếm (KHÔNG phải URL)', 'tin tức AI mới nhất');
        const sources = await webSearch(query);
        return {
          ok: true,
          data: { type: 'sources', sources },
          display: `Đã tìm kiếm web "${query}" — ${sources.length} kết quả:\n${sources.map((s: { name: string; url: string; snippet: string }, i: number) => `[${i + 1}] ${s.name} (${s.url}): ${s.snippet}`).join('\n')}`,
        };
      }
      case 'run_terminal': {
        const command = String(tool.args.command || tool.args.cmd || '');
        const r = await runTerminal(command);
        return {
          ok: r.code === 0,
          data: { type: 'terminal', command, stdout: r.stdout, stderr: r.stderr, code: r.code },
          display: `$ ${command}\n${r.stdout || r.stderr || '(không có output)'}`,
        };
      }
      case 'write_file': {
        const p = cleanWsPath(String(tool.args.path || tool.args.file || ''));
        let content = String(tool.args.content ?? '');
        // Model đôi khi nhét nội dung vào key khác (text, html, code, body, value, data)
        if (!content) {
          for (const alt of ['text', 'html', 'code', 'body', 'value', 'data', 'file_content', 'nội_dung', 'noi_dung']) {
            const v = tool.args[alt];
            if (typeof v === 'string' && v.trim()) {
              content = v;
              break;
            }
            if (v && typeof v === 'object') {
              const s = JSON.stringify(v, null, 2);
              if (s && s.length > 4) {
                content = s.replace(/^"|"$/g, '');
                break;
              }
            }
          }
        }
        if (!p) return { ok: false, data: { type: 'error', error: 'Thiếu đường dẫn' }, display: 'Lỗi ghi file: thiếu đường dẫn (args.path)' };
        if (!content.trim()) {
          // KHÔNG ghi file rỗng — báo model gửi lại với content đầy đủ
          return {
            ok: false,
            data: { type: 'error', error: 'content rỗng', path: p },
            display: `LỖI: write_file cho "${p}" thiếu "content" (args chỉ có: ${Object.keys(tool.args).join(', ') || 'trống'}). Hãy gọi lại write_file với "content" chứa TOÀN BỘ nội dung file (HTML/code đầy đủ).`,
          };
        }
        const r = writeFileWs(p, content);
        return {
          ok: r.ok,
          data: { type: 'file', path: p, action: 'write' },
          display: r.ok ? `Đã tạo/ghi file: ${p}` : `Lỗi ghi file: ${r.error}`,
        };
      }
      case 'read_file': {
        const p = cleanWsPath(String(tool.args.path || tool.args.file || ''));
        const r = readFileWs(p);
        return {
          ok: r.ok,
          data: { type: 'file', path: p, action: 'read', content: r.content },
          display: r.ok ? `Nội dung ${p}:\n${(r.content || '').slice(0, 2000)}` : `Lỗi: ${r.error}`,
        };
      }
      case 'list_files': {
        const p = cleanWsPath(String(tool.args.path || ''));
        ensureWorkspace();
        const abs = path.join(WORKSPACE_ROOT, p.replace(/\.\./g, ''));
        const items = fs.existsSync(abs) ? fs.readdirSync(abs).filter((f) => !f.startsWith('.')) : [];
        return {
          ok: true,
          data: { type: 'file_list', path: p, items },
          display: `Thư mục ${p || './'}: ${items.join(', ') || '(trống)'}`,
        };
      }
      default:
        return { ok: false, data: { type: 'error' }, display: `Tool không tồn tại: ${tool.name}` };
    }
  } catch (e) {
    return { ok: false, data: { type: 'error', error: String(e) }, display: `Lỗi khi chạy ${tool.name}: ${e instanceof Error ? e.message : String(e)}` };
  }
}

export function isTextFilePath(p: string): boolean {
  return isTextFile(p);
}
