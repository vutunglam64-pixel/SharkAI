import { NextRequest } from 'next/server';

// Tạo SSE stream — mỗi event là một dòng "data: {...}\n\n"
export class SSEWriter {
  private encoder = new TextEncoder();
  private controller: ReadableStreamDefaultController<Uint8Array> | null = null;
  closed = false;

  bind(controller: ReadableStreamDefaultController<Uint8Array>) {
    this.controller = controller;
  }

  async send(obj: Record<string, unknown>) {
    if (!this.controller || this.closed) return;
    try {
      this.controller.enqueue(this.encoder.encode(`data: ${JSON.stringify(obj)}\n\n`));
    } catch {
      this.closed = true;
    }
  }

  close() {
    if (!this.controller || this.closed) return;
    this.closed = true;
    try {
      this.controller.close();
    } catch {
      // ignore
    }
  }
}

export function createSSEResponse(): { stream: ReadableStream<Uint8Array>; writer: SSEWriter } {
  const writer = new SSEWriter();
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      writer.bind(controller);
    },
  });
  return { stream, writer };
}

export function sseHeaders() {
  return {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  };
}

export function jsonBody(req: NextRequest) {
  return req.json().catch(() => ({}));
}
