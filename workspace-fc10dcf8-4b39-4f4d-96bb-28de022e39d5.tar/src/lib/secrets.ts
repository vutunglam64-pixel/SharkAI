import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ============================================================
// Secret bền vững qua sandbox recycle.
//
// Vì sao không dùng .env: .gitignore có ".env*" → hệ thống
// snapshot loại file .env ra — mỗi lần sandbox restart, .env
// bị tạo lại từ bản mẫu (chỉ còn DATABASE_URL) → AUTH_SECRET
// thay đổi → cookie phiên người dùng chết → "tự thoát acc".
//
// db/ (nơi chứa custom.db) KHÔNG bị gitignore → db/secrets.json
// sống sót qua mọi lần restart, cùng cơ chế với dữ liệu user.
// Ưu tiên: process.env > db/secrets.json.
// ============================================================

const FILE = path.join(process.cwd(), 'db', 'secrets.json');

type Secrets = Record<string, string>;

let cache: Secrets | null = null;

function readAll(): Secrets {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(FILE, 'utf8')) as Secrets;
  } catch {
    cache = {};
  }
  return cache;
}

function writeAll(s: Secrets): void {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(s, null, 2) + '\n', { mode: 0o600 });
  cache = s;
}

/**
 * Lấy giá trị secret theo tên.
 * - `generate: true` → nếu chưa có ở bất kỳ đâu, tự sinh ngẫu nhiên
 *   và ghi vào db/secrets.json ĐÚNG MỘT LẦN (ổn định vĩnh viễn).
 */
export function getSecret(name: string, opts?: { generate?: boolean }): string {
  const env = process.env[name];
  if (env) return env;
  const all = readAll();
  if (all[name]) return all[name];
  if (opts?.generate) {
    const val = crypto.randomBytes(32).toString('hex');
    all[name] = val;
    try {
      writeAll(all);
    } catch {
      // fs read-only (vd build tĩnh) → vẫn trả giá trị cho phiên này
    }
    return val;
  }
  return '';
}
