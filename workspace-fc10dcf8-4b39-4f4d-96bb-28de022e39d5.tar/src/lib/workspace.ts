import fs from 'fs';
import path from 'path';

export const WORKSPACE_ROOT = '/home/z/my-project/workspace';
export const UPLOAD_ROOT = '/home/z/my-project/upload';

export function ensureWorkspace() {
  if (!fs.existsSync(WORKSPACE_ROOT)) fs.mkdirSync(WORKSPACE_ROOT, { recursive: true });
  if (!fs.existsSync(UPLOAD_ROOT)) fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
}

// Chống path traversal — chỉ cho phép path nằm trong root
export function safeResolve(root: string, relPath: string): string | null {
  const clean = (relPath || '').replace(/^[/\\]+/, '');
  const abs = path.resolve(root, clean);
  if (abs === root || abs.startsWith(root + path.sep)) return abs;
  return null;
}

export interface FileNode {
  name: string;
  path: string; // path tương đối
  type: 'file' | 'dir';
  size?: number;
  children?: FileNode[];
}

export function buildTree(root: string, rel = ''): FileNode[] {
  const abs = rel ? safeResolve(root, rel) : root;
  if (!abs || !fs.existsSync(abs)) return [];
  const items = fs.readdirSync(abs, { withFileTypes: true });
  const nodes: FileNode[] = [];
  for (const item of items) {
    if (item.name.startsWith('.') || item.name === 'node_modules') continue;
    const relPath = rel ? `${rel}/${item.name}` : item.name;
    if (item.isDirectory()) {
      nodes.push({
        name: item.name,
        path: relPath,
        type: 'dir',
        children: buildTree(root, relPath),
      });
    } else {
      const st = fs.statSync(path.join(abs, item.name));
      nodes.push({ name: item.name, path: relPath, type: 'file', size: st.size });
    }
  }
  // thư mục trước, rồi file, sort alphabet
  nodes.sort((a, b) => {
    if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  return nodes;
}

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.ts': 'text/plain; charset=utf-8',
  '.tsx': 'text/plain; charset=utf-8',
  '.py': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.pdf': 'application/pdf',
  '.zip': 'application/zip',
};

export function mimeOf(filePath: string): string {
  return MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream';
}

export function isTextFile(filePath: string): boolean {
  const ext = path.extname(filePath).toLowerCase();
  return [
    '.html', '.htm', '.css', '.js', '.mjs', '.ts', '.tsx', '.jsx', '.py', '.json', '.md',
    '.txt', '.csv', '.xml', '.yml', '.yaml', '.sh', '.c', '.cpp', '.h', '.java', '.go',
    '.rs', '.rb', '.php', '.sql', '.toml', '.ini', '.env', '.log',
  ].includes(ext);
}
