'use client';

import { useEffect, useState } from 'react';
import {
  Plus, Users, KeyRound, FolderKanban, Bell, Pin, PinOff,
  Trash2, Sun, Moon, PanelLeftClose, PanelLeftOpen, MessageSquare, Pencil, Check,
  Globe, Heart, ExternalLink, MoreHorizontal, Loader2, LogIn, LogOut, ScrollText,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { useAppStore } from '@/store/app-store';
import { SharkLogo } from './logo';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip, TooltipContent, TooltipProvider, TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

// Thẻ "Miễn phí 100%" thay cho credit (Shark không dùng credit)
function FreeCard() {
  const sites = useAppStore((s) => s.sites);
  const openModal = useAppStore((s) => s.openModal);
  return (
    <div className="rounded-2xl bg-card border p-3.5 space-y-2.5">
      <div className="flex items-center gap-2">
        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
          <Heart size={14} className="text-primary" />
        </div>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold leading-tight">Shark miễn phí 100%</div>
          <div className="text-[11px] text-muted-foreground leading-tight">
            Không credit · Không giới hạn lượt dùng
          </div>
        </div>
      </div>
      <button
        onClick={() => openModal('sites')}
        className="w-full flex items-center justify-between gap-2 bg-secondary/60 rounded-lg px-2.5 py-2 hover:bg-secondary transition-colors"
      >
        <span className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground">
          <Globe size={13} className="text-primary" /> Web đã đăng
        </span>
        <span className="text-[12px] font-semibold text-foreground tabular-nums flex items-center gap-1">
          {sites.length}
          <ExternalLink size={11} className="text-muted-foreground" />
        </span>
      </button>
      <p className="text-[10px] text-muted-foreground/70 text-center">
        5 mô hình AI · 4 MoE mở + Google Gemini
      </p>
    </div>
  );
}

// Thẻ tài khoản: đăng nhập (Google / email + mật khẩu) để đồng bộ chat mọi thiết bị
function AccountCard() {
  const user = useAppStore((s) => s.user);
  const openModal = useAppStore((s) => s.openModal);
  const logoutUser = useAppStore((s) => s.logoutUser);

  if (!user) {
    return (
      <button
        onClick={() => openModal('login')}
        className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm font-medium text-primary hover:bg-primary/10 transition-colors"
      >
        <span className="h-6 w-6 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
          <LogIn size={13} />
        </span>
        <span className="flex-1 text-left leading-tight">
          Đăng nhập
          <span className="block text-[10.5px] font-normal text-muted-foreground">
            Lưu &amp; đồng bộ chat mọi thiết bị
          </span>
        </span>
      </button>
    );
  }

  return (
    <div className="flex items-center gap-2.5 px-2 py-2">
      {user.image ? (
        <img src={user.image} alt={user.name} className="h-7 w-7 rounded-full border object-cover" />
      ) : (
        <span className="h-7 w-7 rounded-full bg-primary/15 text-primary flex items-center justify-center text-[12px] font-bold shrink-0">
          {user.name.slice(0, 1).toUpperCase()}
        </span>
      )}
      <span className="flex-1 min-w-0 leading-tight">
        <span className="block text-[13px] font-semibold truncate">{user.name}</span>
        <span className="block text-[10.5px] text-muted-foreground truncate">{user.email}</span>
      </span>
      <TooltipProvider delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => logoutUser()}
              className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
            >
              <LogOut size={14} />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right">Đăng xuất</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}

function ThemeToggle() {
  const { setTheme, resolvedTheme } = useTheme();
  return (
    <button
      onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
      className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm text-foreground/90 hover:bg-sidebar-accent transition-colors w-full"
    >
      <Sun size={16} className="hidden dark:block" />
      <Moon size={16} className="block dark:hidden" />
      Đổi giao diện sáng/tối
    </button>
  );
}

function NotificationsBell() {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm text-foreground/90 hover:bg-sidebar-accent transition-colors w-full">
          <Bell size={16} />
          Thông báo
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent side="right" align="end" className="w-80 p-0">
        <div className="px-4 py-3 border-b font-semibold text-sm">Thông báo</div>
        <div className="p-2">
          <div className="p-3 rounded-xl bg-primary/5 border border-primary/20">
            <p className="text-[13px] font-semibold">Chạy nền thông minh</p>
            <p className="text-xs text-muted-foreground mt-1">
              Thoát đoạn chat, Shark vẫn tiếp tục chạy. Quay lại bất kỳ lúc nào để xem kết quả!
            </p>
          </div>
          <div className="p-3 rounded-xl mt-1.5">
            <p className="text-[13px] font-semibold">Chào mừng đến Shark</p>
            <p className="text-xs text-muted-foreground mt-1">
              5 mô hình AI miễn phí: 4 MoE mã nguồn mở (DeepSeek V3 · Kimi K2 · Shark 1.0 · DeepSeek R1) + Google Gemini 3.8 Flash. Thử chế độ Agent hoặc Deep Research ngay!
            </p>
          </div>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// 1 phiên chat trong lịch sử — ghim/đổi tên/xoá qua menu "..." (dùng được cả mobile & PC)
function SessionItem({ id, title, pinned, running, group }: { id: string; title: string; pinned: boolean; running?: boolean; group?: boolean }) {
  const activeSessionId = useAppStore((s) => s.activeSessionId);
  const loadSession = useAppStore((s) => s.loadSession);
  const deleteSession = useAppStore((s) => s.deleteSession);
  const togglePin = useAppStore((s) => s.togglePin);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(title);

  const commitRename = () => {
    const v = draft.trim();
    if (v && v !== title) useAppStore.getState().renameSession(id, v);
    setEditing(false);
  };

  return (
    <div
      className={cn(
        'group flex items-center gap-1.5 px-2 py-1.5 rounded-lg cursor-pointer text-[13px] transition-colors',
        activeSessionId === id ? 'bg-sidebar-accent font-medium' : 'hover:bg-sidebar-accent/60'
      )}
      onClick={() => !editing && loadSession(id)}
    >
      {editing ? (
        <>
          <input
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                commitRename();
              }
              if (e.key === 'Escape') setEditing(false);
            }}
            onBlur={commitRename}
            className="flex-1 bg-transparent outline-none border-b border-primary/50 min-w-0"
            onClick={(e) => e.stopPropagation()}
          />
          <button
            onMouseDown={(e) => {
              e.preventDefault(); // giữ focus input để onBlur không commit 2 lần
              e.stopPropagation();
              commitRename();
            }}
            className="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded shrink-0"
          >
            <Check size={13} />
          </button>
        </>
      ) : (
        <>
          {running ? (
            <Loader2 size={12} className="animate-spin text-primary shrink-0" />
          ) : pinned ? (
            <Pin size={11} className="text-primary shrink-0" />
          ) : group ? (
            <Users size={11} className="text-primary/80 shrink-0" />
          ) : null}
          <span className="truncate flex-1">{title}</span>
          {running && (
            <span className="text-[9px] font-semibold text-primary bg-primary/10 rounded-full px-1.5 py-0.5 shrink-0">
              chạy nền
            </span>
          )}
          {/* Menu "..." — hoạt động bằng chạm (mobile) lẫn chuột (PC) */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 text-muted-foreground opacity-60 group-hover:opacity-100 transition-opacity shrink-0"
                title="Tuỳ chọn"
              >
                <MoreHorizontal size={14} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuItem onClick={() => togglePin(id, !pinned)}>
                {pinned ? <PinOff size={14} /> : <Pin size={14} />}
                {pinned ? 'Bỏ ghim' : 'Ghim lên đầu'}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => {
                  setDraft(title);
                  setEditing(true);
                }}
              >
                <Pencil size={14} /> Đổi tên
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive focus:text-destructive"
                onClick={() => {
                  if (confirm('Xoá phiên chat này?')) deleteSession(id);
                }}
              >
                <Trash2 size={14} /> Xoá phiên chat
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </>
      )}
    </div>
  );
}

export function Sidebar() {
  const {
    sidebarOpen, toggleSidebar, sessions, refreshSessions, projects, refreshProjects,
    refreshSites, refreshCustomSkills, sites, refreshUser,
    newChat, openModal, setActiveProject, activeProjectId,
    groupAI, setGroupAI,
  } = useAppStore();

  useEffect(() => {
    refreshSessions();
    refreshProjects();
    refreshSites();
    refreshCustomSkills();
    refreshUser();
  }, []);

  // mở modal đăng nhập nếu redirect về ?login=...
  useEffect(() => {
    const q = new URLSearchParams(window.location.search).get('login');
    if (q === 'quick' || q === 'error') openModal('login');
    if (q) window.history.replaceState({}, '', '/');
  }, [openModal]);

  const filteredSessions = sessions.filter(
    (s) => !activeProjectId || s.projectId === activeProjectId
  );

  return (
    <aside
      className={cn(
        'h-full flex flex-col bg-sidebar border-r transition-all duration-200 shrink-0 overflow-hidden',
        sidebarOpen ? 'w-[264px]' : 'w-0'
      )}
    >
      <div className={cn('flex flex-col h-full w-[264px]', !sidebarOpen && 'invisible')}>
        {/* Logo */}
        <div className="flex items-center gap-2 px-4 pt-4 pb-2">
          <SharkLogo size={30} />
          <span className="font-bold text-[17px] tracking-tight flex-1">Shark</span>
          <button
            onClick={toggleSidebar}
            className="p-1.5 rounded-lg hover:bg-sidebar-accent text-muted-foreground press"
            title="Thu gọn"
          >
            <PanelLeftClose size={17} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-2.5 pb-2 space-y-0.5 stagger">
          {/* Phiên chat mới */}
          <button
            onClick={newChat}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium border bg-card hover:bg-accent hover:shadow-sm hover:-translate-y-px active:scale-[0.98] transition-all shadow-sm mt-1"
          >
            <Plus size={16} className="text-primary" />
            Phiên chat mới
          </button>

          {/* Group AI — BẬT: sang trang group (đội 8 agent) · TẮT: về chat thường */}
          <button
            onClick={() => setGroupAI(!groupAI)}
            className={cn(
              'w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm active:scale-[0.98] transition-all',
              groupAI
                ? 'bg-primary/10 text-primary font-semibold border border-primary/25'
                : 'hover:bg-sidebar-accent border border-transparent'
            )}
          >
            <Users size={16} className={groupAI ? 'text-primary' : 'text-muted-foreground'} />
            Group AI
            <span
              className={cn(
                'ml-auto text-[9.5px] font-semibold rounded-full px-1.5 py-0.5 transition-colors',
                groupAI ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'
              )}
            >
              8
            </span>
          </button>
          <button
            onClick={() => openModal('api')}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm hover:bg-sidebar-accent active:scale-[0.98] transition-all"
          >
            <KeyRound size={16} className="text-muted-foreground" />
            API
            <span className="ml-auto text-[9.5px] font-semibold text-primary bg-primary/10 rounded-full px-1.5 py-0.5">
              miễn phí
            </span>
          </button>
          <button
            onClick={() => openModal('sites')}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm hover:bg-sidebar-accent active:scale-[0.98] transition-all"
          >
            <Globe size={16} className="text-muted-foreground" />
            Web đã đăng
            {sites.length > 0 && (
              <span className="ml-auto text-[10px] font-semibold text-muted-foreground bg-secondary rounded-full px-1.5 py-0.5">
                {sites.length}
              </span>
            )}
          </button>

          {/* Dự án */}
          <div className="pt-3">
            <div className="flex items-center justify-between px-2.5 pb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Dự án
              </span>
              <button
                onClick={() => openModal('project')}
                className="p-1 rounded hover:bg-sidebar-accent text-muted-foreground"
                title="Tạo dự án mới"
              >
                <Plus size={13} />
              </button>
            </div>
            {projects.length === 0 ? (
              <button
                onClick={() => openModal('project')}
                className="w-full text-left px-3 py-2 rounded-xl text-[13px] text-muted-foreground hover:bg-sidebar-accent transition-colors flex items-center gap-2"
              >
                <FolderKanban size={15} />
                Tạo dự án mới
              </button>
            ) : (
              <div className="space-y-0.5">
                <button
                  onClick={() => setActiveProject(null)}
                  className={cn(
                    'w-full text-left px-3 py-1.5 rounded-lg text-[13px] transition-colors flex items-center gap-2',
                    !activeProjectId ? 'bg-sidebar-accent font-medium' : 'hover:bg-sidebar-accent/60'
                  )}
                >
                  <FolderKanban size={14} className="text-muted-foreground" />
                  Tất cả
                </button>
                {projects.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setActiveProject(activeProjectId === p.id ? null : p.id)}
                    className={cn(
                      'w-full text-left px-3 py-1.5 rounded-lg text-[13px] transition-colors flex items-center gap-2 group',
                      activeProjectId === p.id ? 'bg-sidebar-accent font-medium' : 'hover:bg-sidebar-accent/60'
                    )}
                  >
                    <FolderKanban size={14} className="text-primary shrink-0" />
                    <span className="truncate flex-1">{p.name}</span>
                    <span className="text-[10px] text-muted-foreground">{p._count?.sessions ?? 0}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Lịch sử chat */}
          <div className="pt-3">
            <div className="flex items-center gap-2 px-2.5 pb-1">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Lịch sử chat
              </span>
            </div>
            {filteredSessions.length === 0 ? (
              <div className="px-3 py-2 text-[13px] text-muted-foreground flex items-center gap-2">
                <MessageSquare size={14} />
                Chưa có phiên chat nào
              </div>
            ) : (
              <div className="space-y-0.5">
                {filteredSessions.map((s) => (
                  <SessionItem key={s.id} id={s.id} title={s.title} pinned={s.pinned} running={s.running} group={s.groupAI} />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Bottom */}
        <div className="p-2.5 space-y-1 border-t">
          <AccountCard />
          <NotificationsBell />
          <ThemeToggle />
          <a
            href="/terms"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm text-foreground/90 hover:bg-sidebar-accent transition-colors"
          >
            <ScrollText size={16} />
            Điều khoản &amp; Dịch vụ
          </a>
          <div className="pt-1">
            <FreeCard />
          </div>
        </div>
      </div>
    </aside>
  );
}

export function SidebarExpandButton() {
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);
  return (
    <button
      onClick={toggleSidebar}
      className="p-2 rounded-lg hover:bg-accent text-muted-foreground"
      title="Mở sidebar"
    >
      <PanelLeftOpen size={18} />
    </button>
  );
}
