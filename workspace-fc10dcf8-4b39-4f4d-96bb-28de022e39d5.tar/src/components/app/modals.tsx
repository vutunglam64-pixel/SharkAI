'use client';

import { useEffect, useState } from 'react';
import {
  Users, KeyRound, FolderKanban, Globe, Sparkles,
  Copy, ExternalLink, Loader2, CheckCircle2, Wrench, TerminalSquare, FileText, Eye,
  Film, Search, Image as ImageIcon, Wand2, SearchCode, UploadCloud, Package,
  Volume2, Mic, BarChart3, Plus, Trash2, X, Check, BookOpen, KeySquare, Code2, EyeOff,
} from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { PERSONAS, SKILLS, MODELS } from '@/lib/config';
import { useAppStore } from '@/store/app-store';
import { PersonaAvatar } from './persona';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const SKILL_ICONS: Record<string, React.ReactNode> = {
  search: <Search size={16} />, 'book-open': <FileText size={16} />,
  'image-plus': <ImageIcon size={16} />, wand: <Wand2 size={16} />,
  'search-image': <SearchCode size={16} />, video: <Film size={16} />,
  eye: <Eye size={16} />, film: <Film size={16} />,
  'file-text': <FileText size={16} />, terminal: <TerminalSquare size={16} />,
  folder: <FolderKanban size={16} />, 'upload-cloud': <UploadCloud size={16} />,
  package: <Package size={16} />, 'bar-chart': <BarChart3 size={16} />,
  volume: <Volume2 size={16} />, mic: <Mic size={16} />,
};

// ---------- Modal Dự án ----------
function ProjectModal() {
  const openModal = useAppStore((s) => s.openModal);
  const refreshProjects = useAppStore((s) => s.refreshProjects);
  const [name, setName] = useState('');
  const [goal, setGoal] = useState('');
  const [busy, setBusy] = useState(false);

  const create = async () => {
    if (!name.trim()) return;
    setBusy(true);
    await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, goal }),
    });
    setBusy(false);
    await refreshProjects();
    toast({ title: `Đã tạo dự án "${name}"` });
    openModal(null);
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <FolderKanban size={17} className="text-primary" /> Tạo dự án mới
        </DialogTitle>
        <DialogDescription>
          Shark sẽ ghi nhớ mục tiêu để trả lời sát với dự án của bạn hơn.
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-3.5">
        <div>
          <label className="text-[13px] font-medium">Tên dự án</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="vd: Quán cà phê Shark"
            className="w-full mt-1 h-10 px-3 rounded-xl border bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <div>
          <label className="text-[13px] font-medium">Mục tiêu chính</label>
          <textarea
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="AI sẽ bám sát mục tiêu này trong mọi đoạn chat của dự án..."
            rows={4}
            className="w-full mt-1 p-3 rounded-xl border bg-background text-sm outline-none resize-none focus:ring-2 focus:ring-primary/30"
          />
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => openModal(null)}>Huỷ</Button>
          <Button onClick={create} disabled={!name.trim() || busy} className="bg-primary hover:bg-primary/90">
            {busy ? <Loader2 size={14} className="animate-spin" /> : 'Tạo dự án'}
          </Button>
        </div>
      </div>
    </DialogContent>
  );
}

// ---------- Modal Group AI — đội hình 8 chuyên gia ----------
function GroupAIModal() {
  const openModal = useAppStore((s) => s.openModal);
  const groupAI = useAppStore((s) => s.groupAI);
  const setGroupAI = useAppStore((s) => s.setGroupAI);

  return (
    <DialogContent className="sm:max-w-lg">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Users size={17} className="text-primary" /> Group AI — Đội hình Shark
        </DialogTitle>
        <DialogDescription>
          8 chuyên gia cùng hỗ trợ làm việc: <b>Sếp</b> nhận yêu cầu &amp; giao việc đúng người,
          các chuyên gia <b>Code / Terminal</b> chạy tool thật (tạo file, chạy lệnh),
          <b> Kết quả</b> tổng hợp báo cáo cuối.
        </DialogDescription>
      </DialogHeader>
      <div className="grid grid-cols-2 gap-2 stagger max-h-[46vh] overflow-y-auto pr-0.5">
        {PERSONAS.map((p) => (
          <div key={p.id} className="flex items-start gap-2.5 p-2.5 rounded-xl border bg-card hover-lift">
            <PersonaAvatar p={p} size={32} />
            <div className="min-w-0">
              <div className="text-[12.5px] font-semibold flex items-center gap-1.5 leading-tight">
                {p.name}
                <span className="text-[9px] font-medium bg-secondary text-muted-foreground px-1.5 py-0.5 rounded-full shrink-0">
                  {p.role}
                </span>
              </div>
              <p className="text-[10.5px] text-muted-foreground mt-0.5 leading-snug">{p.desc}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between p-3 rounded-xl border bg-primary/5">
        <span className="text-[13px] font-semibold">
          {groupAI ? 'Bạn đang ở trang Group AI — tắt để về bình thường' : 'Bật Group AI (sang trang group)'}
        </span>
        <Switch checked={groupAI} onCheckedChange={setGroupAI} />
      </div>
      <div className="flex justify-end">
        <Button onClick={() => openModal(null)} className="bg-primary hover:bg-primary/90">Xong</Button>
      </div>
    </DialogContent>
  );
}

// ---------- Modal API (thay cho Desktop) — tạo & quản lý API key + hướng dẫn gọi chi tiết ----------

// khối code có nút copy
function CodeBlock({ code, lang }: { code: string; lang: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="relative group rounded-xl bg-[#17171a] text-[#e8e8ea] overflow-hidden border border-black/10">
      <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/8">
        <span className="text-[10.5px] font-semibold uppercase tracking-wider text-white/50">{lang}</span>
        <button
          onClick={() => {
            navigator.clipboard.writeText(code);
            setCopied(true);
            setTimeout(() => setCopied(false), 1600);
          }}
          className="flex items-center gap-1 text-[11px] text-white/60 hover:text-white transition-colors"
        >
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? 'Đã copy' : 'Copy'}
        </button>
      </div>
      <pre className="p-3 overflow-x-auto text-[11.5px] leading-relaxed font-mono">{code}</pre>
    </div>
  );
}

interface ApiKeyRow {
  id: string;
  name: string;
  masked: string;
  calls: number;
  lastUsedAt: string | null;
  createdAt: string;
}

function ApiKeysTab() {
  const user = useAppStore((s) => s.user);
  const openModal = useAppStore((s) => s.openModal);
  const [keys, setKeys] = useState<ApiKeyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [creating, setCreating] = useState(false);
  // key vừa tạo — chỉ hiện đầy đủ ĐÚNG 1 LẦN (như OpenAI/Gemini)
  const [freshKey, setFreshKey] = useState<string | null>(null);

  const load = async () => {
    try {
      const res = await fetch('/api/keys');
      if (res.ok) setKeys(await res.json());
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    load();
  }, []);

  const create = async () => {
    setCreating(true);
    try {
      const res = await fetch('/api/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name || undefined }),
      });
      const data = await res.json();
      if (data.key) {
        setFreshKey(data.key);
        setName('');
        await load();
      } else toast({ title: data.error || 'Tạo key thất bại', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const remove = async (id: string, keyName: string) => {
    if (!confirm(`Xoá key "${keyName}"? Ứng dụng đang dùng key này sẽ mất quyền truy cập.`)) return;
    await fetch(`/api/keys?id=${id}`, { method: 'DELETE' }).catch(() => {});
    await load();
    toast({ title: `Đã xoá key "${keyName}"` });
  };

  // chưa đăng nhập → mời đăng nhập (key gắn với tài khoản)
  if (!user) {
    return (
      <div className="space-y-3">
        <div className="rounded-xl border border-dashed p-5 text-center">
          <KeySquare size={26} className="mx-auto text-primary mb-2" />
          <p className="text-[13.5px] font-semibold">Đăng nhập để tạo API key</p>
          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
            API key gắn với tài khoản của bạn — tạo, xoá và theo dõi lượt dùng ở mọi thiết bị.
          </p>
          <Button onClick={() => openModal('login')} className="mt-3 bg-primary hover:bg-primary/90">
            Đăng nhập ngay
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* key vừa tạo — hiện đầy đủ 1 lần */}
      {freshKey && (
        <div className="rounded-xl border border-primary/40 bg-primary/5 p-3.5 anim-pop">
          <div className="text-[12.5px] font-semibold text-primary flex items-center gap-1.5">
            <CheckCircle2 size={14} /> Đã tạo! Key CHỈ hiện đầy đủ MỘT LẦN — lưu lại ngay
          </div>
          <div className="flex items-center gap-2 mt-2 bg-background rounded-lg border p-2.5">
            <code className="text-[12.5px] font-mono flex-1 truncate select-all">{freshKey}</code>
            <button
              onClick={() => {
                navigator.clipboard.writeText(freshKey);
                toast({ title: 'Đã sao chép API key' });
              }}
              className="p-1.5 rounded-md hover:bg-secondary shrink-0"
              title="Sao chép"
            >
              <Copy size={14} />
            </button>
          </div>
          <p className="text-[10.5px] text-muted-foreground mt-1.5">
            Nếu mất key, chỉ cần xoá và tạo key mới — miễn phí, không giới hạn số lần.
          </p>
        </div>
      )}

      {/* tạo key mới */}
      <div className="flex gap-2">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && create()}
          placeholder="Tên key (vd: Dự án bán hàng)"
          className="flex-1 h-10 px-3 rounded-xl border bg-background text-[13px] outline-none focus:ring-2 focus:ring-primary/30"
        />
        <Button onClick={create} disabled={creating} className="bg-primary hover:bg-primary/90 shrink-0">
          {creating ? <Loader2 size={14} className="animate-spin" /> : <Plus size={15} />}
          Tạo key
        </Button>
      </div>

      {/* danh sách key */}
      {loading ? (
        <div className="py-6 text-center text-xs text-muted-foreground flex justify-center">
          <Loader2 size={16} className="animate-spin" />
        </div>
      ) : keys.length === 0 ? (
        <div className="p-4 rounded-xl border border-dashed text-center text-xs text-muted-foreground">
          Chưa có API key nào. Tạo key đầu tiên rồi gọi Shark từ ứng dụng bất kỳ — chuẩn OpenAI.
        </div>
      ) : (
        <div className="space-y-1.5">
          {keys.map((k) => (
            <div key={k.id} className="group flex items-center gap-2.5 p-2.5 rounded-xl border bg-card">
              <span className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <KeyRound size={15} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-medium truncate">{k.name}</div>
                <div className="text-[11px] text-muted-foreground font-mono truncate">{k.masked}</div>
              </div>
              <div className="text-right shrink-0 hidden sm:block">
                <div className="text-[11px] font-semibold tabular-nums">{k.calls} lượt gọi</div>
                <div className="text-[10px] text-muted-foreground">
                  {k.lastUsedAt ? 'dùng gần nhất ' + new Date(k.lastUsedAt).toLocaleDateString('vi-VN') : 'chưa dùng'}
                </div>
              </div>
              <button
                onClick={() => remove(k.id, k.name)}
                className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive opacity-60 group-hover:opacity-100 transition-opacity shrink-0"
                title="Xoá key"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ApiDocsTab() {
  // origin chỉ tồn tại trên client — đọc 1 lần khi render đầu (modal luôn mở sau khi mount)
  const [origin] = useState(() => (typeof window !== 'undefined' ? window.location.origin : ''));

  const curl = `curl ${origin}/api/v1/chat/completions \\
  -H "Authorization: Bearer sk-shark-free..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shark-1",
    "messages": [{"role": "user", "content": "Xin chào Shark!"}]
  }'`;

  const curlStream = `curl -N ${origin}/api/v1/chat/completions \\
  -H "Authorization: Bearer sk-shark-free..." \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "shark-1",
    "stream": true,
    "messages": [{"role": "user", "content": "Viết bài giới thiệu quán cà phê"}]
  }'`;

  const pySdk = `from openai import OpenAI  # pip install openai

client = OpenAI(
    base_url="${origin}/api/v1",
    api_key="sk-shark-free...",
)

res = client.chat.completions.create(
    model="shark-1",
    messages=[{"role": "user", "content": "Xin chào Shark!"}],
)
print(res.choices[0].message.content)`;

  const pyStream = `stream = client.chat.completions.create(
    model="shark-1",
    messages=[{"role": "user", "content": "Kể chuyện cười ngắn"}],
    stream=True,
)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")`;

  const jsSdk = `import OpenAI from "openai"; // npm i openai

const client = new OpenAI({
  baseURL: "${origin}/api/v1",
  apiKey: "sk-shark-free...",
});

const res = await client.chat.completions.create({
  model: "shark-1",
  messages: [{ role: "user", content: "Xin chào Shark!" }],
});
console.log(res.choices[0].message.content);`;

  const jsFetch = `const res = await fetch("${origin}/api/v1/chat/completions", {
  method: "POST",
  headers: {
    Authorization: "Bearer sk-shark-free...",
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "shark-1",
    messages: [{ role: "user", content: "Xin chào Shark!" }],
  }),
});
const data = await res.json();
console.log(data.choices[0].message.content);`;

  const modelsCmd = `curl ${origin}/api/v1/models \\
  -H "Authorization: Bearer sk-shark-free..."`;

  return (
    <div className="space-y-4 text-[13px]">
      {/* tổng quan nhanh */}
      <div className="rounded-xl border bg-secondary/40 p-3 leading-relaxed">
        <b>Shark Public API</b> tương thích 100% chuẩn <b>OpenAI / Groq / Gemini</b> — dán key
        <code className="mx-1 px-1.5 py-0.5 rounded bg-background border text-[11.5px]">sk-shark-free...</code>
        vào header <code className="px-1.5 py-0.5 rounded bg-background border text-[11.5px]">Authorization: Bearer</code> là dùng được ngay
        với mọi SDK hiểu chuẩn OpenAI (Python, JS, LangChain, Cursor, Continue...).
      </div>

      {/* endpoint */}
      <div>
        <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Endpoint chính</div>
        <div className="rounded-xl border divide-y overflow-hidden">
          <div className="flex items-center gap-2.5 px-3 py-2.5">
            <span className="text-[10px] font-bold bg-emerald-500/15 text-emerald-600 rounded px-1.5 py-0.5 w-14 text-center shrink-0">POST</span>
            <code className="text-[12px] font-mono">/api/v1/chat/completions</code>
            <span className="ml-auto text-[11px] text-muted-foreground hidden sm:block">chat — có stream</span>
          </div>
          <div className="flex items-center gap-2.5 px-3 py-2.5">
            <span className="text-[10px] font-bold bg-blue-500/15 text-blue-600 rounded px-1.5 py-0.5 w-14 text-center shrink-0">GET</span>
            <code className="text-[12px] font-mono">/api/v1/models</code>
            <span className="ml-auto text-[11px] text-muted-foreground hidden sm:block">danh sách model</span>
          </div>
        </div>
      </div>

      {/* base url */}
      <div className="flex items-center gap-2">
        <span className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Base URL</span>
        <div className="flex items-center gap-1.5 bg-secondary rounded-lg px-2.5 py-1.5 ml-auto">
          <code className="text-[11.5px] font-mono">{origin}/api/v1</code>
          <button
            onClick={() => {
              navigator.clipboard.writeText(`${origin}/api/v1`);
              toast({ title: 'Đã sao chép Base URL' });
            }}
            className="p-1 rounded hover:bg-background"
          >
            <Copy size={12} />
          </button>
        </div>
      </div>

      {/* model */}
      <div>
        <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Model khả dụng (miễn phí)</div>
        <div className="flex flex-wrap gap-1.5">
          {MODELS.map((m) => (
            <span key={m.id} className="text-[11px] font-mono border rounded-full px-2.5 py-1 bg-card" style={{ borderColor: `${m.accent}55` }}>
              {m.id}
            </span>
          ))}
        </div>
      </div>

      {/* ví dụ */}
      <div>
        <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">Ví dụ gọi chi tiết</div>
        <div className="space-y-3">
          <CodeBlock lang="cURL" code={curl} />
          <CodeBlock lang="cURL — streaming" code={curlStream} />
          <CodeBlock lang="Python — SDK OpenAI" code={pySdk} />
          <CodeBlock lang="Python — stream từng chữ" code={pyStream} />
          <CodeBlock lang="JavaScript — SDK OpenAI" code={jsSdk} />
          <CodeBlock lang="JavaScript — fetch" code={jsFetch} />
          <CodeBlock lang="cURL — xem model" code={modelsCmd} />
        </div>
      </div>

      {/* tham số & lỗi */}
      <div className="grid sm:grid-cols-2 gap-3">
        <div className="rounded-xl border p-3">
          <div className="text-[12px] font-semibold mb-1.5">Tham số hỗ trợ</div>
          <ul className="text-[11.5px] text-muted-foreground space-y-1 leading-relaxed">
            <li><code className="text-foreground">model</code> — id model (mặc định: shark-1)</li>
            <li><code className="text-foreground">messages</code> — mảng {`{role, content}`}, hỗ trợ role system</li>
            <li><code className="text-foreground">stream</code> — true để nhận SSE từng chữ</li>
          </ul>
        </div>
        <div className="rounded-xl border p-3">
          <div className="text-[12px] font-semibold mb-1.5">Mã lỗi</div>
          <ul className="text-[11.5px] text-muted-foreground space-y-1 leading-relaxed">
            <li><b className="text-foreground">401</b> — thiếu / sai / đã thu hồi key</li>
            <li><b className="text-foreground">400</b> — body thiếu mảng messages</li>
            <li><b className="text-foreground">500</b> — lỗi máy chủ, thử lại sau</li>
          </ul>
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
        <BookOpen size={13} className="text-primary shrink-0" />
        Key miễn phí, không giới hạn lượt dùng — mỗi tài khoản tạo được tối đa 20 key.
      </p>
    </div>
  );
}

function ApiModal() {
  const [tab, setTab] = useState<'keys' | 'docs'>('keys');
  return (
    <DialogContent className="sm:max-w-2xl max-h-[86vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <KeyRound size={17} className="text-primary" /> Shark API
        </DialogTitle>
        <DialogDescription>
          Tạo API key miễn phí dạng <code className="px-1 rounded bg-secondary">sk-shark-free...</code> và gọi Shark từ
          ứng dụng bất kỳ — tương thích chuẩn OpenAI / Gemini / Groq.
        </DialogDescription>
      </DialogHeader>

      {/* tab chuyển */}
      <div className="flex gap-1 p-1 bg-secondary/60 rounded-xl w-fit">
        {([
          { id: 'keys', label: 'Khoá của tôi', icon: <KeySquare size={13} /> },
          { id: 'docs', label: 'Hướng dẫn gọi chi tiết', icon: <Code2 size={13} /> },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-[12.5px] font-medium transition-all active:scale-[0.97]',
              tab === t.id ? 'bg-background shadow-sm' : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'keys' ? <ApiKeysTab /> : <ApiDocsTab />}
    </DialogContent>
  );
}

// ---------- Modal Skills (kèm tạo skill tùy chỉnh như Claude) ----------
function SkillsModal() {
  const openModal = useAppStore((s) => s.openModal);
  const enabledSkills = useAppStore((s) => s.enabledSkills);
  const toggleSkill = useAppStore((s) => s.toggleSkill);
  const customSkills = useAppStore((s) => s.customSkills);
  const refreshCustomSkills = useAppStore((s) => s.refreshCustomSkills);

  const [creating, setCreating] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [prompt, setPrompt] = useState('');
  const [busy, setBusy] = useState(false);

  const categories = [...new Set(SKILLS.map((s) => s.category))];

  const createSkill = async () => {
    if (!name.trim() || !prompt.trim()) return;
    setBusy(true);
    try {
      const res = await fetch('/api/skills', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, desc, prompt }),
      });
      const data = await res.json();
      if (data.id) {
        toast({ title: `Đã tạo skill "${name}"`, description: 'Bật công tắc để dùng ngay!' });
        setName('');
        setDesc('');
        setPrompt('');
        setCreating(false);
        await refreshCustomSkills();
      } else {
        toast({ title: data.error || 'Tạo skill thất bại', variant: 'destructive' });
      }
    } finally {
      setBusy(false);
    }
  };

  const deleteSkill = async (id: string, skillName: string) => {
    if (!confirm(`Xoá skill "${skillName}"?`)) return;
    await fetch(`/api/skills?id=${id}`, { method: 'DELETE' }).catch(() => {});
    // tắt nếu đang bật
    if (enabledSkills.includes(`custom:${id}`)) toggleSkill(`custom:${id}`);
    await refreshCustomSkills();
    toast({ title: `Đã xoá skill "${skillName}"` });
  };

  return (
    <DialogContent className="sm:max-w-xl max-h-[85vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Sparkles size={17} className="text-primary" /> Skills của Shark
        </DialogTitle>
        <DialogDescription>
          Giống Claude Skills: bật năng lực chuyên biệt — hoặc tự tạo skill của riêng bạn.
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-4">
        {/* Skill có sẵn */}
        {categories.map((cat) => (
          <div key={cat}>
            <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-1.5">{cat}</div>
            <div className="space-y-1">
              {SKILLS.filter((s) => s.category === cat).map((sk) => (
                <div key={sk.id} className="flex items-center gap-3 p-2.5 rounded-xl border bg-card">
                  <span className="h-8 w-8 rounded-lg bg-secondary flex items-center justify-center text-primary shrink-0">
                    {SKILL_ICONS[sk.icon] || <Sparkles size={15} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-medium">{sk.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{sk.desc}</div>
                  </div>
                  <Switch
                    checked={enabledSkills.includes(sk.id)}
                    onCheckedChange={() => toggleSkill(sk.id)}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Skill tùy chỉnh */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <div className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
              Skills tùy chỉnh của bạn
            </div>
            {!creating && (
              <button
                onClick={() => setCreating(true)}
                className="inline-flex items-center gap-1 text-[12px] font-medium text-primary hover:underline"
              >
                <Plus size={13} /> Tạo skill mới
              </button>
            )}
          </div>

          {creating && (
            <div className="space-y-2.5 p-3 rounded-xl border border-primary/30 bg-primary/5 mb-2">
              <div>
                <label className="text-[12px] font-medium">Tên skill</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="vd: Viết content bán hàng"
                  className="w-full mt-1 h-9 px-3 rounded-lg border bg-background text-[13px] outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div>
                <label className="text-[12px] font-medium">Mô tả ngắn</label>
                <input
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="vd: Viết caption thu hút theo công thức AIDA"
                  className="w-full mt-1 h-9 px-3 rounded-lg border bg-background text-[13px] outline-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div>
                <label className="text-[12px] font-medium">Hướng dẫn cho AI (system prompt)</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={'vd: Khi được dùng, hãy viết caption theo công thức AIDA: chú ý - quan tâm - mong muốn - hành động. Giọng văn trẻ trung, có emoji vừa đủ, kết bằng lời kêu gọi inbox.'}
                  rows={5}
                  className="w-full mt-1 p-3 rounded-lg border bg-background text-[13px] outline-none resize-none focus:ring-2 focus:ring-primary/30"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setCreating(false);
                    setName('');
                    setDesc('');
                    setPrompt('');
                  }}
                >
                  <X size={14} /> Huỷ
                </Button>
                <Button
                  size="sm"
                  onClick={createSkill}
                  disabled={!name.trim() || !prompt.trim() || busy}
                  className="bg-primary hover:bg-primary/90"
                >
                  {busy ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />} Tạo skill
                </Button>
              </div>
            </div>
          )}

          {customSkills.length === 0 && !creating ? (
            <div className="p-3 rounded-xl border border-dashed text-center text-xs text-muted-foreground">
              Chưa có skill tùy chỉnh nào. Bấm “Tạo skill mới” để tạo năng lực riêng như Claude Skills.
            </div>
          ) : (
            <div className="space-y-1">
              {customSkills.map((cs) => (
                <div key={cs.id} className="group flex items-center gap-3 p-2.5 rounded-xl border bg-card">
                  <span className="h-8 w-8 rounded-lg bg-primary/15 flex items-center justify-center text-primary shrink-0">
                    <Wrench size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-medium flex items-center gap-1.5">
                      {cs.name}
                      <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">Tùy chỉnh</span>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{cs.desc || cs.prompt.slice(0, 80)}</div>
                  </div>
                  <button
                    onClick={() => deleteSkill(cs.id, cs.name)}
                    className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                    title="Xoá skill"
                  >
                    <Trash2 size={13} />
                  </button>
                  <Switch
                    checked={enabledSkills.includes(`custom:${cs.id}`)}
                    onCheckedChange={() => toggleSkill(`custom:${cs.id}`)}
                  />
                </div>
              ))}
            </div>
          )}
          <p className="text-[11px] text-muted-foreground">
            Skill tùy chỉnh đang bật sẽ được chèn hướng dẫn vào bộ não AI trong mọi lượt chat.
          </p>
        </div>

        <div className="flex justify-end">
          <Button onClick={() => openModal(null)} className="bg-primary hover:bg-primary/90">Xong</Button>
        </div>
      </div>
    </DialogContent>
  );
}

// ---------- Modal Đăng web ----------
function PublishModal() {
  const openModal = useAppStore((s) => s.openModal);
  const previewSrc = useAppStore((s) => s.previewSrc);
  const refreshSites = useAppStore((s) => s.refreshSites);
  const [name, setName] = useState('');
  const [html, setHtml] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  useEffect(() => {
    if (previewSrc?.startsWith('srcdoc:')) setHtml(previewSrc.slice(7));
  }, [previewSrc]);

  const publish = async () => {
    setBusy(true);
    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ html, name: name || 'Trang web của Shark' }),
      });
      const data = await res.json();
      if (data.url) {
        setResult(`${window.location.origin}${data.url}`);
        await refreshSites();
      } else toast({ title: data.error || 'Đăng thất bại', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Globe size={17} className="text-primary" /> Đăng web lên internet
        </DialogTitle>
        <DialogDescription>
          Dán HTML hoặc dùng bản nháp đang xem trước. Trang sẽ có liên kết công khai ngay — xem danh sách ở “Web đã đăng”.
        </DialogDescription>
      </DialogHeader>
      {result ? (
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-green-600 font-medium text-sm">
            <CheckCircle2 size={16} /> Đã đăng thành công!
          </div>
          <div className="flex items-center gap-2 bg-muted rounded-xl p-3">
            <span className="text-xs font-mono truncate flex-1">{result}</span>
            <button
              onClick={() => {
                navigator.clipboard.writeText(result);
                toast({ title: 'Đã sao chép liên kết' });
              }}
              className="p-1.5 rounded-md hover:bg-background"
            >
              <Copy size={14} />
            </button>
            <a href={result} target="_blank" rel="noopener noreferrer" className="p-1.5 rounded-md hover:bg-background">
              <ExternalLink size={14} />
            </a>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => openModal(null)} className="bg-primary hover:bg-primary/90">Xong</Button>
          </div>
        </div>
      ) : (
        <div className="space-y-3.5">
          <div>
            <label className="text-[13px] font-medium">Tên trang</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Trang web của Shark"
              className="w-full mt-1 h-10 px-3 rounded-xl border bg-background text-sm outline-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <div>
            <label className="text-[13px] font-medium">Nội dung HTML</label>
            <textarea
              value={html}
              onChange={(e) => setHtml(e.target.value)}
              placeholder={previewSrc ? 'Đã nạp từ bản xem trước — có thể chỉnh.' : '<!DOCTYPE html> ...'}
              rows={6}
              className="w-full mt-1 p-3 rounded-xl border bg-background text-xs font-mono outline-none resize-none focus:ring-2 focus:ring-primary/30"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => openModal(null)}>Huỷ</Button>
            <Button onClick={publish} disabled={!html.trim() || busy} className="bg-primary hover:bg-primary/90">
              {busy ? <Loader2 size={14} className="animate-spin" /> : 'Đăng lên web'}
            </Button>
          </div>
        </div>
      )}
    </DialogContent>
  );
}

// ---------- Modal Web đã đăng ----------
function SitesModal() {
  const openModal = useAppStore((s) => s.openModal);
  const sites = useAppStore((s) => s.sites);
  const deleteSite = useAppStore((s) => s.deleteSite);
  const openPreview = useAppStore((s) => s.openPreview);
  const previewSrc = useAppStore((s) => s.previewSrc);

  const openSite = (id: string) => {
    window.open(`/api/sites/${id}/`, '_blank');
  };

  const openLocal = (id: string) => {
    openPreview(`/api/sites/${id}`);
    openModal(null);
  };

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <Globe size={17} className="text-primary" /> Web đã đăng
        </DialogTitle>
        <DialogDescription>
          Các trang web bạn đã đăng công khai — ai có liên kết đều xem được.
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-1.5 max-h-[60vh] overflow-y-auto">
        {sites.length === 0 ? (
          <div className="p-4 rounded-xl border border-dashed text-center text-xs text-muted-foreground">
            Chưa đăng trang nào. Hỏi AI tạo website, bấm “Lên web” ở tab Xem trước hoặc icon Globe trên khối code HTML.
          </div>
        ) : (
          sites.map((st) => (
            <div key={st.id} className="group flex items-center gap-2.5 p-2.5 rounded-xl border bg-card">
              <span className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
                <Globe size={16} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-medium truncate flex items-center gap-1.5">
                  {st.name}
                  {st.multi && (
                    <span className="text-[9px] font-semibold text-primary bg-primary/10 rounded-full px-1.5 py-0.5 shrink-0">
                      đa tệp · {st.fileCount}
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-muted-foreground">
                  {st.views} lượt xem · {new Date(st.createdAt).toLocaleString('vi-VN')}
                </div>
              </div>
              <button
                onClick={() => openLocal(st.id)}
                className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"
                title="Xem trước trong app"
              >
                <Eye size={14} />
              </button>
              <button
                onClick={() => openSite(st.id)}
                className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"
                title="Mở liên kết công khai"
              >
                <ExternalLink size={14} />
              </button>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(`${window.location.origin}/api/sites/${st.id}/`);
                  toast({ title: 'Đã sao chép liên kết' });
                }}
                className="p-1.5 rounded-md hover:bg-accent text-muted-foreground"
                title="Sao chép liên kết"
              >
                <Copy size={14} />
              </button>
              <button
                onClick={() => {
                  if (confirm(`Xoá trang "${st.name}"?`)) deleteSite(st.id);
                }}
                className="p-1.5 rounded-md hover:bg-destructive/10 text-destructive"
                title="Xoá"
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))
        )}
      </div>
      {previewSrc && (
        <p className="text-[10px] text-muted-foreground">Đang xem trước: {previewSrc.slice(0, 60)}</p>
      )}
      <div className="flex justify-end">
        <Button onClick={() => openModal(null)} className="bg-primary hover:bg-primary/90">Đóng</Button>
      </div>
    </DialogContent>
  );
}

// ---------- Modal Đăng nhập (2 tab: Tạo tài khoản / Đăng nhập) ----------
function GoogleIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47a5.57 5.57 0 0 1-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09A11.99 11.99 0 0 0 12 24z" />
      <path fill="#FBBC05" d="M5.27 14.29A7.2 7.2 0 0 1 4.89 12c0-.8.14-1.57.38-2.29V6.62H1.29a12 12 0 0 0 0 10.76l3.98-3.09z" />
      <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.69 1.29 6.62l3.98 3.09C6.22 6.86 8.87 4.75 12 4.75z" />
    </svg>
  );
}

function LoginModal() {
  const openModal = useAppStore((s) => s.openModal);
  const loginPassword = useAppStore((s) => s.loginPassword);
  const registerAccount = useAppStore((s) => s.registerAccount);
  const googleConfigured = useAppStore((s) => s.googleConfigured);
  const authError = useAppStore((s) => s.authError);
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null); // banner xanh: gợi ý bước tiếp theo

  const error = authError || localError;

  const switchTab = (t: 'login' | 'register') => {
    setTab(t);
    setLocalError(null);
    setInfo(null);
    useAppStore.setState({ authError: null });
  };

  const submit = async () => {
    setLocalError(null);
    setInfo(null);
    useAppStore.setState({ authError: null });
    if (!email.trim() || !password) {
      setLocalError('Nhập đủ email và mật khẩu');
      return;
    }
    if (tab === 'register') {
      if (password.length < 6) {
        setLocalError('Mật khẩu cần tối thiểu 6 ký tự');
        return;
      }
      if (password !== confirm) {
        setLocalError('Mật khẩu nhập lại chưa khớp');
        return;
      }
    }
    setBusy(true);
    if (tab === 'login') {
      const res = await loginPassword(email, password);
      setBusy(false);
      if (res === 'ok') {
        toast({
          title: 'Đăng nhập thành công',
          description: 'Phiên chat đã được lưu vào tài khoản — đồng bộ trên mọi thiết bị',
        });
        openModal(null);
      } else if (res === 'no_password') {
        // Tài khoản cũ chưa từng đặt mật khẩu → tự chuyển sang tab Tạo tài khoản,
        // giữ nguyên email, chỉ cần điền tên + mật khẩu là xong (lịch sử chat giữ nguyên)
        setTab('register');
        setPassword('');
        setConfirm('');
        setInfo(
          `Email ${email} đã có dữ liệu chat từ trước nhưng chưa đặt mật khẩu. Đặt mật khẩu ngay bên dưới để tiếp tục dùng tài khoản này — toàn bộ lịch sử được giữ nguyên.`
        );
      }
      // 'error' → authError do store đặt, hiện inline
    } else {
      const ok = await registerAccount(name, email, password);
      setBusy(false);
      if (ok) {
        toast({
          title: 'Đã tạo tài khoản & đăng nhập',
          description: 'Phiên chat đã được lưu vào tài khoản — đồng bộ trên mọi thiết bị',
        });
        openModal(null);
      }
    }
  };

  const inputCls =
    'w-full h-11 rounded-xl border bg-background px-3.5 text-[14px] outline-none focus:border-primary';

  return (
    <DialogContent className="max-w-sm">
      <DialogHeader>
        <DialogTitle className="text-center text-xl">Đăng nhập Shark</DialogTitle>
        <DialogDescription className="text-center">
          Tài khoản lưu 60 ngày — thoát web hay sang máy khác, đăng nhập lại là thấy ngay lịch sử chat.
        </DialogDescription>
      </DialogHeader>

      <div className="space-y-3 pt-1">
        {googleConfigured ? (
          <a
            href="/api/auth/google"
            className="w-full flex items-center justify-center gap-2.5 h-11 rounded-xl border bg-background hover:bg-accent text-[14px] font-medium transition-colors"
          >
            <GoogleIcon /> Đăng nhập bằng Google
          </a>
        ) : null}

        <div className="flex items-center gap-3">
          <span className="h-px bg-border flex-1" />
          <span className="text-[11px] text-muted-foreground">
            {googleConfigured ? 'hoặc dùng email' : 'dùng email của bạn'}
          </span>
          <span className="h-px bg-border flex-1" />
        </div>

        {/* 2 tab: Tạo tài khoản / Đăng nhập */}
        <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-secondary">
          {(['register', 'login'] as const).map((t) => (
            <button
              key={t}
              onClick={() => switchTab(t)}
              className={cn(
                'h-9 rounded-lg text-[13px] font-medium transition-all',
                tab === t
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {t === 'register' ? 'Tạo tài khoản' : 'Đăng nhập'}
            </button>
          ))}
        </div>

        {tab === 'register' && (
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Tên hiển thị (vd: Lam)"
            className={inputCls}
          />
        )}

        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email (vd: lam@example.com)"
          className={inputCls}
        />

        <div className="relative">
          <input
            type={showPw ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            placeholder={tab === 'register' ? 'Mật khẩu (tối thiểu 6 ký tự)' : 'Mật khẩu'}
            className={cn(inputCls, 'pr-11')}
          />
          <button
            type="button"
            tabIndex={-1}
            onClick={() => setShowPw((v) => !v)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
            title={showPw ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}
          >
            {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>

        {tab === 'register' && (
          <input
            type={showPw ? 'text' : 'password'}
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            placeholder="Nhập lại mật khẩu"
            className={inputCls}
          />
        )}

        {info && (
          <div className="rounded-xl border border-primary/30 bg-primary/5 px-3 py-2 text-[12.5px] text-primary leading-snug">
            {info}
          </div>
        )}

        {error && (
          <div className="rounded-xl border border-destructive/40 bg-destructive/5 px-3 py-2 text-[12.5px] text-destructive leading-snug">
            {error}
          </div>
        )}

        <Button onClick={submit} disabled={busy} className="w-full h-11">
          {busy ? <Loader2 size={16} className="animate-spin mr-1.5" /> : null}
          {tab === 'login' ? 'Đăng nhập' : 'Tạo tài khoản & đăng nhập'}
        </Button>

        <p className="text-[11px] text-muted-foreground text-center leading-snug">
          Cùng một email + mật khẩu dùng được trên mọi thiết bị — lịch sử chat, API key và cài đặt
          được đồng bộ. Xem <a href="/terms" target="_blank" className="underline">Điều khoản &amp; Dịch vụ</a>.
        </p>
      </div>
    </DialogContent>
  );
}

// ---------- Wrapper ----------
export function Modals() {
  const modal = useAppStore((s) => s.modal);
  const openModal = useAppStore((s) => s.openModal);
  return (
    <Dialog open={!!modal} onOpenChange={(v) => !v && openModal(null)}>
      {modal === 'project' && <ProjectModal />}
      {modal === 'groupai' && <GroupAIModal />}
      {modal === 'api' && <ApiModal />}
      {modal === 'skills' && <SkillsModal />}
      {modal === 'publish' && <PublishModal />}
      {modal === 'sites' && <SitesModal />}
      {modal === 'notifications' && <GroupAIModal />}
      {modal === 'login' && <LoginModal />}
    </Dialog>
  );
}
