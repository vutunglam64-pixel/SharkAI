'use client';

import { useEffect, useRef } from 'react';
import {
  Users, Loader2,
} from 'lucide-react';
import { PERSONAS, type PersonaDef } from '@/lib/config';
import { useAppStore } from '@/store/app-store';
import { SharkLogo } from './logo';
import { ChatInput } from './input';
import { MessageBubble } from './messages';
import { SidebarExpandButton } from './sidebar';
import { PersonaAvatar, PERSONA_ICONS } from './persona';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

export { PERSONA_ICONS };

// ---------- 1 thẻ chuyên gia trong roster ----------
function RosterCard({ p, speaking }: { p: PersonaDef; speaking: boolean }) {
  return (
    <div
      className={cn(
        'flex items-center gap-2.5 px-2.5 py-2 rounded-xl border transition-all duration-300',
        speaking
          ? 'border-primary/45 bg-primary/5 shadow-sm scale-[1.015]'
          : 'bg-card border-transparent hover:bg-accent/60 hover:border-border'
      )}
    >
      <span className={speaking ? 'speaking-ring' : undefined} style={{ color: p.color }}>
        <PersonaAvatar p={p} size={32} />
      </span>
      <div className="min-w-0 flex-1">
        <div className="text-[12.5px] font-semibold truncate flex items-center gap-1.5">
          {p.name}
          {speaking && (
            <span className="text-[9px] font-semibold text-primary animate-pulse shrink-0">đang nói…</span>
          )}
        </div>
        <div className="text-[10.5px] text-muted-foreground truncate">{p.role}</div>
      </div>
      {p.tools && (
        <span className="text-[8.5px] font-semibold text-muted-foreground/80 bg-secondary rounded-full px-1.5 py-0.5 shrink-0">
          tool
        </span>
      )}
    </div>
  );
}

// ---------- dải avatar cuộn ngang trên mobile ----------
function MobileRosterStrip({ speakingId }: { speakingId: string | null }) {
  return (
    <div className="md:hidden flex gap-3 overflow-x-auto px-3 py-2 border-b bg-sidebar/40 shrink-0">
      {PERSONAS.map((p) => {
        const speaking = speakingId === p.id;
        return (
          <div key={p.id} className="flex flex-col items-center gap-1 shrink-0">
            <span className={speaking ? 'speaking-ring' : undefined} style={{ color: p.color }}>
              <PersonaAvatar p={p} size={34} />
            </span>
            <span className={cn('text-[9.5px] truncate w-12 text-center', speaking ? 'text-primary font-semibold' : 'text-muted-foreground')}>
              {p.name}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// ---------- màn hình chào của trang Group ----------
const GROUP_SUGGESTIONS = [
  'Team làm giúp mình một trang web giới thiệu quán cà phê đẹp mắt',
  'Làm bộ slide 8 trang về xu hướng AI 2026',
  'Viết chương trình Python quản lý chi tiêu rồi kiểm thử thử',
  'Lên kế hoạch chi tiết ra mắt app học tiếng Anh',
];

function GroupWelcome() {
  const fill = (t: string) => window.dispatchEvent(new CustomEvent('shark-fill-input', { detail: t }));
  return (
    <div className="flex flex-col items-center px-4 pt-8 pb-4 max-w-3xl mx-auto w-full">
      <div className="rounded-full logo-glow mb-4 anim-pop">
        <SharkLogo size={54} />
      </div>
      <h1 className="text-2xl sm:text-[27px] font-bold tracking-tight text-center text-gradient anim-rise anim-d1">
        Giao việc cho Team Shark
      </h1>
      <p className="text-sm text-muted-foreground mt-1.5 text-center anim-rise anim-d2 max-w-xl">
        8 chuyên gia — <b>Sếp</b> điều phối, <b>Agent</b> đa nhiệm, <b>Slide</b>, <b>Lập trình viên</b>,{' '}
        <b>Terminal</b>, <b>Kiểm tra</b>, <b>Kiểm thử</b>, <b>Kết quả</b> — cùng làm việc như một team thật.
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full mt-7 stagger">
        {PERSONAS.map((p) => (
          <div key={p.id} className="rounded-2xl border bg-card p-3 text-center hover-lift">
            <PersonaAvatar p={p} size={38} className="mx-auto" />
            <div className="text-[12.5px] font-semibold mt-2 leading-tight">{p.name}</div>
            <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{p.role}</div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap justify-center gap-2 mt-6 anim-rise anim-d5">
        {GROUP_SUGGESTIONS.map((s) => (
          <button
            key={s}
            onClick={() => fill(s)}
            className="press rounded-full border bg-card px-3.5 py-1.5 text-[12.5px] text-foreground/85 hover:border-primary/40 hover:bg-primary/5 transition-colors"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------- TRANG GROUP AI (bật Group AI → sang trang này, tắt → về chat thường) ----------
export function GroupPage() {
  const messages = useAppStore((s) => s.messages);
  const streaming = useAppStore((s) => s.streaming);
  const pendingPhase = useAppStore((s) => s.pendingPhase);
  const groupAI = useAppStore((s) => s.groupAI);
  const setGroupAI = useAppStore((s) => s.setGroupAI);
  const activePersonaId = useAppStore((s) => s.activePersonaId);
  const bottomRef = useRef<HTMLDivElement>(null);

  // ẩn dòng assistant tạm (không phải persona, chưa có nội dung) — chỉ là bản nháp stream
  const visibleMessages = messages.filter(
    (m) => !(m.role === 'assistant' && !m.model?.startsWith('persona:') && !m.content && !m.error)
  );

  // agent đang phát biểu: qua SSE (khi xem trực tiếp) hoặc qua tin nhắn streaming (khi poll nền)
  const speakingId = (() => {
    if (!streaming) return null;
    if (activePersonaId) return activePersonaId;
    for (let i = messages.length - 1; i >= 0; i--) {
      const m = messages[i];
      if (m.streaming && m.model?.startsWith('persona:')) return m.model.slice('persona:'.length);
    }
    return null;
  })();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: streaming ? 'auto' : 'smooth' });
  }, [messages, streaming]);

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-background anim-fade-in">
      {/* header trang group */}
      <header className="flex items-center gap-2 px-3 h-14 border-b bg-background/80 backdrop-blur shrink-0">
        <SidebarExpandButton />
        <SharkLogo size={24} />
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-sm font-bold tracking-tight">Group AI</span>
          <span className="hidden sm:inline-flex items-center gap-1 text-[10.5px] font-semibold text-primary bg-primary/10 rounded-full px-2 py-0.5">
            <Users size={10} /> 8 chuyên gia
          </span>
        </div>
        <div className="flex-1" />
        <label className="flex items-center gap-2.5 text-[12.5px] text-muted-foreground cursor-pointer select-none press">
          <span className="hidden sm:inline">Tắt để về chat thường</span>
          <Switch checked={groupAI} onCheckedChange={setGroupAI} />
        </label>
      </header>

      {/* vệt sáng chạy khi team đang làm việc */}
      {streaming && (
        <div className="h-[3px] bg-secondary progress-sheen shrink-0">
          <i />
        </div>
      )}

      <div className="flex-1 flex min-h-0">
        {/* roster bên trái (desktop) */}
        <aside className="hidden md:flex w-[240px] shrink-0 border-r flex-col bg-sidebar/40">
          <div className="px-3.5 pt-3.5 pb-2 text-[10.5px] font-semibold uppercase tracking-wider text-muted-foreground">
            Đội hình Shark
          </div>
          <div className="flex-1 overflow-y-auto px-2 pb-3 space-y-1.5 stagger">
            {PERSONAS.map((p) => (
              <RosterCard key={p.id} p={p} speaking={speakingId === p.id} />
            ))}
          </div>
          <div className="px-3.5 py-2.5 border-t text-[10px] text-muted-foreground/80 leading-snug">
            Sếp tự động giao việc đúng chuyên gia; <b>Kết quả</b> luôn tổng hợp cuối.
          </div>
        </aside>

        {/* khu chat team */}
        <div className="flex-1 flex flex-col min-w-0">
          {visibleMessages.length === 0 ? (
            <div className="flex-1 overflow-y-auto flex flex-col">
              <div className="flex-1 flex flex-col justify-center">
                <GroupWelcome />
              </div>
              <ChatInput />
            </div>
          ) : (
            <>
              <MobileRosterStrip speakingId={speakingId} />
              <div className="flex-1 overflow-y-auto">
                <div className="max-w-3xl mx-auto px-4 py-6 space-y-6">
                  {visibleMessages.map((m) => (
                    <MessageBubble key={m.id} msg={m} />
                  ))}
                  {streaming && pendingPhase && (
                    <div className="flex items-center gap-2 text-[13px] text-muted-foreground anim-rise">
                      <Loader2 size={13} className="animate-spin text-primary" />
                      {pendingPhase}
                    </div>
                  )}
                  <div ref={bottomRef} className="h-2" />
                </div>
              </div>
              <ChatInput />
            </>
          )}
        </div>
      </div>
    </div>
  );
}
