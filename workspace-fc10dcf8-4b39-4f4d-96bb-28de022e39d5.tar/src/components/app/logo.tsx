// Ảnh đại diện chính thức của Shark AI — chữ S phát sáng (do người dùng cung cấp)
export function SharkLogo({ size = 28, className = '' }: { size?: number; className?: string }) {
  return (
    <img
      src="/shark-avatar.png"
      alt="Shark AI"
      width={size}
      height={size}
      className={`rounded-full object-cover shrink-0 ${className}`}
      style={{ boxShadow: '0 0 0 1px rgba(23,23,26,0.06), 0 2px 12px -4px rgba(93,120,228,0.35)' }}
    />
  );
}

// giữ tên cũ để tương thích các import còn sót
export const NovaLogo = SharkLogo;
