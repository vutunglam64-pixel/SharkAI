'use client';

// Icon + avatar của 8 chuyên gia Team Shark — dùng chung group-page / messages / modals
// (file riêng để tránh import vòng)
import {
  Crown, Bot, Presentation, Code2, TerminalSquare, SearchCheck, FlaskConical,
  ClipboardCheck, Compass, Shield,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export const PERSONA_ICONS: Record<
  string,
  React.ComponentType<{ size?: number; className?: string }>
> = {
  crown: Crown,
  bot: Bot,
  presentation: Presentation,
  code: Code2,
  terminal: TerminalSquare,
  'search-check': SearchCheck,
  flask: FlaskConical,
  'clipboard-check': ClipboardCheck,
  compass: Compass, // persona cũ (architect)
  shield: Shield,   // persona cũ (reviewer)
};

export function PersonaAvatar({
  p,
  size = 34,
  className = '',
}: {
  p: { id?: string; name: string; role?: string; color: string; icon?: string };
  size?: number;
  className?: string;
}) {
  const Ico = PERSONA_ICONS[p.icon || ''] || Bot;
  return (
    <span
      className={cn(
        'rounded-full text-white flex items-center justify-center shrink-0 shadow-sm',
        className
      )}
      style={{ backgroundColor: p.color, width: size, height: size }}
      title={`${p.name}${p.role ? ` — ${p.role}` : ''}`}
    >
      <Ico size={Math.round(size * 0.5)} />
    </span>
  );
}
