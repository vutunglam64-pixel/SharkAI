'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  FileText, Folder, FolderOpen, RefreshCw, Plus, Trash2, Download, Save,
  X, Terminal as TerminalIcon, Eye, FolderTree, Package, Globe, Loader2, ChevronRight, ChevronDown, ExternalLink,
} from 'lucide-react';
import { useAppStore, type FileNode } from '@/store/app-store';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

// ================= File Tree =================
function TreeNode({ node, depth }: { node: FileNode; depth: number }) {
  const [open, setOpen] = useState(depth < 1);
  const loadFile = useLoadFile();
  const deleteNode = useDeleteNode();

  if (node.type === 'dir') {
    return (
      <div>
        <button
          onClick={() => setOpen(!open)}
          className="w-full flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-accent text-[13px] text-left"
          style={{ paddingLeft: depth * 12 + 8 }}
        >
          {open ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          {open ? <FolderOpen size={13} className="text-chart-3" /> : <Folder size={13} className="text-chart-3" />}
          <span className="truncate">{node.name}</span>
        </button>
        {open && node.children?.map((c) => <TreeNode key={c.path} node={c} depth={depth + 1} />)}
      </div>
    );
  }

  return (
    <div className="group flex items-center">
      <button
        onClick={() => loadFile(node.path)}
        className="flex-1 flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-accent text-[13px] text-left min-w-0"
        style={{ paddingLeft: depth * 12 + 20 }}
      >
        <FileText size={13} className="text-muted-foreground shrink-0" />
        <span className="truncate">{node.name}</span>
      </button>
      <span className="hidden group-hover:flex items-center gap-0.5 pr-1.5">
        <a
          href={`/api/preview/${node.path}?download=1`}
          download
          className="p-1 rounded hover:bg-accent"
          title="Tải xuống"
        >
          <Download size={11} />
        </a>
        <button
          onClick={() => {
            if (confirm(`Xoá ${node.name}?`)) deleteNode(node.path);
          }}
          className="p-1 rounded hover:bg-destructive/10 text-destructive"
          title="Xoá"
        >
          <Trash2 size={11} />
        </button>
      </span>
    </div>
  );
}

function useLoadFile() {
  const setPanelTab = useAppStore((s) => s.setPanelTab);
  return useCallback(
    async (path: string) => {
      const res = await fetch('/api/workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'read', path }),
      });
      const data = await res.json();
      if (data.error) {
        toast({ title: data.error, variant: 'destructive' });
        return;
      }
      setPanelTab('files');
      useAppStore.getState().setOpenedFile({ path, content: data.content });
    },
    [setPanelTab]
  );
}

function useDeleteNode() {
  const bumpFiles = useAppStore((s) => s.bumpFiles);
  return useCallback(
    async (path: string) => {
      await fetch('/api/workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', path }),
      });
      useAppStore.getState().setOpenedFile(null);
      bumpFiles();
    },
    [bumpFiles]
  );
}

// ================= Tab Thư mục =================
function FilesTab() {
  const filesVersion = useAppStore((s) => s.filesVersion);
  const bumpFiles = useAppStore((s) => s.bumpFiles);
  const openedFile = useAppStore((s) => s.openedFile);
  const [tree, setTree] = useState<FileNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishingMulti, setPublishingMulti] = useState(false);
  const draftRef = useRef<HTMLTextAreaElement>(null);

  const loadTree = useCallback(async () => {
    try {
      const res = await fetch('/api/workspace');
      const data = await res.json();
      setTree(data.tree || []);
    } catch {}
    setLoading(false);
  }, []);

  useEffect(() => {
    const t = setTimeout(loadTree, 0);
    return () => clearTimeout(t);
  }, [loadTree, filesVersion]);

  const save = async () => {
    if (!openedFile) return;
    setSaving(true);
    await fetch('/api/workspace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'write', path: openedFile.path, content: draftRef.current?.value ?? '' }),
    });
    setSaving(false);
    toast({ title: `Đã lưu ${openedFile.path}` });
  };

  const newFile = async () => {
    const name = prompt('Tên file mới (vd: index.html, app.py):');
    if (!name) return;
    await fetch('/api/workspace', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'write', path: name, content: '' }),
    });
    bumpFiles();
  };

  const totalFiles = (nodes: FileNode[]): number =>
    nodes.reduce((a, n) => a + (n.type === 'file' ? 1 : totalFiles(n.children || [])), 0);
  const fileCount = totalFiles(tree);

  // Đăng CẢ THƯ MỤC (index.html + style.css + app.js + ảnh...) thành 1 trang web công khai
  const publishMulti = async () => {
    const name = prompt('Tên trang web của bạn:', 'Website của tôi');
    if (name === null) return;
    setPublishingMulti(true);
    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ multi: true, name: name.trim() || 'Website của tôi' }),
      });
      const data = await res.json();
      if (data.url) {
        const full = `${window.location.origin}${data.url}`;
        await navigator.clipboard.writeText(full).catch(() => {});
        useAppStore.getState().refreshSites();
        useAppStore.getState().openPreview(data.url);
        toast({
          title: `Đã đăng ${data.fileCount} tệp lên web!`,
          description: 'Liên kết đã được sao chép — mở tab mới để xem',
        });
      } else {
        toast({ title: data.error || 'Đăng thất bại', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Lỗi kết nối khi đăng web', variant: 'destructive' });
    } finally {
      setPublishingMulti(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-1 px-3 py-2 border-b shrink-0">
        <button
          onClick={() => {
            setLoading(true);
            loadTree();
          }}
          className="p-1.5 rounded-md hover:bg-accent"
          title="Làm mới"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
        </button>
        <button onClick={newFile} className="p-1.5 rounded-md hover:bg-accent" title="Tạo file mới">
          <Plus size={14} />
        </button>
        <div className="flex-1" />
        <a
          href="/api/zip"
          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-primary/10 text-primary hover:bg-primary/15 text-xs font-medium"
        >
          <Package size={13} /> Xuất ZIP
        </a>
      </div>

      {/* Đăng cả thư mục (đa tệp) lên web — nằm ngay dưới nút Xuất ZIP */}
      <div className="px-3 py-2 border-b shrink-0">
        <button
          onClick={publishMulti}
          disabled={publishingMulti || fileCount === 0}
          className="w-full inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-medium disabled:opacity-50 disabled:cursor-not-allowed"
          title="Đăng toàn bộ index.html + CSS + JS + ảnh thành 1 trang web công khai"
        >
          {publishingMulti ? <Loader2 size={13} className="animate-spin" /> : <Globe size={13} />}
          Đăng cả thư mục lên web
          {fileCount > 0 && <span className="opacity-75">({fileCount} tệp)</span>}
        </button>
      </div>

      <div className={cn('min-h-0 flex-1', openedFile ? 'grid grid-rows-[auto_1fr]' : '')}>
        <div className={cn('overflow-y-auto p-2', openedFile && 'max-h-48 border-b')}>
          {tree.length === 0 && !loading ? (
            <div className="text-center text-xs text-muted-foreground py-8 px-4">
              Thư mục trống. Hỏi AI tạo website/code — file sẽ xuất hiện ở đây, hoặc bấm “+” để tự tạo.
            </div>
          ) : (
            tree.map((n) => <TreeNode key={n.path} node={n} depth={0} />)
          )}
        </div>

        {openedFile && (
          <div className="flex flex-col min-h-0">
            <div className="flex items-center gap-2 px-3 py-1.5 border-b shrink-0">
              <FileText size={13} className="text-primary" />
              <span className="text-xs font-mono font-medium truncate flex-1">{openedFile.path}</span>
              <button
                onClick={() => {
                  if (/\.html?$/i.test(openedFile.path)) {
                    useAppStore.getState().openPreview(
                      `/api/preview-bundle?path=${encodeURIComponent(openedFile.path)}`
                    );
                  } else {
                    toast({ title: 'Chỉ xem trước được file HTML (bản xem trước tự ghép CSS/JS)' });
                  }
                }}
                className="p-1.5 rounded-md hover:bg-accent"
                title="Xem trước (ghép cả CSS/JS đi kèm)"
              >
                <Eye size={13} />
              </button>
              <button onClick={save} className="p-1.5 rounded-md hover:bg-accent" title="Lưu (Ctrl+S)">
                {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />}
              </button>
              <button
                onClick={() => useAppStore.getState().setOpenedFile(null)}
                className="p-1.5 rounded-md hover:bg-accent"
              >
                <X size={13} />
              </button>
            </div>
            <textarea
              key={openedFile.path}
              ref={draftRef}
              defaultValue={openedFile.content}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                  e.preventDefault();
                  save();
                }
              }}
              spellCheck={false}
              className="flex-1 w-full resize-none bg-[#212120] text-[#e6e2d8] font-mono text-[12.5px] p-3 outline-none"
            />
          </div>
        )}
      </div>
    </div>
  );
}

// ================= Tab Terminal =================
interface TermLine {
  kind: 'cmd' | 'out' | 'err' | 'info';
  text: string;
}

function TerminalTab() {
  const [lines, setLines] = useState<TermLine[]>([
    { kind: 'info', text: 'Shark Terminal — thư mục dự án: /workspace' },
    { kind: 'info', text: 'Gõ lệnh rồi Enter. Thử: ls, node -v, python3 --version, echo hello' },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const historyRef = useRef<string[]>([]);
  const histPosRef = useRef(-1);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const run = async (command: string) => {
    setLines((l) => [...l, { kind: 'cmd', text: command }]);
    setBusy(true);
    try {
      const res = await fetch('/api/terminal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command }),
      });
      const data = await res.json();
      if (data.stdout) setLines((l) => [...l, { kind: 'out', text: data.stdout }]);
      if (data.stderr) setLines((l) => [...l, { kind: 'err', text: data.stderr }]);
      if (!data.stdout && !data.stderr) setLines((l) => [...l, { kind: 'out', text: '(hoàn tất)' }]);
    } catch {
      setLines((l) => [...l, { kind: 'err', text: 'Lỗi kết nối terminal' }]);
    }
    setBusy(false);
    inputRef.current?.focus();
  };

  const submit = () => {
    const cmd = input.trim();
    if (!cmd || busy) return;
    setInput('');
    historyRef.current.unshift(cmd);
    histPosRef.current = -1;
    run(cmd);
  };

  const suggestions = ['ls', 'node -v', 'python3 --version', 'echo "Hello Shark"'];

  return (
    <div className="flex flex-col h-full bg-[#1a1a19]">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/10 shrink-0">
        <TerminalIcon size={13} className="text-green-400" />
        <span className="text-xs text-white/60 flex-1">bash — /workspace</span>
        <button
          onClick={() => setLines([])}
          className="text-[11px] text-white/50 hover:text-white px-2 py-0.5 rounded"
        >
          Xoá
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-3 font-mono text-[12.5px] leading-relaxed">
        {lines.map((l, i) => (
          <div
            key={i}
            className={cn(
              'whitespace-pre-wrap break-all',
              l.kind === 'cmd' && 'text-green-400',
              l.kind === 'err' && 'text-red-400',
              l.kind === 'out' && 'text-white/85',
              l.kind === 'info' && 'text-white/40'
            )}
          >
            {l.kind === 'cmd' ? `$ ${l.text}` : l.text}
          </div>
        ))}
        {busy && (
          <div className="text-yellow-400/80 animate-pulse flex items-center gap-1.5">
            <Loader2 size={11} className="animate-spin" /> đang chạy...
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      {lines.length <= 2 && (
        <div className="flex flex-wrap gap-1.5 px-3 pb-2">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => run(s)}
              className="text-[11px] font-mono px-2 py-1 rounded-md bg-white/5 text-white/60 hover:bg-white/10 border border-white/10"
            >
              {s}
            </button>
          ))}
        </div>
      )}
      <div className="flex items-center gap-2 px-3 py-2.5 border-t border-white/10">
        <span className="text-green-400 font-mono text-[13px] shrink-0">$</span>
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') submit();
            if (e.key === 'ArrowUp') {
              e.preventDefault();
              histPosRef.current = Math.min(histPosRef.current + 1, historyRef.current.length - 1);
              setInput(historyRef.current[histPosRef.current] || '');
            }
            if (e.key === 'ArrowDown') {
              e.preventDefault();
              histPosRef.current = Math.max(histPosRef.current - 1, -1);
              setInput(histPosRef.current < 0 ? '' : historyRef.current[histPosRef.current]);
            }
          }}
          placeholder="Nhập lệnh..."
          className="flex-1 bg-transparent text-white font-mono text-[13px] outline-none placeholder:text-white/30"
        />
      </div>
    </div>
  );
}

// ================= Tab Xem trước =================
function PreviewTab() {
  const previewSrc = useAppStore((s) => s.previewSrc);
  const setPreviewSrc = useAppStore((s) => s.setPreviewSrc);
  const [key, setKey] = useState(0);
  const [publishing, setPublishing] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState<string | null>(null);

  const isSrcdoc = previewSrc?.startsWith('srcdoc:');
  const isBundle = previewSrc?.startsWith('/api/preview-bundle?');
  const bundlePath = isBundle ? new URLSearchParams(previewSrc!.split('?')[1]).get('path') : null;
  const displayUrl = isSrcdoc
    ? '(bản nháp trong bộ nhớ)'
    : isBundle
      ? `xem trước đa tệp: ${bundlePath}`
      : previewSrc || '';

  const publish = async () => {
    setPublishing(true);
    try {
      let body: Record<string, unknown> = {};
      let name = 'trang-web-shark';
      if (isSrcdoc) {
        body = { html: previewSrc!.slice(7) };
      } else if (previewSrc) {
        if (isBundle) {
          const p = bundlePath || '';
          name = (p.split('/').pop() || name).replace(/\.html?$/i, '');
          body = { path: p };
        } else if (previewSrc.startsWith('/api/preview/')) {
          const p = decodeURIComponent(previewSrc.replace('/api/preview/', ''));
          name = (p.split('/').pop() || name).replace(/\.html?$/i, '');
          body = { path: p };
        } else if (previewSrc.includes('/api/sites/')) {
          const id = previewSrc.split('/api/sites/')[1].replace(/\/+$/, '');
          const res = await fetch(`/api/sites/${id}`);
          if (!res.ok) {
            toast({ title: 'Không đọc được trang để đăng', variant: 'destructive' });
            setPublishing(false);
            return;
          }
          body = { html: await res.text() };
        } else {
          const res = await fetch(previewSrc);
          if (!res.ok) {
            toast({ title: 'Không đọc được trang để đăng', variant: 'destructive' });
            setPublishing(false);
            return;
          }
          body = { html: await res.text() };
        }
      }
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...body, name }),
      });
      const data = await res.json();
      if (data.url) {
        const full = `${window.location.origin}${data.url}`;
        setPublishedUrl(full);
        await navigator.clipboard.writeText(full).catch(() => {});
        useAppStore.getState().refreshSites();
        toast({ title: 'Đã đăng lên web!', description: 'Liên kết đã được sao chép' });
      } else {
        toast({ title: data.error || 'Đăng thất bại', variant: 'destructive' });
      }
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-3 py-2 border-b shrink-0">
        <div className="flex-1 flex items-center gap-2 bg-muted rounded-lg px-2.5 py-1.5 min-w-0">
          <Globe size={13} className="text-muted-foreground shrink-0" />
          <span className="text-xs font-mono truncate text-muted-foreground">
            {displayUrl || 'chưa có trang nào'}
          </span>
        </div>
        {previewSrc && (
          <>
            <button onClick={() => setKey((k) => k + 1)} className="p-1.5 rounded-md hover:bg-accent" title="Tải lại">
              <RefreshCw size={14} />
            </button>
            {!isSrcdoc && (
              <a
                href={previewSrc}
                target="_blank"
                rel="noopener noreferrer"
                className="p-1.5 rounded-md hover:bg-accent"
                title="Mở tab mới"
              >
                <ExternalLink size={14} />
              </a>
            )}
            <button
              onClick={publish}
              disabled={publishing}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-medium disabled:opacity-60"
            >
              {publishing ? <Loader2 size={12} className="animate-spin" /> : <Globe size={12} />}
              Lên web
            </button>
          </>
        )}
      </div>

      {publishedUrl && (
        <div className="px-3 py-2 bg-green-500/10 border-b text-xs flex items-center gap-2">
          <span className="truncate flex-1 font-mono">{publishedUrl}</span>
          <button
            onClick={() => navigator.clipboard.writeText(publishedUrl)}
            className="text-green-600 hover:underline shrink-0 font-medium"
          >
            Sao chép
          </button>
        </div>
      )}

      <div className="flex-1 min-h-0 bg-white">
        {!previewSrc ? (
          <div className="h-full flex flex-col items-center justify-center text-muted-foreground gap-3 px-6 text-center">
            <Eye size={32} className="opacity-40" />
            <div>
              <p className="font-medium text-sm text-foreground">Chưa có gì để xem trước</p>
              <p className="text-xs mt-1">
                Hỏi AI tạo website → bấm “Xem trước” trên thẻ tệp (tự ghép cả CSS/JS), hoặc chọn file .html trong tab Thư mục.
              </p>
            </div>
          </div>
        ) : isSrcdoc ? (
          <iframe
            key={key}
            srcDoc={previewSrc.slice(7)}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-forms allow-popups"
            title="Xem trước"
          />
        ) : (
          <iframe
            key={key}
            src={previewSrc}
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-forms allow-popups allow-same-origin"
            title="Xem trước"
          />
        )}
      </div>
    </div>
  );
}

// ================= Panel chính =================
export function RightPanel() {
  const panelOpen = useAppStore((s) => s.panelOpen);
  const panelTab = useAppStore((s) => s.panelTab);
  const setPanelTab = useAppStore((s) => s.setPanelTab);
  const setPanelOpen = useAppStore((s) => s.setPanelOpen);

  if (!panelOpen) return null;

  const tabs: { id: 'files' | 'terminal' | 'preview'; label: string; icon: React.ReactNode }[] = [
    { id: 'files', label: 'Thư mục', icon: <FolderTree size={13} /> },
    { id: 'terminal', label: 'Terminal', icon: <TerminalIcon size={13} /> },
    { id: 'preview', label: 'Xem trước', icon: <Eye size={13} /> },
  ];

  return (
    <aside className="h-full w-[400px] max-w-[45vw] border-l bg-background flex flex-col shrink-0 animate-in slide-in-from-right-4 duration-200">
      <div className="flex items-center gap-1 px-2 py-2 border-b shrink-0">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setPanelTab(t.id)}
            className={cn(
              'inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12.5px] font-medium transition-colors',
              panelTab === t.id ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:bg-accent'
            )}
          >
            {t.icon}
            {t.label}
          </button>
        ))}
        <div className="flex-1" />
        <button onClick={() => setPanelOpen(false)} className="p-1.5 rounded-md hover:bg-accent text-muted-foreground">
          <X size={15} />
        </button>
      </div>
      <div className="flex-1 min-h-0">
        {panelTab === 'files' && <FilesTab />}
        {panelTab === 'terminal' && <TerminalTab />}
        {panelTab === 'preview' && <PreviewTab />}
      </div>
    </aside>
  );
}
