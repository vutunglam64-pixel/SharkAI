'use client';

import { memo, useEffect, useState } from 'react';
import {
  Brain, ChevronDown, ChevronRight, Copy, Check, Globe, Image as ImageIcon,
  Loader2, RefreshCw, Terminal, FileText, Folder, Search, Volume2,
  Film, AlertCircle, ListTree, Pencil, X, Download, Eye, Cloud,
} from 'lucide-react';
import { Markdown } from './markdown';
import { useAppStore, type ChatMessage, type ChatEvent, type ToolResultData } from '@/store/app-store';
import { getModel } from '@/lib/config';
import { SharkLogo } from './logo';
import { PersonaAvatar } from './persona';
import { toast } from '@/hooks/use-toast';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

// Mở rộng ngôn ngữ cho mọi loại tệp Shark tạo (toml, ini, csv, env...)
const EXT_LANG: Record<string, string> = {
  html: 'markup', htm: 'markup', xml: 'markup', svg: 'markup',
  css: 'css', scss: 'scss',
  js: 'javascript', mjs: 'javascript', jsx: 'jsx',
  ts: 'typescript', tsx: 'tsx',
  py: 'python', rb: 'ruby', php: 'php', java: 'java',
  c: 'c', h: 'c', cpp: 'cpp', hpp: 'cpp', cs: 'csharp', go: 'go', rs: 'rust',
  sh: 'bash', bash: 'bash', zsh: 'bash',
  json: 'json', toml: 'toml', yaml: 'yaml', yml: 'yaml',
  ini: 'ini', cfg: 'ini', conf: 'ini', env: 'ini', properties: 'ini',
  md: 'markdown', sql: 'sql', csv: 'csv', txt: 'text', log: 'text',
  dockerfile: 'docker', makefile: 'makefile',
};

function extOf(p: string): string {
  const base = p.split('/').pop() || '';
  const parts = base.split('.');
  if (parts.length > 1) return parts.pop()!.toLowerCase();
  return base.toLowerCase(); // Dockerfile, Makefile...
}

// ================= Khối suy nghĩ (kiểu DeepSeek — hiện TRƯỚC câu trả lời) =================
function ThinkingBlock({ text, live, hasAnswer }: { text: string; live: boolean; hasAnswer?: boolean }) {
  const [userOpen, setUserOpen] = useState<boolean | null>(null);
  const open = userOpen ?? live;
  return (
    <div className="mb-3 rounded-xl border border-border/70 bg-muted/50 overflow-hidden">
      <button
        onClick={() => setUserOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors"
      >
        <Brain size={15} className="text-primary" />
        <span className="font-medium">{live && !hasAnswer ? 'Đang suy nghĩ...' : live ? 'Suy nghĩ' : 'Đã suy nghĩ'}</span>
        {live && !hasAnswer ? (
          <span className="flex gap-1 ml-1 text-primary">
            <span className="thinking-dot" />
            <span className="thinking-dot" />
            <span className="thinking-dot" />
          </span>
        ) : (
          open ? <ChevronDown size={14} className="ml-auto" /> : <ChevronRight size={14} className="ml-auto" />
        )}
      </button>
      {open && (
        <div className="px-4 py-3 text-[13px] leading-relaxed text-muted-foreground whitespace-pre-wrap border-t border-border/60 max-h-72 overflow-y-auto">
          {text}
        </div>
      )}
    </div>
  );
}

// ================= Bản tự phản biện (chế độ Kết quả tốt nhất) =================
function ReflectionBlock({ text }: { text: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mb-3 rounded-xl border border-border/70 bg-muted/50 overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:bg-muted transition-colors"
      >
        <RefreshCw size={15} className="text-chart-2" />
        <span className="font-medium">Bản tự phản biện</span>
        {open ? <ChevronDown size={14} className="ml-auto" /> : <ChevronRight size={14} className="ml-auto" />}
      </button>
      {open && (
        <div className="px-4 py-3 text-[13px] text-muted-foreground border-t border-border/60 max-h-72 overflow-y-auto">
          <Markdown content={text} />
        </div>
      )}
    </div>
  );
}

// ================= Hộp xem code tệp (khi bấm vào file Shark tạo) =================
function FileCodeDialog({ path, open, onClose }: { path: string; open: boolean; onClose: () => void }) {
  const [content, setContent] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open || !path) return;
    let cancelled = false;
    setContent('');
    setLoading(true);
    setError(null);
    (async () => {
      try {
        const res = await fetch('/api/workspace', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'read', path }),
        });
        const data = await res.json();
        if (cancelled) return;
        if (data.error) setError(data.error);
        else setContent(data.content || '');
      } catch {
        if (!cancelled) setError('Không đọc được tệp');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [open, path]);

  const fileName = path.split('/').pop() || path;
  const ext = extOf(path);
  const lang = EXT_LANG[ext] || 'text';

  const copy = async () => {
    await navigator.clipboard.writeText(content).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const download = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[80vh] flex flex-col p-0 gap-0">
        <DialogHeader className="px-4 py-3 border-b flex-row items-center justify-between space-y-0">
          <DialogTitle className="text-sm font-mono flex items-center gap-2 min-w-0">
            <FileText size={15} className="text-chart-2 shrink-0" />
            <span className="truncate">{path}</span>
          </DialogTitle>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={copy}
              disabled={!content}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[12px] hover:bg-accent transition-colors disabled:opacity-50"
            >
              {copied ? <Check size={12} className="text-green-600" /> : <Copy size={12} />}
              Sao chép
            </button>
            <button
              onClick={download}
              disabled={!content}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-[12px] hover:bg-accent transition-colors disabled:opacity-50"
            >
              <Download size={12} /> Tải về
            </button>
          </div>
        </DialogHeader>
        <div className="flex-1 overflow-auto">
          {loading ? (
            <div className="flex items-center justify-center py-16 text-muted-foreground">
              <Loader2 size={20} className="animate-spin mr-2" /> Đang đọc tệp...
            </div>
          ) : error ? (
            <div className="flex items-center justify-center gap-2 py-16 text-[13px] text-destructive">
              <AlertCircle size={15} /> {error}
            </div>
          ) : (
            <SyntaxHighlighter
              language={lang}
              style={oneDark}
              customStyle={{ margin: 0, borderRadius: 0, fontSize: '12px' }}
              wrapLongLines
            >
              {content}
            </SyntaxHighlighter>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ================= Tool events =================
function ToolEventBlock({ ev }: { ev: Extract<ChatEvent, { kind: 'tool' }> }) {
  const [open, setOpen] = useState(false);
  const openPreview = useAppStore((s) => s.openPreview);
  const setPanelTab = useAppStore((s) => s.setPanelTab);
  const [viewPath, setViewPath] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const r: ToolResultData = ev.result || { type: 'error' };

  // ----- terminal -----
  if (r.type === 'terminal') {
    const failed = r.code !== 0;
    return (
      <div className="my-2 rounded-xl overflow-hidden border border-[#3a3a37] bg-[#212120] text-[#d8d4cb]">
        <button
          onClick={() => setOpen(!open)}
          className="w-full flex items-center gap-2 px-3 py-2 text-left text-[13px] font-mono hover:bg-white/5"
        >
          <Terminal size={14} className="text-green-400 shrink-0" />
          <span className="truncate flex-1">
            <span className="text-green-400">$</span> {r.command}
          </span>
          {failed ? (
            <span className="text-xs text-red-400 shrink-0">mã {r.code}</span>
          ) : (
            <span className="text-xs text-green-400/80 shrink-0">thành công</span>
          )}
          {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
        </button>
        {open && (
          <pre className="px-4 pb-3 text-xs font-mono whitespace-pre-wrap max-h-64 overflow-y-auto text-[#c9c5bb]">
            {r.stdout || r.stderr || '(không có output)'}
          </pre>
        )}
      </div>
    );
  }

  // ----- write/read file: thẻ tệp bấm được — xem code / tải / sao chép -----
  if (r.type === 'file') {
    const isHtml = /\.html?$/i.test(r.path || '');
    const isWrite = r.action === 'write';
    const fileName = (r.path || '').split('/').pop() || r.path;

    const copyFile = async () => {
      try {
        const res = await fetch('/api/workspace', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'read', path: r.path }),
        });
        const data = await res.json();
        if (data.error) {
          toast({ title: data.error, variant: 'destructive' });
          return;
        }
        await navigator.clipboard.writeText(data.content || '');
        setCopied(true);
        setTimeout(() => setCopied(false), 1500);
      } catch {
        toast({ title: 'Không sao chép được tệp', variant: 'destructive' });
      }
    };

    return (
      <div className="my-1.5">
        <div className="inline-flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setViewPath(r.path || '')}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border bg-muted/60 hover:bg-muted text-[13px] transition-colors"
            title="Bấm để xem code"
          >
            {isWrite ? <FileText size={14} className="text-chart-2" /> : <Folder size={14} className="text-chart-3" />}
            <span>
              {isWrite ? 'Đã tạo tệp:' : 'Đã đọc tệp:'}{' '}
              <span className="font-mono font-medium">{fileName}</span>
            </span>
          </button>
          {isWrite && (
            <>
              <button
                onClick={() => setViewPath(r.path || '')}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border bg-primary/10 text-primary hover:bg-primary/15 text-[12px] font-medium transition-colors"
              >
                <Eye size={12} /> Xem code
              </button>
              <a
                href={`/api/preview/${encodeURIComponent(r.path || '')}?download=1`}
                download={fileName}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border hover:bg-accent text-[12px] font-medium transition-colors"
              >
                <Download size={12} /> Tải về
              </a>
              <button
                onClick={copyFile}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border hover:bg-accent text-[12px] font-medium transition-colors"
              >
                {copied ? <Check size={12} className="text-green-600" /> : <Copy size={12} />}
                {copied ? 'Đã chép' : 'Sao chép'}
              </button>
            </>
          )}
          {isHtml && (
            <button
              onClick={() => openPreview(`/api/preview-bundle?path=${encodeURIComponent(r.path || '')}`)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border bg-primary/10 text-primary hover:bg-primary/15 text-[12px] font-medium transition-colors"
              title="Xem trước trang web (tự ghép CSS/JS đi kèm)"
            >
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500" />
              Xem trước
            </button>
          )}
        </div>
        <FileCodeDialog
          path={viewPath || ''}
          open={!!viewPath}
          onClose={() => {
            setViewPath(null);
          }}
        />
      </div>
    );
  }

  // ----- file list -----
  if (r.type === 'file_list') {
    return (
      <div className="my-1.5 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border bg-muted/60 text-[13px]">
        <ListTree size={14} className="text-muted-foreground" />
        <span>Thư mục <span className="font-mono">{r.path || './'}</span>: {(r.items as string[] | undefined)?.join(', ') || '(trống)'}</span>
      </div>
    );
  }

  // ----- ảnh đã tạo -----
  if (r.type === 'image' && r.url) {
    return (
      <div className="my-2 inline-block max-w-sm">
        <img
          src={r.url}
          alt={r.prompt || 'Ảnh AI tạo'}
          className="rounded-xl border shadow-sm max-h-80 cursor-zoom-in"
          onClick={() => window.open(r.url, '_blank')}
        />
        <div className="mt-1.5 flex items-center gap-2 text-xs text-muted-foreground">
          <ImageIcon size={12} />
          <span className="truncate flex-1">{r.prompt}</span>
          <a href={`${r.url}?download=1`} download className="hover:text-foreground shrink-0" title="Tải ảnh">
            <Download size={12} />
          </a>
        </div>
      </div>
    );
  }

  // ----- tìm ảnh web -----
  if (r.type === 'image_search' && r.items?.length) {
    return (
      <div className="my-2">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1.5">
          <Search size={12} /> Kết quả tìm ảnh ({r.items.length})
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {r.items.map((it, i) => (
            <a key={i} href={it.url} target="_blank" rel="noopener noreferrer" className="group">
              <img
                src={it.url}
                alt={it.caption || 'Ảnh tìm được'}
                loading="lazy"
                className="rounded-lg border h-24 w-full object-cover group-hover:opacity-90"
                onError={(e) => ((e.target as HTMLImageElement).style.visibility = 'hidden')}
              />
            </a>
          ))}
        </div>
      </div>
    );
  }

  // ----- video task -----
  if (r.type === 'video_task') {
    if (r.status === 'done' && r.url) {
      return (
        <div className="my-2 max-w-md">
          <video src={r.url} controls className="rounded-xl border w-full" />
          <div className="mt-1 text-xs text-muted-foreground flex items-center gap-1.5">
            <Film size={12} /> {r.prompt}
          </div>
        </div>
      );
    }
    if (r.status === 'fail') {
      return (
        <div className="my-2 flex items-center gap-2 px-3 py-2 rounded-lg border border-destructive/30 bg-destructive/5 text-[13px] text-destructive">
          <AlertCircle size={14} /> Tạo video thất bại — thử lại với mô tả khác.
        </div>
      );
    }
    return (
      <div className="my-2 flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl border bg-muted/60 text-[13px]">
        <Loader2 size={15} className="animate-spin text-primary" />
        <div className="flex-1">
          <div className="font-medium">Đang tạo video...</div>
          <div className="text-xs text-muted-foreground">{r.prompt} — có thể mất 1-5 phút</div>
        </div>
      </div>
    );
  }

  // ----- lỗi -----
  return (
    <div className="my-1.5 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border border-destructive/30 bg-destructive/5 text-[13px] text-destructive">
      <AlertCircle size={13} /> {ev.name}: {r.error || 'thất bại'}
    </div>
  );
}

// ================= Nguồn tham khảo =================
function SourcesBlock({ sources }: { sources: { url: string; name: string; snippet: string }[] }) {
  const [open, setOpen] = useState(true);
  if (!sources?.length) return null;
  return (
    <div className="my-2 rounded-xl border bg-muted/40 overflow-hidden">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center gap-2 px-3 py-2 text-[13px] text-muted-foreground hover:bg-muted">
        <Globe size={14} className="text-chart-4" />
        <span className="font-medium">Nguồn tham khảo ({sources.length})</span>
        {open ? <ChevronDown size={14} className="ml-auto" /> : <ChevronRight size={14} className="ml-auto" />}
      </button>
      {open && (
        <div className="px-3 pb-2.5 space-y-1.5 border-t border-border/60 pt-2">
          {sources.map((s, i) => (
            <a
              key={i}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex gap-2 items-start p-1.5 rounded-lg hover:bg-muted text-[13px]"
            >
              <span className="text-[11px] font-mono text-muted-foreground bg-secondary rounded px-1.5 py-0.5 shrink-0 mt-0.5">
                [{i + 1}]
              </span>
              <span className="min-w-0">
                <span className="block font-medium truncate">{s.name}</span>
                <span className="block text-xs text-muted-foreground truncate">{s.url}</span>
              </span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

// ================= Actions dưới tin nhắn AI =================
function AssistantActions({ msg }: { msg: ChatMessage }) {
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const regenerate = useAppStore((s) => s.regenerate);
  const streaming = useAppStore((s) => s.streaming);

  const copy = async () => {
    await navigator.clipboard.writeText(msg.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const speak = async () => {
    if (speaking) return;
    setSpeaking(true);
    try {
      const plain = msg.content.replace(/```[\s\S]*?```/g, ' (khối code) ').replace(/[#*_>`~[\]()]/g, '').slice(0, 950);
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: plain }),
      });
      if (!res.ok) throw new Error();
      const blob = await res.blob();
      const audio = new Audio(URL.createObjectURL(blob));
      audio.onended = () => setSpeaking(false);
      audio.play();
    } catch {
      setSpeaking(false);
      toast({ title: 'Không tạo được giọng đọc', variant: 'destructive' });
    }
  };

  return (
    <div className="flex items-center gap-0.5 mt-2 -ml-1.5 opacity-70 hover:opacity-100 transition-opacity">
      <button onClick={copy} className="p-1.5 rounded-lg hover:bg-muted transition-colors" title="Sao chép">
        {copied ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
      </button>
      <button onClick={speak} className="p-1.5 rounded-lg hover:bg-muted transition-colors" title="Đọc thành tiếng">
        {speaking ? <Loader2 size={14} className="animate-spin" /> : <Volume2 size={14} />}
      </button>
      {!streaming && (
        <button
          onClick={() => regenerate(msg.id)}
          className="p-1.5 rounded-lg hover:bg-muted transition-colors"
          title="Tạo lại câu trả lời"
        >
          <RefreshCw size={14} />
        </button>
      )}
    </div>
  );
}

// ================= Actions dưới tin nhắn người dùng (kiểu DeepSeek) =================
function UserActions({ msg }: { msg: ChatMessage }) {
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(msg.content);
  const editMessage = useAppStore((s) => s.editMessage);
  const streaming = useAppStore((s) => s.streaming);

  if (streaming) return null;

  const save = () => {
    const v = draft.trim();
    setEditing(false);
    if (v && v !== msg.content) editMessage(msg.id, v);
  };

  return (
    <div className="flex justify-end mt-1">
      {editing ? (
        <div className="w-full max-w-full">
          <textarea
            autoFocus
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) save();
              if (e.key === 'Escape') setEditing(false);
            }}
            rows={Math.min(8, Math.max(2, draft.split('\n').length))}
            className="w-full rounded-2xl border border-primary/40 bg-card px-4 py-2.5 text-[15px] outline-none focus:border-primary resize-y"
          />
          <div className="flex justify-end gap-2 mt-1.5">
            <button
              onClick={() => {
                setDraft(msg.content);
                setEditing(false);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[12.5px] hover:bg-accent"
            >
              <X size={13} /> Huỷ
            </button>
            <button
              onClick={save}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary text-primary-foreground text-[12.5px] font-medium hover:opacity-90"
            >
              <Check size={13} /> Gửi lại
            </button>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-0.5 opacity-60 hover:opacity-100 transition-opacity">
          <button
            onClick={() => {
              navigator.clipboard.writeText(msg.content);
              setCopied(true);
              setTimeout(() => setCopied(false), 1500);
            }}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Sao chép"
          >
            {copied ? <Check size={14} className="text-green-600" /> : <Copy size={14} />}
          </button>
          <button
            onClick={() => {
              setDraft(msg.content);
              setEditing(true);
            }}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Sửa tin nhắn"
          >
            <Pencil size={14} />
          </button>
        </div>
      )}
    </div>
  );
}

// ================= 1 tin nhắn =================
export const MessageBubble = memo(function MessageBubble({ msg }: { msg: ChatMessage }) {
  const streaming = useAppStore((s) => s.streaming);

  if (msg.role === 'user') {
    return (
      <div className="group flex justify-end animate-in fade-in slide-in-from-bottom-1 duration-300">
        <div className="max-w-[85%] sm:max-w-[75%]">
          {msg.attachments && msg.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-end mb-1.5">
              {msg.attachments.map((a, i) => {
                if (a.type === 'image') {
                  return (
                    <img key={i} src={a.url} alt={a.name} className="h-20 w-20 object-cover rounded-xl border" />
                  );
                }
                if (a.type === 'video') {
                  return (
                    <video key={i} src={a.url} className="h-20 rounded-xl border" muted />
                  );
                }
                return (
                  <a
                    key={i}
                    href={a.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border bg-card text-xs max-w-48"
                  >
                    <FileText size={13} className="shrink-0 text-primary" />
                    <span className="truncate">{a.name}</span>
                  </a>
                );
              })}
            </div>
          )}
          {msg.content && (
            <div className="rounded-2xl rounded-br-md bg-secondary px-4 py-2.5 text-[15px] whitespace-pre-wrap break-words">
              {msg.content}
            </div>
          )}
          <UserActions msg={msg} />
        </div>
      </div>
    );
  }

  // ----- assistant -----
  const isPersona = msg.model?.startsWith('persona:');
  const modelDef = !isPersona && msg.model ? getModel(msg.model) : null;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-1 duration-300">
      {/* nhãn model / persona */}
      <div className="flex items-center gap-2 mb-1.5">
        {isPersona ? (() => {
          const pe = msg.events?.find((e) => e.kind === 'persona') as
            { id?: string; name?: string; role?: string; color?: string; icon?: string } | undefined;
          return (
            <div className="flex items-center gap-2 anim-left">
              <PersonaAvatar
                p={{
                  id: pe?.id || '',
                  name: pe?.name || 'Chuyên gia',
                  role: pe?.role,
                  color: pe?.color || '#7D9B76',
                  icon: pe?.icon,
                }}
                size={26}
                className={msg.streaming ? 'speaking-ring' : ''}
              />
              <span className="text-xs font-semibold" style={{ color: pe?.color || 'inherit' }}>
                {pe?.name || 'Chuyên gia'}
              </span>
              {pe?.role && (
                <span className="text-[9.5px] font-medium text-muted-foreground bg-secondary rounded-full px-1.5 py-0.5">
                  {pe.role}
                </span>
              )}
              {msg.streaming && (
                <span className="text-[10px] text-primary animate-pulse">đang viết…</span>
              )}
            </div>
          );
        })() : (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <SharkLogo size={16} />
            {modelDef?.name || 'Shark'}
          </span>
        )}
        {/* phiên đang chạy nền sau khi thoát chat */}
        {msg.status === 'running' && !streaming && (
          <span className="inline-flex items-center gap-1 text-[11px] text-primary bg-primary/10 rounded-full px-2 py-0.5">
            <Cloud size={11} /> Chạy nền
          </span>
        )}
      </div>

      <div className="pl-0.5">
        {msg.thinking && (
          <ThinkingBlock
            text={msg.thinking}
            live={!!msg.streaming}
            hasAnswer={!!msg.content}
          />
        )}

        {msg.events?.map((ev, i) => {
          if (ev.kind === 'phase') {
            return (
              <div key={i} className="flex items-center gap-2 text-[13px] text-muted-foreground my-1">
                <Loader2 size={12} className="animate-spin text-primary" />
                {ev.detail}
              </div>
            );
          }
          if (ev.kind === 'reflection') return <ReflectionBlock key={i} text={ev.text} />;
          if (ev.kind === 'sources') return <SourcesBlock key={i} sources={ev.sources} />;
          if (ev.kind === 'tool') return <ToolEventBlock key={i} ev={ev} />;
          return null;
        })}

        {msg.content && <Markdown content={msg.content} />}
        {msg.streaming && !msg.content && !msg.thinking && (
          <span className="flex gap-1 text-primary py-1">
            <span className="thinking-dot" />
            <span className="thinking-dot" />
            <span className="thinking-dot" />
          </span>
        )}
        {msg.streaming && msg.content && <span className="stream-cursor" />}

        {msg.error && (
          <div className="mt-2 flex items-center gap-2 px-3 py-2 rounded-lg border border-destructive/30 bg-destructive/5 text-[13px] text-destructive">
            <AlertCircle size={14} /> {msg.error}
          </div>
        )}

        {!msg.streaming && msg.content && !streaming && <AssistantActions msg={msg} />}
      </div>
    </div>
  );
});
