'use client';

import {
  Hammer, Sparkles, FileText, Clapperboard, Wallet, AppWindow, Palette, ArrowUpRight,
} from 'lucide-react';
import { SUGGEST_CARDS } from '@/lib/config';
import { SharkLogo } from './logo';

const ICONS: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  hammer: Hammer,
  sparkles: Sparkles,
  'file-text': FileText,
  clapperboard: Clapperboard,
  wallet: Wallet,
  'app-window': AppWindow,
  palette: Palette,
};

export function WelcomeScreen() {
  const onCardClick = (card: (typeof SUGGEST_CARDS)[number]) => {
    if (card.action === 'upload') {
      window.dispatchEvent(new CustomEvent('shark-open-file-picker'));
      return;
    }
    if (card.action === 'image') {
      window.dispatchEvent(
        new CustomEvent('shark-fill-input', {
          detail: 'Tạo cho mình ảnh concept art game giả tưởng: ',
        })
      );
      return;
    }
    if (card.prompt) {
      window.dispatchEvent(new CustomEvent('shark-fill-input', { detail: card.prompt }));
    }
  };

  const top = SUGGEST_CARDS.slice(0, 4);
  const bottom = SUGGEST_CARDS.slice(4);

  return (
    <div className="flex flex-col items-center px-4 pt-10 pb-4 max-w-3xl mx-auto w-full">
      <div className="flex flex-col items-center mb-7">
        <div className="rounded-full logo-glow mb-4 anim-pop">
          <span className="block float-y">
            <SharkLogo size={52} />
          </span>
        </div>
        <h1 className="text-2xl sm:text-[26px] font-bold tracking-tight text-center text-gradient anim-rise anim-d1">
          Chào mừng đến với Shark
        </h1>
        <p className="text-sm text-muted-foreground mt-1.5 text-center anim-rise anim-d2 max-w-xl">
          5 mô hình AI miễn phí: 4 MoE mã nguồn mở (DeepSeek V3 · Kimi K2 · Shark 1.0 · DeepSeek R1) + Google Gemini 3.8 Flash — chat, agent, terminal,
          tạo ảnh &amp; video, deep research
        </p>
      </div>

      {/* Hàng 1: 4 card chính — vào theo nhịp bậc thang */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 w-full">
        {top.map((card, i) => {
          const Icon = ICONS[card.icon] || Sparkles;
          return (
            <button
              key={card.id}
              onClick={() => onCardClick(card)}
              className={`group text-left rounded-2xl border bg-card p-3.5 hover-lift anim-rise anim-d${i + 3} hover:border-primary/40`}
            >
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-primary/10 text-primary mb-2.5 transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6">
                <Icon size={16} />
              </span>
              <span className="block text-[13.5px] font-semibold leading-tight">{card.title}</span>
              <span className="block text-xs text-muted-foreground mt-1 leading-snug">{card.subtitle}</span>
            </button>
          );
        })}
      </div>

      {/* Hàng 2: 3 card phụ */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 w-full mt-2.5">
        {bottom.map((card, i) => {
          const Icon = ICONS[card.icon] || Sparkles;
          return (
            <button
              key={card.id}
              onClick={() => onCardClick(card)}
              className={`group text-left rounded-2xl border bg-card p-3.5 hover-lift anim-rise anim-d${i + 7} flex items-start gap-3 hover:border-primary/40`}
            >
              <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-secondary text-foreground/80 transition-transform duration-300 group-hover:scale-110">
                <Icon size={16} />
              </span>
              <span className="min-w-0">
                <span className="block text-[13.5px] font-semibold leading-tight">{card.title}</span>
                <span className="block text-xs text-muted-foreground mt-0.5 leading-snug line-clamp-2">
                  {card.subtitle}
                </span>
              </span>
              <ArrowUpRight
                size={13}
                className="ml-auto shrink-0 text-muted-foreground opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300"
              />
            </button>
          );
        })}
      </div>
    </div>
  );
}
