'use client';

import { memo, useState, useMemo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Check, Copy, Download, Eye, Save, Globe, FileCode } from 'lucide-react';
import { useAppStore } from '@/store/app-store';
import { toast } from '@/hooks/use-toast';

const EXT_MAP: Record<string, string> = {
  html: 'html', xml: 'xml', css: 'css', javascript: 'js', js: 'js', jsx: 'jsx',
  typescript: 'ts', ts: 'ts', tsx: 'tsx', python: 'py', py: 'py', bash: 'sh',
  shell: 'sh', json: 'json', markdown: 'md', sql: 'sql', java: 'java', c: 'c',
  cpp: 'cpp', go: 'go', rust: 'rs', php: 'php', ruby: 'rb', yaml: 'yml',
};

function extractFilenameFromCode(code: string): string | null {
  const m = code.match(/^(?:\/\/|#|<!--|--)\s*(?:file:|tệp:)?\s*([\w./-]+\.\w{2,4})/);
  return m ? m[1] : null;
}

function CodeBlock({ language, code }: { language: string; code: string }) {
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const bumpFiles = useAppStore((s) => s.bumpFiles);
  const openPreview = useAppStore((s) => s.openPreview);

  const lang = (language || 'text').toLowerCase();
  const ext = EXT_MAP[lang] || 'txt';
  const fileName = useMemo(() => extractFilenameFromCode(code) || `shark-tao.${ext}`, [code, ext]);
  const isHtml = ['html', 'xml'].includes(lang);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {}
  };

  const download = () => {
    const blob = new Blob([code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: `Đã tải ${fileName}` });
  };

  const saveToWorkspace = async () => {
    try {
      const res = await fetch('/api/workspace', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'write', path: fileName, content: code }),
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 1500);
        bumpFiles();
        toast({ title: `Đã lưu ${fileName} vào thư mục dự án` });
      } else toast({ title: 'Lưu thất bại', variant: 'destructive' });
    } catch {}
  };

  const previewHtml = () => {
    openPreview(`srcdoc:${code}`);
  };

  const publish = async () => {
    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ html: code, name: fileName }),
      });
      const data = await res.json();
      if (data.url) {
        const full = `${window.location.origin}${data.url}`;
        window.open(full, '_blank');
        await navigator.clipboard.writeText(full).catch(() => {});
        useAppStore.getState().refreshSites();
        toast({ title: 'Đã đăng lên web!', description: `Liên kết: ${full}` });
      } else toast({ title: data.error || 'Đăng thất bại', variant: 'destructive' });
    } catch {}
  };

  return (
    <div className="my-3 rounded-xl border border-[#3a3a37] overflow-hidden bg-[#282826] text-[#e6e2d8]">
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#212120] border-b border-[#3a3a37]">
        <div className="flex items-center gap-1.5 text-xs text-[#a5a29a] font-mono">
          <FileCode size={13} />
          <span>{fileName}</span>
          <span className="opacity-50">· {lang}</span>
        </div>
        <div className="flex items-center gap-0.5">
          <button onClick={copy} className="p-1.5 rounded-md hover:bg-white/10 transition-colors" title="Sao chép">
            {copied ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
          </button>
          <button onClick={download} className="p-1.5 rounded-md hover:bg-white/10 transition-colors" title="Tải xuống">
            <Download size={14} />
          </button>
          <button onClick={saveToWorkspace} className="p-1.5 rounded-md hover:bg-white/10 transition-colors" title="Lưu vào thư mục dự án">
            <Save size={14} className={saved ? 'text-green-400' : ''} />
          </button>
          {isHtml && (
            <>
              <button onClick={previewHtml} className="p-1.5 rounded-md hover:bg-white/10 transition-colors" title="Xem trước trang">
                <Eye size={14} />
              </button>
              <button onClick={publish} className="p-1.5 rounded-md hover:bg-white/10 transition-colors" title="Đăng lên web">
                <Globe size={14} />
              </button>
            </>
          )}
        </div>
      </div>
      <SyntaxHighlighter
        language={lang}
        style={oneDark}
        customStyle={{ margin: 0, padding: '14px 16px', background: 'transparent', fontSize: '13px', lineHeight: 1.6 }}
        codeTagProps={{ style: { fontFamily: 'var(--font-app-mono)' } }}
      >
        {code.replace(/\n$/, '')}
      </SyntaxHighlighter>
    </div>
  );
}

export const Markdown = memo(function Markdown({ content }: { content: string }) {
  return (
    <div className="md-body">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code(props) {
            const { className, children, ...rest } = props;
            const match = /language-(\w+)/.exec(className || '');
            const text = String(children).replace(/\n$/, '');
            const isBlock = match || text.includes('\n');
            if (!isBlock) {
              return (
                <code className={className} {...rest}>
                  {children}
                </code>
              );
            }
            return <CodeBlock language={match?.[1] || 'text'} code={text} />;
          },
          pre(props) {
            return <>{props.children}</>;
          },
          a(props) {
            return (
              <a href={props.href} target="_blank" rel="noopener noreferrer">
                {props.children}
              </a>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
});
