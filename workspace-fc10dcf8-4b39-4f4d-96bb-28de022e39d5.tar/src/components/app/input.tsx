'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Plus, ArrowUp, Square, Paperclip, Mic, MicOff, Brain, Zap, Gauge, Wrench,
  Image as ImageIcon, Video, Search, Loader2, X, FileText, Users, Sparkles,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Popover, PopoverContent, PopoverTrigger,
} from '@/components/ui/popover';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { MODES, THINK_MODES, TOPICS, SPEEDS, SKILLS } from '@/lib/config';
import { useAppStore, type Attachment } from '@/store/app-store';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

// ---------- Ghi âm WAV (AudioContext → PCM 16k → WAV) ----------
async function recordWav(): Promise<{ stop: () => Promise<Blob> }> {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  const ctx = new AudioContext({ sampleRate: 16000 });
  const source = ctx.createMediaStreamSource(stream);
  const processor = ctx.createScriptProcessor(4096, 1, 1);
  const chunks: Float32Array[] = [];
  processor.onaudioprocess = (e) => {
    chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)));
  };
  source.connect(processor);
  processor.connect(ctx.destination);
  return {
    stop: () =>
      new Promise((resolve) => {
        processor.disconnect();
        source.disconnect();
        stream.getTracks().forEach((t) => t.stop());
        const total = chunks.reduce((a, c) => a + c.length, 0);
        const pcm = new Float32Array(total);
        let off = 0;
        for (const c of chunks) {
          pcm.set(c, off);
          off += c.length;
        }
        const buffer = ctx.createBuffer(1, pcm.length, 16000);
        buffer.copyToChannel(pcm, 0);
        const wav = encodeWav(buffer);
        ctx.close();
        resolve(wav);
      }),
  };
}

function encodeWav(buffer: AudioBuffer): Blob {
  const numCh = 1, sampleRate = buffer.sampleRate;
  const data = buffer.getChannelData(0);
  const bytes = new ArrayBuffer(44 + data.length * 2);
  const view = new DataView(bytes);
  const writeStr = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + data.length * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numCh, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, 'data');
  view.setUint32(40, data.length * 2, true);
  let off = 44;
  for (let i = 0; i < data.length; i++, off += 2) {
    const s = Math.max(-1, Math.min(1, data[i]));
    view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([view], { type: 'audio/wav' });
}

// ---------- Chip dropdown ----------
function ChipDropdown({
  icon, label, active, children, contentClass,
}: {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  children: React.ReactNode;
  contentClass?: string;
}) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            'inline-flex items-center gap-1.5 h-8 px-2.5 rounded-full text-[12.5px] font-medium border transition-colors whitespace-nowrap',
            active
              ? 'bg-primary/10 border-primary/30 text-primary'
              : 'bg-background hover:bg-accent text-foreground/80'
          )}
        >
          {icon}
          {label}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" side="top" className={cn('p-1.5', contentClass)}>
        {children}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function ChatInput() {
  const send = useAppStore((s) => s.send);
  const stop = useAppStore((s) => s.stop);
  const streaming = useAppStore((s) => s.streaming);
  const mode = useAppStore((s) => s.mode);
  const setMode = useAppStore((s) => s.setMode);
  const think = useAppStore((s) => s.think);
  const setThink = useAppStore((s) => s.setThink);
  const topic = useAppStore((s) => s.topic);
  const setTopic = useAppStore((s) => s.setTopic);
  const speed = useAppStore((s) => s.speed);
  const setSpeed = useAppStore((s) => s.setSpeed);
  const enabledSkills = useAppStore((s) => s.enabledSkills);
  const toggleSkill = useAppStore((s) => s.toggleSkill);
  const customSkills = useAppStore((s) => s.customSkills);
  const groupAI = useAppStore((s) => s.groupAI);
  const setGroupAI = useAppStore((s) => s.setGroupAI);
  const setPanelTab = useAppStore((s) => s.setPanelTab);
  const openModal = useAppStore((s) => s.openModal);

  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const recorderRef = useRef<{ stop: () => Promise<Blob> } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // tự chỉnh chiều cao
  const resize = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 200) + 'px';
  }, []);

  // sự kiện điền text từ welcome cards
  useEffect(() => {
    const fill = (e: Event) => {
      const detail = (e as CustomEvent).detail as string;
      setText(detail);
      setTimeout(() => {
        textareaRef.current?.focus();
        resize();
      }, 50);
    };
    const openPicker = () => fileInputRef.current?.click();
    window.addEventListener('shark-fill-input', fill);
    window.addEventListener('shark-open-file-picker', openPicker);
    return () => {
      window.removeEventListener('shark-fill-input', fill);
      window.removeEventListener('shark-open-file-picker', openPicker);
    };
  }, [resize]);

  const uploadFile = async (file: File) => {
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await fetch('/api/upload', { method: 'POST', body: form });
      const data = await res.json();
      if (data.error) {
        toast({ title: data.error, variant: 'destructive' });
      } else {
        setAttachments((a) => [...a, data as Attachment]);
      }
    } catch {
      toast({ title: 'Tải tệp lên thất bại', variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  const doSend = () => {
    if (streaming || (!text.trim() && attachments.length === 0)) return;
    const msg = text.trim();
    setText('');
    const atts = attachments;
    setAttachments([]);
    send(msg, atts);
  };

  const toggleMic = async () => {
    if (recording) {
      setRecording(false);
      setTranscribing(true);
      try {
        const blob = await recorderRef.current?.stop();
        if (blob) {
          const form = new FormData();
          form.append('audio', blob, 'rec.wav');
          const res = await fetch('/api/asr', { method: 'POST', body: form });
          const data = await res.json();
          if (data.text) {
            setText((t) => (t ? t + ' ' : '') + data.text);
            setTimeout(resize, 50);
          } else toast({ title: data.error || 'Không nhận dạng được giọng nói', variant: 'destructive' });
        }
      } catch {
        toast({ title: 'Lỗi ghi âm', variant: 'destructive' });
      } finally {
        setTranscribing(false);
        recorderRef.current = null;
      }
      return;
    }
    try {
      recorderRef.current = await recordWav();
      setRecording(true);
    } catch {
      toast({ title: 'Không truy cập được micro', variant: 'destructive' });
    }
  };

  // kéo-thả file
  const onDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    for (const file of Array.from(e.dataTransfer.files)) {
      await uploadFile(file);
    }
  };

  const modeDef = MODES.find((m) => m.id === mode);
  const thinkDef = THINK_MODES.find((t) => t.id === think);
  const topicDef = TOPICS.find((t) => t.id === topic);
  const speedDef = SPEEDS.find((s) => s.id === speed);
  const skillCount = enabledSkills.length;

  return (
    <div className="relative px-3 pb-3 pt-1 max-w-3xl mx-auto w-full">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        hidden
        onChange={async (e) => {
          for (const f of Array.from(e.target.files || [])) await uploadFile(f);
          e.target.value = '';
        }}
      />

      {/* overlay kéo thả */}
      {dragging && (
        <div className="absolute inset-0 z-20 rounded-3xl border-2 border-dashed border-primary bg-primary/5 flex items-center justify-center pointer-events-none">
          <div className="text-center">
            <Paperclip size={28} className="mx-auto text-primary mb-2" />
            <p className="font-semibold text-primary">Thả file vào đây để đính kèm</p>
            <p className="text-xs text-muted-foreground mt-1">Ảnh, PDF, file văn bản hoặc code</p>
          </div>
        </div>
      )}

      <div
        className="rounded-3xl border bg-card shadow-sm"
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        {/* attachments */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 px-3 pt-3">
            {attachments.map((a, i) => (
              <div key={i} className="relative group">
                {a.type === 'image' ? (
                  <img src={a.url} alt={a.name} className="h-16 w-16 object-cover rounded-xl border" />
                ) : (
                  <div className="flex items-center gap-1.5 h-9 px-2.5 rounded-xl border bg-secondary text-xs max-w-44">
                    <FileText size={13} className="shrink-0 text-primary" />
                    <span className="truncate">{a.name}</span>
                  </div>
                )}
                <button
                  onClick={() => setAttachments((arr) => arr.filter((_, j) => j !== i))}
                  className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-foreground text-background flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={11} />
                </button>
              </div>
            ))}
            {uploading && (
              <div className="h-16 w-16 rounded-xl border flex items-center justify-center">
                <Loader2 size={16} className="animate-spin text-primary" />
              </div>
            )}
          </div>
        )}

        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            resize();
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
              e.preventDefault();
              doSend();
            }
          }}
          placeholder="Hỏi Shark bất cứ điều gì, hoặc thả file để phân tích..."
          rows={1}
          className="w-full resize-none bg-transparent px-4 pt-3.5 pb-1 text-[15px] outline-none placeholder:text-muted-foreground/70 max-h-[200px]"
        />

        {/* hàng nút */}
        <div className="flex items-center gap-1.5 px-2.5 pb-2.5 pt-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="h-8 w-8 shrink-0 rounded-full border bg-background hover:bg-accent flex items-center justify-center" title="Đính kèm">
                <Plus size={16} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start" className="p-1.5 w-52">
              <button onClick={() => fileInputRef.current?.click()} className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-accent text-[13px]">
                <Paperclip size={15} /> Tải tệp lên
              </button>
              <button
                onClick={() => setText((t) => (t ? t + ' ' : '') + 'Tạo ảnh: ')}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-accent text-[13px]"
              >
                <ImageIcon size={15} /> Tạo ảnh AI
              </button>
              <button
                onClick={() => setText((t) => (t ? t + ' ' : '') + 'Tạo video: ')}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-accent text-[13px]"
              >
                <Video size={15} /> Tạo video AI
              </button>
              <button
                onClick={() => setText((t) => (t ? t + ' ' : '') + 'Tìm ảnh về: ')}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-accent text-[13px]"
              >
                <Search size={15} /> Tìm ảnh web
              </button>
            </DropdownMenuContent>
          </DropdownMenu>

          <ChipDropdown
            icon={<Zap size={13} />}
            label={modeDef?.id === 'normal' ? 'Chế độ' : modeDef?.name || 'Chế độ'}
            active={mode !== 'normal'}
            contentClass="w-72"
          >
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={cn(
                  'w-full text-left px-2.5 py-2 rounded-lg hover:bg-accent transition-colors',
                  m.id === mode && 'bg-accent/70'
                )}
              >
                <div className="text-[13px] font-semibold flex items-center justify-between">
                  {m.name}
                  {m.id === mode && <span className="text-primary text-xs">✓</span>}
                </div>
                <div className="text-[11.5px] text-muted-foreground mt-0.5 leading-snug">{m.desc}</div>
              </button>
            ))}
          </ChipDropdown>

          {/* Mức suy nghĩ — thanh trượt kéo như "effort" của GLM */}
          <Popover>
            <PopoverTrigger asChild>
              <button
                className={cn(
                  'inline-flex items-center gap-1.5 h-8 px-2.5 rounded-full text-[12.5px] font-medium border transition-colors whitespace-nowrap',
                  think !== 'off'
                    ? 'bg-primary/10 border-primary/30 text-primary'
                    : 'bg-background hover:bg-accent text-foreground/80'
                )}
              >
                <Brain size={13} />
                {think === 'off' ? 'Suy nghĩ' : thinkDef?.name || 'Suy nghĩ'}
              </button>
            </PopoverTrigger>
            <PopoverContent side="top" align="start" className="w-72 p-3.5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[13px] font-semibold flex items-center gap-1.5">
                  <Brain size={14} className="text-primary" /> Mức suy nghĩ
                </span>
                <span className="text-[11px] font-medium text-primary bg-primary/10 rounded-full px-2 py-0.5">
                  {thinkDef?.name}
                </span>
              </div>
              <Slider
                value={[Math.max(0, THINK_MODES.findIndex((t) => t.id === think))]}
                min={0}
                max={THINK_MODES.length - 1}
                step={1}
                onValueChange={([v]) => setThink(THINK_MODES[v].id)}
                className="cursor-pointer"
              />
              <div className="flex justify-between mt-2">
                {THINK_MODES.map((t, i) => (
                  <button
                    key={t.id}
                    onClick={() => setThink(t.id)}
                    className={cn(
                      'text-[10px] leading-tight transition-colors text-center flex-1',
                      t.id === think ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'
                    )}
                  >
                    {t.name}
                    {i < THINK_MODES.length - 1 && <span className="hidden">·</span>}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-muted-foreground mt-2.5 leading-snug border-t pt-2">
                {thinkDef?.desc}
              </p>
            </PopoverContent>
          </Popover>

          <ChipDropdown
            icon={<Wrench size={13} />}
            label={topicDef?.name || 'Chủ đề'}
            active={topic !== 'chung'}
            contentClass="w-60"
          >
            {TOPICS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTopic(t.id)}
                className={cn(
                  'w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-accent text-[13px]',
                  t.id === topic && 'bg-accent/70'
                )}
              >
                <span>
                  <span className="font-medium">{t.name}</span>
                  <span className="text-muted-foreground text-[11px] ml-2">{t.desc}</span>
                </span>
                {t.id === topic && <span className="text-primary text-xs">✓</span>}
              </button>
            ))}
          </ChipDropdown>

          <ChipDropdown
            icon={<Gauge size={13} />}
            label={speedDef?.name || 'Vừa'}
            active={speed !== 'medium'}
            contentClass="w-56"
          >
            {SPEEDS.map((sp) => (
              <button
                key={sp.id}
                onClick={() => setSpeed(sp.id)}
                className={cn(
                  'w-full text-left px-2.5 py-2 rounded-lg hover:bg-accent',
                  sp.id === speed && 'bg-accent/70'
                )}
              >
                <div className="text-[13px] font-semibold flex items-center gap-1.5">
                  {sp.name}
                  {sp.badge && (
                    <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">{sp.badge}</span>
                  )}
                </div>
                <div className="text-[11.5px] text-muted-foreground mt-0.5">{sp.desc}</div>
              </button>
            ))}
          </ChipDropdown>

          <ChipDropdown
            icon={<Sparkles size={13} />}
            label={skillCount ? `Skills · ${skillCount}` : 'Skills'}
            active={skillCount > 0}
            contentClass="w-72 max-h-80 overflow-y-auto"
          >
            {customSkills.length > 0 && (
              <>
                <div className="px-2.5 pt-1 pb-0.5 text-[10px] font-semibold text-primary uppercase tracking-wide">
                  Tùy chỉnh của bạn
                </div>
                {customSkills.map((cs) => (
                  <div
                    key={cs.id}
                    className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg hover:bg-accent/60"
                  >
                    <div className="min-w-0">
                      <div className="text-[13px] font-medium">{cs.name}</div>
                      <div className="text-[11px] text-muted-foreground truncate">{cs.desc || 'Skill tùy chỉnh'}</div>
                    </div>
                    <Switch
                      checked={enabledSkills.includes(`custom:${cs.id}`)}
                      onCheckedChange={() => toggleSkill(`custom:${cs.id}`)}
                    />
                  </div>
                ))}
                <div className="h-px bg-border my-1.5" />
              </>
            )}
            {SKILLS.map((sk) => (
              <div
                key={sk.id}
                className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-lg hover:bg-accent/60"
              >
                <div className="min-w-0">
                  <div className="text-[13px] font-medium">{sk.name}</div>
                  <div className="text-[11px] text-muted-foreground truncate">{sk.desc}</div>
                </div>
                <Switch
                  checked={enabledSkills.includes(sk.id)}
                  onCheckedChange={() => toggleSkill(sk.id)}
                />
              </div>
            ))}
            <div className="px-2.5 pt-1.5 pb-1 text-[11px] text-muted-foreground border-t mt-1">
              Skills được bật sẽ được AI dùng tự động khi phù hợp.
            </div>
            <button
              onClick={() => openModal('skills')}
              className="mt-0.5 mx-1.5 mb-1 flex items-center justify-center gap-1.5 w-[calc(100%-12px)] px-2.5 py-2 rounded-lg bg-primary/10 text-primary hover:bg-primary/15 text-[12.5px] font-medium transition-colors"
            >
              <Sparkles size={13} /> Quản lý &amp; tạo skill mới
            </button>
          </ChipDropdown>

          <ChipDropdown
            icon={<Users size={13} />}
            label="Group AI"
            active={groupAI}
            contentClass="w-64"
          >
            <div className="px-2.5 py-2">
              <p className="text-[12.5px] leading-snug text-muted-foreground">
                8 chuyên gia (Sếp, Agent, Slide, Code, Terminal, Kiểm tra, Kiểm thử, Kết quả) cùng làm việc như một team.
              </p>
              <div className="flex items-center justify-between mt-2">
                <span className="text-[13px] font-semibold">
                  {groupAI ? 'Bạn đang ở trang Group AI' : 'Bật Group AI'}
                </span>
                <Switch checked={groupAI} onCheckedChange={setGroupAI} />
              </div>
              <p className="text-[10.5px] text-muted-foreground mt-1.5">
                Bật → sang trang group · Tắt → về chat thường
              </p>
            </div>
          </ChipDropdown>

          <div className="flex-1 min-w-2" />

          <button
            onClick={() => setPanelTab('terminal')}
            className="h-8 w-8 shrink-0 rounded-full hover:bg-accent flex items-center justify-center text-muted-foreground"
            title="Mở Terminal"
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="4 17 10 11 4 5" />
              <line x1="12" y1="19" x2="20" y2="19" />
            </svg>
          </button>

          <button
            onClick={toggleMic}
            disabled={transcribing}
            className={cn(
              'h-8 w-8 shrink-0 rounded-full flex items-center justify-center transition-colors',
              recording ? 'bg-destructive text-white animate-pulse' : 'hover:bg-accent text-muted-foreground'
            )}
            title={recording ? 'Dừng ghi âm' : 'Nói để nhập'}
          >
            {transcribing ? <Loader2 size={15} className="animate-spin" /> : recording ? <MicOff size={15} /> : <Mic size={15} />}
          </button>

          {streaming ? (
            <button
              onClick={stop}
              className="h-9 w-9 shrink-0 rounded-full bg-foreground text-background flex items-center justify-center press sheen-host"
              title="Dừng"
            >
              <Square size={14} fill="currentColor" />
            </button>
          ) : (
            <button
              onClick={doSend}
              disabled={!text.trim() && attachments.length === 0}
              className="h-9 w-9 shrink-0 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-40 press sheen-host transition-opacity"
              title="Gửi"
            >
              <ArrowUp size={17} strokeWidth={2.5} />
            </button>
          )}
        </div>
      </div>

      <p className="text-center text-[11px] text-muted-foreground mt-2">
        Bạn đang trò chuyện với Shark — miễn phí 100%, không giới hạn. Shark có thể mắc lỗi, hãy kiểm tra lại thông tin quan trọng.{' '}
        <a href="/terms" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">Điều khoản</a> ·{' '}
        <a href="/terms#quyen-rieng-tu" target="_blank" rel="noopener noreferrer" className="underline hover:text-foreground">Quyền riêng tư</a>
      </p>
    </div>
  );
}
