'use client';

import {
  ChevronDown, Check, BadgeCheck, FolderTree, TerminalSquare, Eye, Sparkles, Lock,
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MODELS, MODES, getModel } from '@/lib/config';
import { useAppStore } from '@/store/app-store';
import { SharkLogo } from './logo';
import { SidebarExpandButton } from './sidebar';
import { cn } from '@/lib/utils';

function ModelSelector() {
  const model = useAppStore((s) => s.model);
  const setModel = useAppStore((s) => s.setModel);
  // fallback rõ ràng về shark-1 (model mặc định) — MODELS[0] không còn là mặc định sau khi xếp lại danh sách
  const current = getModel(model);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 px-3 py-1.5 rounded-xl hover:bg-accent press transition-all text-sm font-semibold">
          <SharkLogo size={20} />
          {current.name}
          <ChevronDown size={15} className="text-muted-foreground transition-transform duration-300 group-hover:translate-y-0.5" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-[380px] p-1.5 max-h-[70vh] overflow-y-auto">
        <div className="px-2.5 pt-1.5 pb-2">
          <div className="font-semibold text-sm">{current.name}</div>
          <div className="text-xs text-muted-foreground mt-0.5">
            Mô hình của Shark · mixture-of-experts · mã nguồn mở, miễn phí 100%
          </div>
        </div>
        <div className="h-px bg-border my-1" />
        {MODELS.map((m) => (
          <button
            key={m.id}
            onClick={() => setModel(m.id)}
            className={cn(
              'w-full flex items-start gap-3 px-2.5 py-2.5 rounded-xl text-left hover:bg-accent transition-colors',
              m.id === model && 'bg-accent/70'
            )}
          >
            <span
              className="mt-1 h-2.5 w-2.5 rounded-full shrink-0 ring-4 ring-offset-0"
              style={{ backgroundColor: m.accent, boxShadow: `0 0 0 3px ${m.accent}22` }}
            />
            <span className="flex-1 min-w-0">
              <span className="flex items-center gap-1.5">
                <span className="font-semibold text-[13.5px]">{m.name}</span>
                {m.badge && (
                  <span className="text-[10px] font-semibold bg-primary/10 text-primary px-1.5 py-0.5 rounded-full">
                    {m.badge}
                  </span>
                )}
                {m.id === model && <Check size={14} className="text-primary" />}
              </span>
              <span className="block text-xs text-muted-foreground mt-0.5">
                {m.vendor} · {m.params} · {m.license}
              </span>
              <span className="block text-xs text-muted-foreground mt-0.5 line-clamp-2">{m.desc}</span>
            </span>
          </button>
        ))}
        <div className="h-px bg-border my-1" />
        <div className="px-2.5 py-1.5 text-[11px] text-muted-foreground flex items-center gap-1.5">
          <Sparkles size={12} className="text-primary" />
          Mixture-of-Experts: mỗi token chỉ kích hoạt nhóm chuyên gia phù hợp → nhanh & rẻ hơn.
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function ModeIndicator() {
  const mode = useAppStore((s) => s.mode);
  const m = MODES.find((x) => x.id === mode);
  if (!m || m.id === 'normal') return null;
  return (
    <span className="hidden sm:inline-flex items-center gap-1 text-xs font-medium bg-primary/10 text-primary px-2 py-1 rounded-full">
      {m.name}
    </span>
  );
}

export function ChatHeader() {
  const panelOpen = useAppStore((s) => s.panelOpen);
  const setPanelTab = useAppStore((s) => s.setPanelTab);

  return (
    <header className="flex items-center gap-1 px-3 h-14 border-b bg-background/80 backdrop-blur shrink-0">
      <SidebarExpandButton />
      <ModelSelector />
      <ModeIndicator />
      <div className="flex-1" />
      <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-muted-foreground mr-1">
        <Lock size={11} /> Chạy local · miễn phí
      </span>
      <button
        onClick={() => setPanelTab('files')}
        className={cn(
          'p-2 rounded-lg hover:bg-accent text-muted-foreground press transition-colors',
          panelOpen && 'bg-accent text-foreground'
        )}
        title="Thư mục dự án"
      >
        <FolderTree size={17} />
      </button>
      <button
        onClick={() => setPanelTab('terminal')}
        className={cn(
          'p-2 rounded-lg hover:bg-accent text-muted-foreground press transition-colors',
          panelOpen && 'bg-accent text-foreground'
        )}
        title="Terminal"
      >
        <TerminalSquare size={17} />
      </button>
      <button
        onClick={() => setPanelTab('preview')}
        className={cn(
          'p-2 rounded-lg hover:bg-accent text-muted-foreground press transition-colors',
          panelOpen && 'bg-accent text-foreground'
        )}
        title="Xem trước"
      >
        <Eye size={17} />
      </button>
    </header>
  );
}
