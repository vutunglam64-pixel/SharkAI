'use client';

import { create } from 'zustand';

// ================= Types =================
export interface Attachment {
  type: 'image' | 'video' | 'document' | 'text';
  name: string;
  url: string; // /api/asset/<file>
  mime: string;
  size: number;
  preview?: string | null;
}

export interface ToolResultData {
  type: string;
  url?: string;
  prompt?: string;
  command?: string;
  stdout?: string;
  stderr?: string;
  code?: number;
  path?: string;
  action?: string;
  content?: string;
  items?: { url: string; caption?: string; source?: string }[];
  sources?: { url: string; name: string; snippet: string; host?: string }[];
  taskId?: string;
  status?: string;
  error?: string;
}

export type ChatEvent =
  | { kind: 'phase'; phase: string; detail: string }
  | { kind: 'tool'; name: string; args: Record<string, unknown>; result: ToolResultData; ok: boolean; step?: number }
  | { kind: 'sources'; sources: { url: string; name: string; snippet: string }[] }
  | { kind: 'reflection'; text: string }
  | { kind: 'persona'; id: string; name: string; role: string; color: string; icon?: string };

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  thinking?: string;
  attachments?: Attachment[];
  events?: ChatEvent[];
  model?: string;
  streaming?: boolean;
  error?: string;
  status?: string; // running (đang chạy nền) | done | stopped | error
}

export interface SessionMeta {
  id: string;
  title: string;
  model: string;
  mode: string;
  pinned: boolean;
  groupAI: boolean;
  projectId: string | null;
  userId?: string | null;
  running?: boolean;
  updatedAt: string;
  _count?: { messages: number };
}

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  image: string | null;
}

export interface ProjectMeta {
  id: string;
  name: string;
  goal: string;
  updatedAt: string;
  _count?: { sessions: number };
}

export interface SiteMeta {
  id: string;
  name: string;
  views: number;
  createdAt: string;
  multi?: boolean; // site đăng cả thư mục (nhiều tệp)
  fileCount?: number;
}

export interface CustomSkillMeta {
  id: string;
  name: string;
  desc: string;
  prompt: string;
  createdAt: string;
}

export interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'dir';
  size?: number;
  children?: FileNode[];
}

type ModalType = 'project' | 'groupai' | 'skills' | 'api' | 'publish' | 'sites' | 'notifications' | 'login' | null;
type PanelTab = 'files' | 'terminal' | 'preview';

interface SendOpts {
  reuseUserMessageId?: string; // sửa/tạo lại: dùng lại tin nhắn user gốc
}

interface AppState {
  // sidebar / sessions
  sessions: SessionMeta[];
  projects: ProjectMeta[];
  sites: SiteMeta[];
  customSkills: CustomSkillMeta[];
  activeSessionId: string | null;
  activeProjectId: string | null;
  sidebarOpen: boolean;

  // tài khoản
  user: AuthUser | null;
  googleConfigured: boolean;
  authError: string | null; // lỗi hiển thị trong modal đăng nhập/đăng ký

  // chat
  messages: ChatMessage[];
  streaming: boolean;
  pendingPhase: string | null;
  activePersonaId: string | null; // agent nào trong đội Group AI đang phát biểu

  // settings
  model: string;
  mode: string;
  topic: string;
  think: string;
  speed: string;
  enabledSkills: string[];
  groupAI: boolean;

  // panel
  panelOpen: boolean;
  panelTab: PanelTab;
  previewSrc: string | null; // URL hoặc "srcdoc:..."
  filesVersion: number;

  // modals
  modal: ModalType;

  // file đang mở để edit trong panel
  openedFile: { path: string; content: string } | null;
  setOpenedFile: (f: { path: string; content: string } | null) => void;

  // actions
  setModel: (v: string) => void;
  setMode: (v: string) => void;
  setTopic: (v: string) => void;
  setThink: (v: string) => void;
  setSpeed: (v: string) => void;
  toggleSkill: (id: string) => void;
  setGroupAI: (v: boolean) => void;
  toggleSidebar: () => void;
  setPanelOpen: (v: boolean) => void;
  setPanelTab: (v: PanelTab) => void;
  openPreview: (src: string) => void;
  setPreviewSrc: (src: string | null) => void;
  bumpFiles: () => void;
  openModal: (m: ModalType) => void;

  refreshSessions: () => Promise<void>;
  refreshProjects: () => Promise<void>;
  refreshSites: () => Promise<void>;
  refreshCustomSkills: () => Promise<void>;
  deleteSite: (id: string) => Promise<void>;
  setActiveProject: (id: string | null) => void;
  loadSession: (id: string) => Promise<void>;
  newChat: () => void;
  deleteSession: (id: string) => Promise<void>;
  togglePin: (id: string, pinned: boolean) => Promise<void>;
  renameSession: (id: string, title: string) => Promise<void>;

  refreshUser: () => Promise<void>;
  loginQuick: (name: string, email: string) => Promise<boolean>;
  loginPassword: (
    email: string,
    password: string
  ) => Promise<'ok' | 'no_password' | 'error'>;
  registerAccount: (name: string, email: string, password: string) => Promise<boolean>;
  logoutUser: () => Promise<void>;

  send: (text: string, attachments: Attachment[], opts?: SendOpts) => Promise<void>;
  stop: () => void;
  editMessage: (id: string, newContent: string) => Promise<void>;
  regenerate: (assistantMsgId: string) => Promise<void>;
  pollVideoTask: (msgId: string, taskId: string) => Promise<void>;
}

// ================= Helpers =================
let abortController: AbortController | null = null;

// Poll các phiên đang chạy nền (khi user thoát chat rồi quay lại)
const pollers = new Map<string, ReturnType<typeof setInterval>>();

function mapDbMessages(messages: Record<string, unknown>[]): ChatMessage[] {
  return messages.map((m) => ({
    id: m.id as string,
    role: m.role as 'user' | 'assistant',
    content: m.content as string,
    thinking: (m.thinking as string) || undefined,
    attachments: m.attachments && m.attachments !== '[]' ? JSON.parse(m.attachments as string) : undefined,
    events: m.events && m.events !== '[]' ? JSON.parse(m.events as string) : undefined,
    model: (m.model as string) || undefined,
    status: (m.status as string) || 'done',
    streaming: m.status === 'running',
  }));
}

function stopPolling(sessionId: string) {
  const t = pollers.get(sessionId);
  if (t) {
    clearInterval(t);
    pollers.delete(sessionId);
  }
}

function startPolling(sessionId: string) {
  if (pollers.has(sessionId)) return;
  const timer = setInterval(async () => {
    try {
      const res = await fetch(`/api/sessions/${sessionId}`);
      if (!res.ok) {
        stopPolling(sessionId);
        return;
      }
      const session = await res.json();
      const stillRunning = (session.messages || []).some(
        (m: Record<string, unknown>) => m.status === 'running'
      );
      const isActive = useAppStore.getState().activeSessionId === sessionId;
      if (isActive) {
        useAppStore.setState({ messages: mapDbMessages(session.messages), streaming: stillRunning });
        // Agent chạy nền có thể vừa tạo file → cập nhật cây thư mục liên tục (không cần tải lại trang)
        if (stillRunning) useAppStore.getState().bumpFiles();
        // khôi phục poll video đang xử lý
        for (const m of useAppStore.getState().messages) {
          for (const ev of m.events || []) {
            if (ev.kind === 'tool' && ev.result?.type === 'video_task' && ev.result?.status === 'processing' && ev.result?.taskId) {
              useAppStore.getState().pollVideoTask(m.id, ev.result.taskId);
            }
          }
        }
      }
      if (!stillRunning) {
        stopPolling(sessionId);
        useAppStore.getState().refreshSessions();
        useAppStore.getState().bumpFiles(); // tác vụ nền vừa tạo xong file → nạp lại cây thư mục
      }
    } catch {}
  }, 2000);
  pollers.set(sessionId, timer);
}

export function updateMessageVideoStatus(
  messages: ChatMessage[],
  msgId: string,
  taskId: string,
  status: string,
  url?: string
): ChatMessage[] {
  return messages.map((m) => {
    if (m.id !== msgId) return m;
    const events = (m.events || []).map((ev) => {
      if (ev.kind === 'tool' && ev.result?.type === 'video_task' && ev.result?.taskId === taskId) {
        return {
          ...ev,
          result: { ...ev.result, status, url: url || ev.result.url },
        } as ChatEvent;
      }
      return ev;
    });
    return { ...m, events };
  });
}

// ================= Gemini client-side (Google) =================
// Server bị Google chặn theo vị trí IP → browser người dùng (Việt Nam — vùng hỗ trợ)
// tự gọi streamGenerateContent trực tiếp rồi PATCH kết quả về DB.

export interface GeminiDelegate {
  model: string;
  system: string;
  history: { role: string; content: string }[];
  userText: string;
}

async function runGeminiDirect(
  opts: GeminiDelegate,
  assistantId: string,
  push: (fn: (m: ChatMessage) => ChatMessage) => void,
  signal: AbortSignal
): Promise<void> {
  let content = '';
  let thinking = '';

  const finalize = async (status: 'done' | 'stopped' | 'error', errorMessage?: string) => {
    await fetch(`/api/messages/${assistantId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        finalize: true,
        content,
        thinking: thinking || null,
        status,
        ...(errorMessage ? { errorMessage } : {}),
      }),
    }).catch(() => {});
  };

  try {
    // 1. Lấy khoá Google từ máy chủ (env, không hardcode client)
    const keyRes = await fetch('/api/gemini');
    const keyData = await keyRes.json().catch(() => ({}));
    const apiKey = (keyData as { key?: string }).key;
    if (!apiKey) throw new Error('Máy chủ chưa cấu hình khoá Google (GEMINI_API_KEY).');

    // 2. Ghép contents chuẩn Gemini: gộp các lượt liền vai, assistant → model
    const contents: { role: 'user' | 'model'; parts: { text: string }[] }[] = [];
    const addTurn = (role: 'user' | 'model', text: string) => {
      const last = contents[contents.length - 1];
      if (last && last.role === role && last.parts[0]) last.parts[0].text += '\n\n' + text;
      else contents.push({ role, parts: [{ text }] });
    };
    for (const h of opts.history) addTurn(h.role === 'user' ? 'user' : 'model', h.content);
    addTurn('user', opts.userText);
    if (contents.length && contents[0].role === 'model') contents.shift();
    if (!contents.length) throw new Error('Không có nội dung để gửi.');

    // 3. Gọi Google streamGenerateContent (SSE)
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(opts.model)}:streamGenerateContent?alt=sse`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify({
          systemInstruction: opts.system ? { parts: [{ text: opts.system }] } : undefined,
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 65536 },
        }),
        signal,
      }
    );

    if (!res.ok || !res.body) {
      let msg = `Google API lỗi HTTP ${res.status}`;
      try {
        const j = await res.json();
        const m = String((j as { error?: { message?: string } }).error?.message || '');
        if (res.status === 400 && m.toLowerCase().includes('location'))
          msg = 'Google đang chặn khu vực mạng này với Gemini API. Hãy thử lại từ mạng được hỗ trợ (Việt Nam OK).';
        else if (res.status === 401) msg = 'Khoá Google Gemini không hợp lệ / đã thu hồi — kiểm tra lại GEMINI_API_KEY.';
        else if (res.status === 403) msg = 'Khoá Gemini chưa có quyền dùng model này (chưa bật Gemini API hoặc khoá bị giới hạn).';
        else if (res.status === 429) msg = 'Vượt hạn mức miễn phí của Google — thử lại sau ít phút.';
        else if (m) msg = `Google API: ${m.slice(0, 300)}`;
      } catch {}
      throw new Error(msg);
    }

    // 4. Đọc SSE: part có thought:true → luồng suy nghĩ, part thường → nội dung
    const reader = res.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buf = '';
    let finishReason = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let idx: number;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, idx);
        buf = buf.slice(idx + 2);
        for (const line of block.split('\n')) {
          if (!line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (!payload || payload === '[DONE]') continue;
          try {
            const j = JSON.parse(payload) as {
              candidates?: { content?: { parts?: { text?: string; thought?: boolean }[] }; finishReason?: string }[];
              promptFeedback?: { blockReason?: string };
            };
            const cand = j.candidates?.[0];
            if (j.promptFeedback?.blockReason)
              throw new Error('Google đã chặn yêu cầu vì lý do an toàn (safety).');
            for (const p of cand?.content?.parts || []) {
              const t = typeof p.text === 'string' ? p.text : '';
              if (!t) continue;
              if (p.thought) {
                thinking += t;
                push((m) => ({ ...m, thinking: (m.thinking || '') + t }));
              } else {
                content += t;
                push((m) => ({ ...m, content: m.content + t }));
              }
            }
            if (cand?.finishReason) finishReason = cand.finishReason;
          } catch (e) {
            if (e instanceof Error && e.message.includes('safety')) throw e;
          }
        }
      }
    }

    if (!content.trim() && !thinking.trim()) {
      throw new Error(
        finishReason === 'SAFETY'
          ? 'Google đã chặn câu trả lời vì lý do an toàn.'
          : 'Gemini không trả về nội dung — thử lại hoặc đặt lại câu hỏi.'
      );
    }

    // 5. Xong — lưu về DB
    push((m) => ({ ...m, streaming: false, status: 'done' }));
    await finalize('done');
  } catch (e) {
    const aborted = e instanceof DOMException && e.name === 'AbortError';
    if (aborted) {
      push((m) => ({ ...m, streaming: false, status: 'stopped' }));
      await finalize('stopped');
      return;
    }
    const msg = e instanceof Error ? e.message : 'Lỗi gọi Google Gemini';
    push((m) => ({ ...m, error: msg, streaming: false, status: 'error' }));
    await finalize('error', msg);
  }
}

// ================= Store =================
export const useAppStore = create<AppState>((set, get) => ({
  sessions: [],
  projects: [],
  sites: [],
  customSkills: [],
  activeSessionId: null,
  activeProjectId: null,
  sidebarOpen: true,

  user: null,
  googleConfigured: false,
  authError: null,

  messages: [],
  streaming: false,
  pendingPhase: null,
  activePersonaId: null,

  model: 'shark-1',
  mode: 'normal',
  topic: 'chung',
  think: 'off',
  speed: 'medium',
  enabledSkills: [],
  groupAI: false,

  panelOpen: false,
  panelTab: 'files',
  previewSrc: null,
  filesVersion: 0,

  modal: null,

  openedFile: null,
  setOpenedFile: (f) => set({ openedFile: f }),

  setModel: (v) => set({ model: v }),
  setMode: (v) => set({ mode: v }),
  setTopic: (v) => set({ topic: v }),
  setThink: (v) => set({ think: v }),
  setSpeed: (v) => set({ speed: v }),
  toggleSkill: (id) =>
    set((s) => ({
      enabledSkills: s.enabledSkills.includes(id)
        ? s.enabledSkills.filter((x) => x !== id)
        : [...s.enabledSkills, id],
    })),
  // BẬT: sang trang Group AI · TẮT: về trang chat thường (kiểu vico)
  // Nếu phiên đang mở thuộc loại khác và đã có nội dung → mở phiên trống cho sạch
  setGroupAI: (v) => {
    const s = get();
    if (s.groupAI === v) return;
    const cur = s.sessions.find((x) => x.id === s.activeSessionId);
    const needFresh = !!cur && !!cur.groupAI !== v && s.messages.length > 0;
    if (needFresh) {
      abortController?.abort();
      abortController = null;
      set({
        activeSessionId: null,
        messages: [],
        pendingPhase: null,
        activePersonaId: null,
        streaming: false,
        groupAI: v,
      });
      get().refreshSessions();
    } else {
      set({ groupAI: v });
    }
  },
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setPanelOpen: (v) => set({ panelOpen: v }),
  setPanelTab: (v) => set({ panelTab: v, panelOpen: true }),
  openPreview: (src) => set({ panelOpen: true, panelTab: 'preview', previewSrc: src }),
  setPreviewSrc: (src) => set({ previewSrc: src }),
  bumpFiles: () => set((s) => ({ filesVersion: s.filesVersion + 1 })),
  openModal: (m) => set({ modal: m }),

  refreshSessions: async () => {
    try {
      const res = await fetch('/api/sessions');
      set({ sessions: await res.json() });
    } catch {}
  },

  refreshProjects: async () => {
    try {
      const res = await fetch('/api/projects');
      set({ projects: await res.json() });
    } catch {}
  },

  refreshSites: async () => {
    try {
      const res = await fetch('/api/publish');
      set({ sites: await res.json() });
    } catch {}
  },

  refreshCustomSkills: async () => {
    try {
      const res = await fetch('/api/skills');
      set({ customSkills: await res.json() });
    } catch {}
  },

  deleteSite: async (id) => {
    await fetch(`/api/sites/${id}`, { method: 'DELETE' }).catch(() => {});
    await get().refreshSites();
  },

  setActiveProject: (id) => set({ activeProjectId: id }),

  loadSession: async (id) => {
    // Ngắt stream cục bộ của phiên cũ — server vẫn chạy nền, quay lại sẽ poll từ DB
    abortController?.abort();
    abortController = null;
    try {
      const res = await fetch(`/api/sessions/${id}`);
      if (!res.ok) return;
      const session = await res.json();
      const msgs = mapDbMessages(session.messages);
      const hasRunning = msgs.some((m) => m.status === 'running');
      set({
        activeSessionId: id,
        messages: msgs,
        streaming: hasRunning,
        model: session.model,
        mode: session.mode,
        topic: session.topic,
        think: session.think,
        speed: session.speed,
        groupAI: session.groupAI,
        activeProjectId: session.projectId,
      });
      // Mở lại phiên → nạp lại cây thư mục để thấy file mới ngay (không cần tải lại trang)
      get().bumpFiles();
      // khôi phục poll các video đang xử lý
      for (const m of msgs) {
        for (const ev of m.events || []) {
          if (ev.kind === 'tool' && ev.result?.type === 'video_task' && ev.result?.status === 'processing' && ev.result?.taskId) {
            get().pollVideoTask(m.id, ev.result.taskId);
          }
        }
      }
      // phiên đang chạy nền (hoặc sắp chạy) → poll để cập nhật liên tục
      const lastIsUser = msgs.length > 0 && msgs[msgs.length - 1].role === 'user';
      if (hasRunning || lastIsUser) startPolling(id);
      else stopPolling(id);
    } catch {}
  },

  newChat: () => {
    // server vẫn tiếp tục các tác vụ nền; ta chỉ rời khung nhìn
    abortController?.abort();
    abortController = null;
    set({ activeSessionId: null, messages: [], pendingPhase: null, streaming: false });
  },

  deleteSession: async (id) => {
    stopPolling(id);
    await fetch(`/api/sessions/${id}`, { method: 'DELETE' }).catch(() => {});
    if (get().activeSessionId === id) get().newChat();
    await get().refreshSessions();
  },

  togglePin: async (id, pinned) => {
    await fetch(`/api/sessions/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pinned }),
    }).catch(() => {});
    await get().refreshSessions();
  },

  renameSession: async (id, title) => {
    await fetch(`/api/sessions/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    }).catch(() => {});
    await get().refreshSessions();
  },

  refreshUser: async () => {
    try {
      const res = await fetch('/api/auth/me');
      const data = await res.json();
      set({ user: data.user || null, googleConfigured: !!data.googleConfigured });
    } catch {}
  },

  loginQuick: async (name, email) => {
    try {
      const res = await fetch('/api/auth/quick', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email }),
      });
      if (!res.ok) return false;
      await get().refreshUser();
      await get().refreshSessions();
      return true;
    } catch {
      return false;
    }
  },

  // Đăng nhập bằng email + mật khẩu (cookie 60 ngày, dùng được trên mọi thiết bị)
  // Trả về: ok | no_password (tài khoản cũ chưa đặt mk — UI tự chuyển tab Đăng ký) | error
  loginPassword: async (email, password) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data.code === 'no_password') {
          // không set authError — UI tự chuyển tab Tạo tài khoản kèm banner xanh hướng dẫn
          set({ authError: null });
          return 'no_password';
        }
        set({ authError: data.error || 'Email hoặc mật khẩu không đúng' });
        return 'error';
      }
      set({ authError: null });
      await get().refreshUser();
      await get().refreshSessions();
      return 'ok';
    } catch {
      set({ authError: 'Không kết nối được máy chủ — thử lại' });
      return 'error';
    }
  },

  // Tạo tài khoản mới (email + mật khẩu) — xong tự đăng nhập luôn
  registerAccount: async (name, email, password) => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        set({ authError: data.error || 'Không tạo được tài khoản' });
        return false;
      }
      set({ authError: null });
      await get().refreshUser();
      await get().refreshSessions();
      return true;
    } catch {
      set({ authError: 'Không kết nối được máy chủ — thử lại' });
      return false;
    }
  },

  logoutUser: async () => {
    await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    await get().refreshUser();
    get().newChat();
    await get().refreshSessions();
  },

  stop: () => {
    // Huỷ tác vụ đang chạy trên server (cả khi chạy nền) + dừng stream cục bộ
    const sid = get().activeSessionId;
    if (sid) {
      fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cancelSessionId: sid }),
      }).catch(() => {});
      stopPolling(sid);
    }
    abortController?.abort();
    abortController = null;
    set((s) => ({
      streaming: false,
      pendingPhase: null,
      messages: s.messages.map((m) => (m.streaming ? { ...m, streaming: false, status: 'stopped' } : m)),
    }));
  },

  editMessage: async (id, newContent) => {
    if (get().streaming) return;
    const msgs = get().messages;
    const idx = msgs.findIndex((m) => m.id === id);
    if (idx < 0 || msgs[idx].role !== 'user') return;
    const target = msgs[idx];
    try {
      const res = await fetch(`/api/messages/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newContent }),
      });
      if (!res.ok) return;
    } catch {
      return;
    }
    // cắt mọi tin nhắn phía sau + cập nhật nội dung đã sửa
    set({ messages: [...msgs.slice(0, idx), { ...target, content: newContent }] });
    await get().send(newContent, target.attachments || [], { reuseUserMessageId: id });
  },

  regenerate: async (assistantMsgId) => {
    if (get().streaming) return;
    const msgs = get().messages;
    const idx = msgs.findIndex((m) => m.id === assistantMsgId);
    if (idx < 0) return;
    // tìm tin nhắn user gần nhất phía trước
    let userIdx = idx - 1;
    while (userIdx >= 0 && msgs[userIdx].role !== 'user') userIdx--;
    if (userIdx < 0) return;
    const userMsg = msgs[userIdx];
    try {
      const res = await fetch(`/api/messages/${assistantMsgId}`, { method: 'DELETE' });
      if (!res.ok) return;
    } catch {
      return;
    }
    set({ messages: msgs.slice(0, userIdx + 1) });
    await get().send(userMsg.content, userMsg.attachments || [], { reuseUserMessageId: userMsg.id });
  },

  send: async (text, attachments, opts) => {
    if (get().streaming) return;
    const reuseId = opts?.reuseUserMessageId;
    const tempAssistantId = `tmp-a-${Date.now()}`;
    // id tạm của tin nhắn user — meta event từ server sẽ trả về id thật để thay thế
    // (không thay sẽ khiến Sửa tin nhắn → PATCH /api/messages/tmp-u-... → 404)
    const tempUserId = reuseId ? null : `tmp-u-${Date.now()}`;
    const assistantMsg: ChatMessage = {
      id: tempAssistantId,
      role: 'assistant',
      content: '',
      model: get().model,
      streaming: true,
      events: [],
    };
    if (reuseId) {
      // sửa/tạo lại: tin nhắn user đã có sẵn trong khung chat
      set((s) => ({ messages: [...s.messages, assistantMsg], streaming: true, pendingPhase: null }));
    } else {
      const userMsg: ChatMessage = {
        id: tempUserId as string,
        role: 'user',
        content: text,
        attachments: attachments.length ? attachments : undefined,
      };
      set((s) => ({
        messages: [...s.messages, userMsg, assistantMsg],
        streaming: true,
        pendingPhase: null,
      }));
    }

    abortController = new AbortController();
    let currentAssistantId = tempAssistantId;
    let streamSessionId: string | null = null;
    let abortedFlag = false;
    // Gemini delegate: server phát event rồi browser tự gọi Google (server bị Google chặn geo)
    let geminiDelegate: GeminiDelegate | null = null;

    const pushToAssistant = (fn: (m: ChatMessage) => ChatMessage) => {
      set((s) => ({
        messages: s.messages.map((m) => (m.id === currentAssistantId ? fn(m) : m)),
      }));
    };

    const startPersona = (p: { id: string; name: string; role: string; color: string; icon?: string }) => {
      const id = `tmp-p-${p.id}-${Date.now()}`;
      currentAssistantId = id;
      set((s) => ({
        activePersonaId: p.id,
        messages: [
          ...s.messages.map((m) => (m.streaming ? { ...m, streaming: false } : m)),
          {
            id,
            role: 'assistant',
            content: '',
            model: `persona:${p.id}`,
            streaming: true,
            events: [{ kind: 'persona', id: p.id, name: p.name, role: p.role, color: p.color, icon: p.icon }],
          } as ChatMessage,
        ],
      }));
    };

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: get().activeSessionId,
          message: text,
          attachments,
          model: get().model,
          mode: get().mode,
          topic: get().topic,
          think: get().think,
          speed: get().speed,
          enabledSkills: get().enabledSkills,
          groupAI: get().groupAI,
          reuseUserMessageId: reuseId,
        }),
        signal: abortController.signal,
      });

      if (!res.ok || !res.body) throw new Error('Không kết nối được máy chủ');

      const reader = res.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let buf = '';

      const handleEvent = (ev: Record<string, unknown>) => {
        const type = ev.type as string;
        switch (type) {
          case 'meta': {
            if (ev.sessionId) {
              streamSessionId = ev.sessionId as string;
              set({ activeSessionId: streamSessionId });
            }
            // đổi id tạm thành id thật trong DB (để sửa/tạo lại sau này)
            // — assistant: id dòng assistant đang stream
            // — user: id dòng user vừa tạo (trước đây BỎ QUA → lỗi 404 khi sửa tin nhắn)
            if (ev.assistantMessageId) {
              const realId = ev.assistantMessageId as string;
              set((s) => ({
                messages: s.messages.map((m) => (m.id === tempAssistantId ? { ...m, id: realId } : m)),
              }));
              currentAssistantId = realId;
            }
            if (ev.userMessageId && tempUserId) {
              const realUserId = ev.userMessageId as string;
              set((s) => ({
                messages: s.messages.map((m) => (m.id === tempUserId ? { ...m, id: realUserId } : m)),
              }));
            }
            break;
          }
          case 'thinking':
            pushToAssistant((m) => ({ ...m, thinking: (m.thinking || '') + (ev.delta as string) }));
            break;
          case 'content':
            pushToAssistant((m) => ({ ...m, content: m.content + (ev.delta as string) }));
            break;
          case 'phase':
            set({ pendingPhase: (ev.detail as string) || null });
            pushToAssistant((m) => ({
              ...m,
              events: [...(m.events || []), { kind: 'phase', phase: ev.phase as string, detail: ev.detail as string }],
            }));
            break;
          case 'tool_result': {
            const chatEv: ChatEvent = {
              kind: 'tool',
              name: ev.name as string,
              args: (ev.args as Record<string, unknown>) || {},
              result: (ev.result as ToolResultData) || {},
              ok: !!ev.ok,
              step: ev.step as number | undefined,
            };
            pushToAssistant((m) => ({ ...m, events: [...(m.events || []), chatEv] }));
            if (chatEv.result?.type === 'video_task' && chatEv.result?.taskId) {
              get().pollVideoTask(currentAssistantId, chatEv.result.taskId);
            }
            if (['write_file', 'generate_image', 'run_terminal'].includes(chatEv.name)) {
              get().bumpFiles();
            }
            // Agent vừa tạo/sửa file .html → tự động mở bản xem trước (đa tệp: ghép cả CSS/JS)
            const toolPath = String(chatEv.result?.path || '');
            if (
              ['write_file'].includes(chatEv.name) &&
              /\.html?$/i.test(toolPath) &&
              ev.ok !== false
            ) {
              get().openPreview(`/api/preview-bundle?path=${encodeURIComponent(toolPath)}`);
            }
            break;
          }
          case 'sources':
            pushToAssistant((m) => ({
              ...m,
              events: [
                ...(m.events || []),
                { kind: 'sources', sources: (ev.sources as { url: string; name: string; snippet: string }[]) || [] },
              ],
            }));
            break;
          case 'reflection':
            pushToAssistant((m) => ({
              ...m,
              events: [...(m.events || []), { kind: 'reflection', text: ev.text as string }],
            }));
            break;
          case 'persona':
            startPersona(ev as unknown as { id: string; name: string; role: string; color: string; icon?: string });
            break;
          case 'persona_done':
            pushToAssistant((m) => ({ ...m, streaming: false }));
            set({ activePersonaId: null });
            break;
          case 'title':
            set((s) => ({
              sessions: s.sessions.map((x) =>
                x.id === s.activeSessionId ? { ...x, title: ev.title as string } : x
              ),
            }));
            get().refreshSessions();
            break;
          case 'delegate':
            // Server vừa giao quyền cho client gọi Google trực tiếp
            geminiDelegate = {
              model: (ev.model as string) || 'gemini-3.8-flash',
              system: (ev.system as string) || '',
              history: (ev.history as GeminiDelegate['history']) || [],
              userText: (ev.userText as string) || '',
            };
            break;
          case 'error':
            pushToAssistant((m) => ({ ...m, error: (ev.message as string) || 'Lỗi' }));
            break;
          case 'done':
            break;
        }
      };

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buf.indexOf('\n\n')) >= 0) {
          const block = buf.slice(0, idx);
          buf = buf.slice(idx + 2);
          for (const line of block.split('\n')) {
            if (!line.startsWith('data:')) continue;
            try {
              handleEvent(JSON.parse(line.slice(5).trim()));
            } catch {}
          }
        }
      }

      // Gemini: browser tự gọi Google streamGenerateContent (server không gọi được)
      if (geminiDelegate) {
        abortController = new AbortController(); // nút Dừng giờ huỷ luồng Google
        await runGeminiDirect(geminiDelegate, currentAssistantId, pushToAssistant, abortController.signal);
      }
    } catch (e) {
      const aborted = e instanceof DOMException && e.name === 'AbortError';
      abortedFlag = aborted;
      if (!aborted) {
        pushToAssistant((m) => ({ ...m, error: e instanceof Error ? e.message : 'Lỗi kết nối' }));
      }
    } finally {
      // Nếu stream cục bộ bị ngắt (rời phiên) → server vẫn chạy nền,
      // poll phiên đó để tiếp tục cập nhật khi user quay lại
      set((s) => ({
        streaming: false,
        pendingPhase: null,
        activePersonaId: null,
        messages: s.messages.map((m) => (m.streaming ? { ...m, streaming: false } : m)),
      }));
      abortController = null;
      get().refreshSessions();
      get().bumpFiles(); // agent có thể vừa tạo file → cây thư mục cập nhật ngay
      if (abortedFlag && streamSessionId) startPolling(streamSessionId);
    }
  },

  pollVideoTask: async (msgId, taskId) => {
    for (let i = 0; i < 90; i++) {
      await new Promise((r) => setTimeout(r, 5000));
      try {
        const res = await fetch(`/api/video?taskId=${taskId}`);
        const data = await res.json();
        if (data.status === 'done' && data.url) {
          set((s) => ({ messages: updateMessageVideoStatus(s.messages, msgId, taskId, 'done', data.url) }));
          return;
        }
        if (data.status === 'fail') {
          set((s) => ({ messages: updateMessageVideoStatus(s.messages, msgId, taskId, 'fail') }));
          return;
        }
      } catch {}
    }
    set((s) => ({ messages: updateMessageVideoStatus(s.messages, msgId, taskId, 'fail') }));
  },
}));

// lưu skills khi thay đổi + khôi phục khi mở app
if (typeof window !== 'undefined') {
  useAppStore.subscribe((s, prev) => {
    if (s.enabledSkills !== prev.enabledSkills) {
      localStorage.setItem('shark-skills', JSON.stringify(s.enabledSkills));
    }
  });
  try {
    const saved =
      localStorage.getItem('shark-skills') || localStorage.getItem('nova-skills');
    if (saved) {
      const arr = JSON.parse(saved);
      if (Array.isArray(arr) && arr.length) {
        useAppStore.setState({ enabledSkills: arr.filter((x) => typeof x === 'string') });
      }
    }
    if (localStorage.getItem('nova-skills')) localStorage.removeItem('nova-skills');
    if (localStorage.getItem('nova-credit')) localStorage.removeItem('nova-credit');
  } catch {}
}
