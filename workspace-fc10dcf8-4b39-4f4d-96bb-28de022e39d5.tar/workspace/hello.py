# In ra dòng chào mừng
print('Xin chao Nova AI')
