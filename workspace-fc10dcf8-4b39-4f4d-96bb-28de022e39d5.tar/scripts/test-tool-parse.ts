// Test extractToolCall với các format model thực tế hay gặp
import { extractToolCall } from '../src/lib/tools';

const cases: { name: string; input: string; expectTool?: string; expectPath?: string }[] = [
  {
    name: 'JSON chuẩn',
    input: 'Trước. <tool>{"name":"write_file","args":{"path":"a.html","content":"<h1>X</h1>"}}</tool>',
    expectTool: 'write_file',
    expectPath: 'a.html',
  },
  {
    name: 'JSON newline thô trong content (repair)',
    input: 'Ok.\n<tool>{"name":"write_file","args":{"path":"b.html","content":"line1\nline2"}}</tool>',
    expectTool: 'write_file',
    expectPath: 'b.html',
  },
  {
    name: 'pseudo-XML content attribute (lỗi thật từ model)',
    input:
      '<tool>\n<write_file>\n<path>demo-shark.html</path>\ncontent="<!DOCTYPE html>\n<html lang="vi">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body>\n    <h1>Shark Agent</h1>\n</body>\n</html>"\n</tool>',
    expectTool: 'write_file',
    expectPath: 'demo-shark.html',
  },
  {
    name: 'XML chuẩn có thẻ đóng',
    input: '<tool><write_file><path>c.py</path><content>print(1)</content></write_file></tool>',
    expectTool: 'write_file',
    expectPath: 'c.py',
  },
  {
    name: 'pseudo-XML không có content=, chỉ path rồi text',
    input: '<tool>\n<write_file>\n<path>d.html</path>\n<html><body>Hi</body></html>\n</tool>',
    expectTool: 'write_file',
    expectPath: 'd.html',
  },
  {
    name: 'run_terminal JSON chuẩn',
    input: '<tool>{"name":"run_terminal","args":{"command":"ls -la"}}</tool>',
    expectTool: 'run_terminal',
  },
  {
    name: 'tên tool + JSON rời',
    input: '<tool>write_file</tool>\n<tool>{"path":"e.js","content":"let a = 1"}</tool>',
    expectTool: 'write_file',
    expectPath: 'e.js',
  },
];

let pass = 0;
let fail = 0;
for (const c of cases) {
  const { tool, textBefore } = extractToolCall(c.input);
  const okName = !c.expectTool || tool?.name === c.expectTool;
  const okPath = !c.expectPath || String(tool?.args?.path || '') === c.expectPath;
  if (okName && okPath) {
    pass++;
    console.log(`PASS: ${c.name} → ${tool?.name} path=${tool?.args?.path} contentLen=${String(tool?.args?.content || '').length} before=${JSON.stringify((textBefore||'').slice(0,20))}`);
  } else {
    fail++;
    console.log(`FAIL: ${c.name} → got tool=${tool?.name} path=${tool?.args?.path}`);
  }
}
console.log(`\n${pass} pass / ${fail} fail`);
process.exit(fail ? 1 : 0);
