#!/usr/bin/env python3
# Thay thế hàm streamToClient (dòng 592-707) trong route.ts bằng bản fix:
# - Giữ rawAll (toàn bộ raw output kể cả <tool> JSON) để extractToolCall tìm được tool
# - Ẩn <tool>...</tool> khỏi hiển thị, text sau </tool> vẫn hiển thị
import io

PATH = '/home/z/my-project/src/app/api/chat/route.ts'

NEW_FUNC = r'''async function streamToClient(
  body: ReadableStream<Uint8Array> | null,
  writer: SSEWriter,
  opts: { collect: (content: string, thinking: string) => void; stop?: () => boolean }
): Promise<StreamResult> {
  const OPEN_T = '<suy>';
  const CLOSE_T = '</suy>';
  const OPEN_TOOL = '<tool>';
  const CLOSE_TOOL = '</tool>';
  const MAX_HOLD = Math.max(OPEN_T.length, CLOSE_T.length, OPEN_TOOL.length) - 1;

  let buf = '';
  let fullText = ''; // text hiển thị (đã lọc bỏ khối <tool> JSON)
  let rawAll = ''; // TOÀN BỘ raw model output (kể cả <tool> JSON) — nguồn cho extractToolCall
  let fullThinking = '';
  let inThink = false;
  let inTool = false;

  const safePrefixLength = (s: string, tags: string[]): number => {
    for (let i = s.length - 1; i >= Math.max(0, s.length - MAX_HOLD); i--) {
      const tail = s.slice(i);
      if (tags.some((t) => t.startsWith(tail))) return i;
    }
    return s.length;
  };

  const processBuffer = async (flush: boolean) => {
    while (buf.length > 0) {
      // đang nằm trong khối <tool>...</tool> — ẩn JSON khỏi hiển thị
      // (rawAll vẫn giữ nguyên để extractToolCall đọc được tool call)
      if (inTool) {
        const closeIdx = buf.indexOf(CLOSE_TOOL);
        if (closeIdx >= 0) {
          // hết khối tool — text sau </tool> hiển thị bình thường trở lại
          buf = buf.slice(closeIdx + CLOSE_TOOL.length);
          inTool = false;
          continue;
        }
        // chưa thấy </tool>: giữ nguyên trong buf chờ tag đóng
        // (flush mà vẫn chưa đóng → tool JSON dở, vứt phần hiển thị)
        if (flush) buf = '';
        return;
      }
      if (inThink) {
        const closeIdx = buf.indexOf(CLOSE_T);
        if (closeIdx >= 0) {
          const seg = buf.slice(0, closeIdx);
          if (seg) {
            fullThinking += seg;
            await writer.send({ type: 'thinking', delta: seg });
          }
          buf = buf.slice(closeIdx + CLOSE_T.length);
          inThink = false;
          continue;
        }
        if (flush) {
          fullThinking += buf;
          await writer.send({ type: 'thinking', delta: buf });
          buf = '';
        } else {
          const safe = safePrefixLength(buf, [CLOSE_T]);
          if (safe > 0) {
            const seg = buf.slice(0, safe);
            fullThinking += seg;
            await writer.send({ type: 'thinking', delta: seg });
            buf = buf.slice(safe);
          }
          return;
        }
        continue;
      }
      // ngoài think: tìm <tool> và <suy>
      const gi = buf.indexOf(OPEN_TOOL);
      const ti = buf.indexOf(OPEN_T);
      if (gi >= 0 && (ti < 0 || gi < ti)) {
        const seg = buf.slice(0, gi);
        if (seg) {
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
        }
        buf = buf.slice(gi + OPEN_TOOL.length);
        inTool = true;
        continue;
      }
      if (ti >= 0) {
        const seg = buf.slice(0, ti);
        if (seg) {
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
        }
        buf = buf.slice(ti + OPEN_T.length);
        inThink = true;
        continue;
      }
      if (flush) {
        fullText += buf;
        await writer.send({ type: 'content', delta: buf });
        buf = '';
      } else {
        const safe = safePrefixLength(buf, [OPEN_T, OPEN_TOOL]);
        if (safe > 0) {
          const seg = buf.slice(0, safe);
          fullText += seg;
          await writer.send({ type: 'content', delta: seg });
          buf = buf.slice(safe);
        }
        return;
      }
    }
  };

  for await (const delta of parseSDKStream(body)) {
    // Tiếp tục đọc stream kể cả khi client ngắt kết nối (chạy nền),
    // nhưng dừng ngay nếu người dùng chủ động huỷ
    if (opts.stop?.()) break;
    // Suy nghĩ gốc (reasoning_content) — đẩy xuống client NGAY, xuất hiện TRƯỚC câu trả lời (kiểu DeepSeek)
    if (delta.thinking) {
      fullThinking += delta.thinking;
      await writer.send({ type: 'thinking', delta: delta.thinking });
    }
    rawAll += delta.content; // bản gốc chưa lọc — tool call sống ở đây
    buf += delta.content;
    await processBuffer(false);
  }
  await processBuffer(true);
  opts.collect(fullText, fullThinking);

  // FIX QUAN TRỌNG: extractToolCall phải chạy trên BẢN GỐC đầy đủ (rawAll)
  // — trước đây chạy trên fullText (đã lọc bỏ <tool> JSON) nên tool không bao giờ
  // được tìm thấy → tạo ảnh / tạo video qua chat luôn thất bại.
  const { tool } = extractToolCall(rawAll);
  return { fullText, fullThinking, tool };
}
'''

with io.open(PATH, 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Hàm bắt đầu tại dòng 592 (index 591) — "async function streamToClient("
# và kết thúc tại dòng 707 (index 706) — "}"
start = None
for i, ln in enumerate(lines):
    if ln.startswith('async function streamToClient('):
        start = i
        break
if start is None:
    raise SystemExit('Không tìm thấy streamToClient')

# Tìm dòng "}" đóng hàm (dòng chỉ chứa "}" ở đầu file section này)
end = None
for j in range(start, len(lines)):
    if lines[j].rstrip() == '}':
        end = j  # dòng "}" đầu tiên cấp 0 sau start chính là kết thúc hàm
        break
if end is None:
    raise SystemExit('Không tìm thấy kết thúc hàm')

new_lines = [NEW_FUNC + '\n']
lines[start:end + 1] = new_lines

with io.open(PATH, 'w', encoding='utf-8') as f:
    f.writelines(lines)

print(f'OK — đã thay streamToClient (dòng {start + 1}-{end + 1}) bằng bản fix rawAll')
