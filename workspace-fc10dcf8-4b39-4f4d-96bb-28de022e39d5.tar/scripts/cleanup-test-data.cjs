// Dọn dẹp dữ liệu test: xoá phiên do automation tạo, trả phiên thật về ẩn danh, xoá user test
const { PrismaClient } = require('@prisma/client');
const db = new PrismaClient();

(async () => {
  // 1. Các phiên do curl test tạo (thuộc lam@test.com, tạo sau 04:55 hôm nay theo thứ tự test)
  // Xác định qua nội dung tin nhắn đặc trưng
  const testMarkers = [
    'Viết 1 câu ngắn về cá mập',
    'Nghiên cứu xu hướng AI 2026',
    'Chào bạn, bạn là AI gì?',
    'Chào bạn', // edit-test session bắt đầu bằng "Chào bạn"
    'Nghiên cứu chi tiết về tàu điện ngầm',
    'Nghiên cứu ngắn về lịch sử tàu điện ngầm Hà Nội', // browser research test (đã bị xoá, khoá an toàn)
    'Tạo cho mình file Cargo.toml', // agent test (nếu ở phiên riêng)
  ];

  const lam = await db.user.findUnique({ where: { email: 'lam@test.com' }, include: { sessions: { include: { messages: true } } } });
  let deleted = 0;
  if (lam) {
    for (const s of lam.sessions) {
      const firstUser = s.messages.find((m) => m.role === 'user');
      const isTest = firstUser && testMarkers.some((t) => (firstUser.content || '').includes(t));
      if (isTest) {
        await db.chatSession.delete({ where: { id: s.id } });
        deleted++;
        console.log('ĐÃ XOÁ phiên test:', s.title, '| msg:', firstUser?.content?.slice(0, 40));
      }
    }
    // 2. Trả các phiên thật về ẩn danh
    await db.chatSession.updateMany({ where: { userId: lam.id }, data: { userId: null } });
    await db.user.delete({ where: { id: lam.id } });
    console.log('Đã xoá user test lam@test.com, xoá', deleted, 'phiên test, trả phần còn lại về ẩn danh');
  }

  // 3. User test vutunglam08: trả phiên "Phiên web HTML của mình" về ẩn danh + khôi phục tên + nội dung gốc
  const v = await db.user.findUnique({ where: { email: 'vutunglam08@shark.app' }, include: { sessions: true } });
  if (v) {
    for (const s of v.sessions) {
      if (s.title === 'Phiên web HTML của mình') {
        await db.chatSession.update({ where: { id: s.id }, data: { title: 'Tạo trang web HTML', userId: null } });
        const firstUser = await db.message.findFirst({ where: { sessionId: s.id, role: 'user' }, orderBy: { createdAt: 'asc' } });
        if (firstUser && firstUser.content !== 'Tạo html') {
          await db.message.update({ where: { id: firstUser.id }, data: { content: 'Tạo html' } });
        }
        console.log('Đã khôi phục phiên user: Tạo trang web HTML');
      } else {
        await db.chatSession.update({ where: { id: s.id }, data: { userId: null } });
        console.log('Đã trả phiên về ẩn danh:', s.title);
      }
    }
    await db.user.delete({ where: { id: v.id } });
    console.log('Đã xoá user test vutunglam08@shark.app');
  }

  // 4. Tổng kết
  const users = await db.user.findMany();
  const anon = await db.chatSession.count({ where: { userId: null } });
  const orphan = await db.chatSession.count({ where: { userId: { not: null } } });
  console.log('--- TỔNG KẾT ---');
  console.log('users còn lại:', users.length, '| phiên ẩn danh:', anon, '| phiên có chủ (mồ côi nếu user đã xoá):', orphan);
  await db.$disconnect();
})();
