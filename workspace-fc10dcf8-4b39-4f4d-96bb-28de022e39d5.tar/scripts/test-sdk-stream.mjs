// Debug: test SDK stream trực tiếp để xem model trả gì
import ZAI from 'z-ai-web-dev-sdk';

async function main() {
  const zai = await ZAI.create();
  const msgs = [
    {
      role: 'assistant',
      content:
        'Bạn là Shark 1.0...Khi người dùng yêu cầu tạo ảnh, hãy gọi tool generate_image theo format: <tool>{"name":"generate_image","args":{"prompt":"..."}}</tool>',
    },
    { role: 'user', content: 'Tạo giúp mình 1 ảnh con mèo cam dễ thương' },
  ];
  const body = await zai.chat.completions.create({
    messages: msgs,
    stream: true,
    thinking: { type: 'disabled' },
  });
  console.log('stream body type:', typeof body, body && typeof body.getReader);
  let raw = '';
  try {
    const reader = body.getReader();
    const dec = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      raw += dec.decode(value, { stream: true });
    }
  } catch (e) {
    console.log('reader error:', e);
  }
  console.log('=== RAW SSE (first 3000 chars) ===');
  console.log(raw.slice(0, 3000));
  console.log('=== total length:', raw.length);
}

main().catch((e) => {
  console.error('FATAL:', e);
  process.exit(1);
});
