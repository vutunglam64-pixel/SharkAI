#!/bin/bash
# Test chat flow with image generation request
curl -sN -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Tạo giúp mình 1 ảnh con mèo cam dễ thương","model":"shark-1","mode":"normal","topic":"chung","think":"off","speed":"medium","enabledSkills":["image-gen"]}' \
  --max-time 120 | head -c 4000
