// Dọn các phiên chat test Kimi K2 (guest, tạo lúc test)
const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();

async function main() {
  const sessions = await p.chatSession.findMany({
    where: { title: { contains: 'mô hình gì' } },
    select: { id: true, title: true, userId: true, createdAt: true },
  });
  console.log('Phiên test tìm thấy:', JSON.stringify(sessions, null, 2));
  for (const s of sessions) {
    await p.message.deleteMany({ where: { sessionId: s.id } });
    await p.chatSession.delete({ where: { id: s.id } });
    console.log('Đã xoá:', s.id, '-', s.title);
  }
  // xoá user test kimi-test@shark.local nếu còn (key đã xoá qua API)
  const u = await p.user.findFirst({ where: { email: 'kimi-test@shark.local' } });
  if (u) {
    await p.user.delete({ where: { id: u.id } });
    console.log('Đã xoá user test:', u.email);
  }
  const total = await p.chatSession.count();
  console.log('Tổng phiên còn lại:', total);
}

main().finally(() => p.$disconnect());
