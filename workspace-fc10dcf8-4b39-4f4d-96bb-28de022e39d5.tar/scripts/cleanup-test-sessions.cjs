// Dọn các phiên chat test tạo trong đợt fix này (không đụng dữ liệu thật của user)
const { PrismaClient } = require('@prisma/client');
const p = new PrismaClient();

(async () => {
  // tìm session chứa message test browser (robot/corgi)
  const browserMsg = await p.message.findUnique({ where: { id: 'cmvqkdrr40017p5ihroekp4ox' } });
  const ids = [
    'cmvqk0vl7000lp5ihegi9l9sd', // test ảnh rỗng (bug cũ)
    'cmvqk7dum000rp5ihrhikik1g', // test ảnh + PATCH XÁM
    'cmvqk9ot0000xp5ih7zj3tq4n', // test video
    browserMsg ? browserMsg.sessionId : null, // test browser robot→corgi
  ].filter(Boolean);

  for (const id of ids) {
    const s = await p.chatSession.findUnique({ where: { id } });
    if (!s) { console.log('skip (không tồn tại):', id); continue; }
    await p.message.deleteMany({ where: { sessionId: id } });
    await p.chatSession.delete({ where: { id } });
    console.log('đã xoá phiên test:', s.title, '(', id, ')');
  }

  const count = await p.chatSession.count();
  console.log('Số phiên còn lại:', count);
  await p.$disconnect();
})();
