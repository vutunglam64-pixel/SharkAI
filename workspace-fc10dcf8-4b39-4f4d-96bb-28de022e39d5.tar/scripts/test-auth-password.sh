#!/bin/bash
# Test hệ thống tài khoản mật khẩu: đăng ký → lưu cookie → đăng nhập máy khác → đồng bộ → logout
set -e
BASE="http://localhost:3000"
EMAIL="lam.test.shark@gmail.com"
PASS="matkhau123"
JAR1="/tmp/shark-machine1.txt"   # máy 1: nơi đăng ký
JAR2="/tmp/shark-machine2.txt"   # máy 2: nơi đăng nhập lại (cookie jar riêng)
rm -f "$JAR1" "$JAR2"

step() { echo ""; echo "=== $1 ==="; }

step "1. ĐĂNG KÝ (máy 1): tab Tạo tài khoản"
curl -s -c "$JAR1" -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' \
  -d "{\"name\":\"Lam Test\",\"email\":\"$EMAIL\",\"password\":\"$PASS\"}"
echo ""

step "2. Cookie máy 1 có shark_session không? (httpOnly, maxAge 60 ngày)"
grep shark_session "$JAR1" | head -2 || echo "KHÔNG CÓ COOKIE!"

step "3. THOÁT WEB VÀO LẠI (máy 1): GET /api/auth/me với cookie cũ"
curl -s -b "$JAR1" "$BASE/api/auth/me"
echo ""

step "4. Đăng ký TRÙNG email đã có mật khẩu → phải báo 409"
curl -s -o /dev/null -w "HTTP %{http_code} — " -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' \
  -d "{\"name\":\"Ai đó\",\"email\":\"$EMAIL\",\"password\":\"khac123\"}"
curl -s -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' \
  -d "{\"name\":\"Ai đó\",\"email\":\"$EMAIL\",\"password\":\"khac123\"}"
echo ""

step "5. Đăng nhập SAI mật khẩu → 401"
curl -s -o /dev/null -w "HTTP %{http_code}\n" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"sairoi123\"}"

step "6. QUICK LOGIN vào tài khoản có mật khẩu → bị chặn (chống chiếm tài khoản)"
curl -s -o /dev/null -w "HTTP %{http_code} — " -X POST "$BASE/api/auth/quick" -H 'Content-Type: application/json' \
  -d "{\"name\":\"Hacker\",\"email\":\"$EMAIL\"}"
curl -s -X POST "$BASE/api/auth/quick" -H 'Content-Type: application/json' \
  -d "{\"name\":\"Hacker\",\"email\":\"$EMAIL\"}"
echo ""

step "7. MÁY 2 (cookie jar trống): đăng nhập đúng mật khẩu"
curl -s -c "$JAR2" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS\"}"
echo ""

step "8. Máy 2 đọc /api/auth/me → cùng tài khoản"
curl -s -b "$JAR2" "$BASE/api/auth/me"
echo ""

step "9. Tạo phiên chat trên máy 2 → máy 1 refresh phải thấy cùng phiên"
SID=$(curl -s -b "$JAR2" -X POST "$BASE/api/sessions" -H 'Content-Type: application/json' \
  -d '{"title":"Phiên test đồng bộ","model":"shark-1"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
echo "Máy 2 tạo phiên: $SID"
echo -n "Máy 1 thấy phiên: "
curl -s -b "$JAR1" "$BASE/api/sessions" | python3 -c "import sys,json;ts=[s['title'] for s in json.load(sys.stdin)];print(ts)"

step "10. LOGOUT máy 1 → máy 1 mất đăng nhập, máy 2 vẫn giữ"
curl -s -b "$JAR1" -c "$JAR1" -X POST "$BASE/api/auth/logout" > /dev/null
echo -n "Máy 1 sau logout: "; curl -s -b "$JAR1" "$BASE/api/auth/me"
echo ""
echo -n "Máy 2 vẫn đăng nhập: "; curl -s -b "$JAR2" "$BASE/api/auth/me"

step "11. DỌN DẸP: xoá phiên test + user test"
curl -s -b "$JAR2" -X DELETE "$BASE/api/sessions/$SID" > /dev/null && echo "đã xoá phiên $SID"
python3 - <<'EOF'
import sqlite3
con = sqlite3.connect('/home/z/my-project/db/custom.db')
con.execute("DELETE FROM ApiKey WHERE userId IN (SELECT id FROM User WHERE email=?)", ("lam.test.shark@gmail.com",))
con.execute("DELETE FROM ChatSession WHERE userId IN (SELECT id FROM User WHERE email=?)", ("lam.test.shark@gmail.com",))
con.execute("DELETE FROM User WHERE email=?", ("lam.test.shark@gmail.com",))
con.commit()
print("đã xoá user test:", con.total_changes, "thay đổi")
EOF
echo ""
echo "HOÀN TẤT TEST AUTH"
