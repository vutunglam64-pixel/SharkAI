#!/bin/bash
# Test chat flow với yêu cầu tạo video
curl -sN -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Tạo giúp mình 1 video ngắn 5 giây: chú mèo cam đang chạy trên bãi cỏ","model":"shark-1","mode":"normal","topic":"chung","think":"off","speed":"medium","enabledSkills":["video-gen"]}' \
  --max-time 100 > /home/z/my-project/tool-results/chat-video-test.log 2>&1
