// Debug: xem model output đầy đủ có chứa <tool> không
import ZAI from 'z-ai-web-dev-sdk';

async function main() {
  const zai = await ZAI.create();
  const msgs = [
    {
      role: 'assistant',
      content:
        'Bạn là Shark 1.0. Khi người dùng yêu cầu tạo ảnh, hãy gọi tool generate_image theo format: <tool>{"name":"generate_image","args":{"prompt":"..."}}</tool>',
    },
    { role: 'user', content: 'Tạo giúp mình 1 ảnh con mèo cam dễ thương' },
  ];
  const body = await zai.chat.completions.create({
    messages: msgs,
    stream: true,
    thinking: { type: 'disabled' },
  });
  const reader = body.getReader();
  const dec = new TextDecoder();
  let raw = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    raw += dec.decode(value, { stream: true });
  }
  // assemble content từ các delta
  let content = '';
  let thinking = '';
  for (const line of raw.split('\n')) {
    const t = line.trim();
    if (!t.startsWith('data:')) continue;
    const payload = t.slice(5).trim();
    if (!payload || payload === '[DONE]') continue;
    try {
      const j = JSON.parse(payload);
      const d = j?.choices?.[0]?.delta ?? {};
      if (d.content) content += d.content;
      if (d.reasoning_content) thinking += d.reasoning_content;
    } catch {}
  }
  console.log('=== ASSEMBLED CONTENT ===');
  console.log(content);
  console.log('=== HAS <tool>:', content.includes('<tool>'));
  console.log('=== thinking len:', thinking.length);
}

main().catch((e) => {
  console.error('FATAL:', e);
  process.exit(1);
});
