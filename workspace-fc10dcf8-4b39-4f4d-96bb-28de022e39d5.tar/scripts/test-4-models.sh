#!/bin/bash
# Test danh sách 4 model: /api/v1/models đúng thứ tự + chat completions với deepseek-r1
set -e
BASE=http://localhost:3000
JAR=/tmp/r1-test-cookies.txt
rm -f "$JAR"

echo "=== 1. Đăng nhập nhanh + tạo key ==="
curl -s -c "$JAR" -X POST $BASE/api/auth/quick -H 'Content-Type: application/json' -d '{"name":"R1 Test","email":"r1-test@shark.local"}' > /dev/null
APIKEY=$(curl -s -b "$JAR" -X POST $BASE/api/keys -H 'Content-Type: application/json' -d '{"name":"test-r1"}' | python3 -c "import sys,json; print(json.load(sys.stdin).get('key',''))")
echo "Key OK: ${APIKEY:0:18}..."

echo ""
echo "=== 2. GET /api/v1/models — phải đúng 4 model đúng thứ tự ==="
curl -s -H "Authorization: Bearer $APIKEY" $BASE/api/v1/models | python3 -c "
import sys, json
d = json.load(sys.stdin)
ids = [m['id'] for m in d['data']]
print('Số model:', len(ids))
print('Thứ tự:', ' -> '.join(ids))
expect = ['deepseek-v3', 'kimi-k2', 'shark-1', 'deepseek-r1']
print('ĐÚNG THỨ TỰ YÊU CẦU' if ids == expect else f'SAI! kỳ vọng {expect}')
"

echo ""
echo "=== 3. POST /api/v1/chat/completions model=deepseek-r1 (câu toán) ==="
curl -s -X POST $BASE/api/v1/chat/completions \
  -H "Authorization: Bearer $APIKEY" \
  -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-r1","messages":[{"role":"user","content":"Bạn là mô hình gì? Trả lời 2 câu ngắn kèm 1 điểm mạnh."}]}' | python3 -c "
import sys, json
d = json.load(sys.stdin)
if 'choices' in d:
    print('Model:', d.get('model'))
    print('Trả lời:', d['choices'][0]['message']['content'][:250])
else:
    print('ERROR:', json.dumps(d, ensure_ascii=False)[:250])
"

echo ""
echo "=== 4. Model đã xoá (mixtral-8x22b) giờ fallback về shark-1 ==="
curl -s -X POST $BASE/api/v1/chat/completions \
  -H "Authorization: Bearer $APIKEY" \
  -H 'Content-Type: application/json' \
  -d '{"model":"mixtral-8x22b","messages":[{"role":"user","content":"2+2=?"}]}' | python3 -c "
import sys, json
d = json.load(sys.stdin)
print('Model fallback:', d.get('model'), '(phải là shark-1)')
"

echo ""
echo "=== 5. Xoá key test ==="
KEYID=$(curl -s -b "$JAR" $BASE/api/keys | python3 -c "
import sys, json
d = json.load(sys.stdin)
keys = d if isinstance(d, list) else d.get('keys', d.get('data', []))
for k in keys:
    if k.get('name') == 'test-r1':
        print(k['id']); break
")
[ -n "$KEYID" ] && curl -s -b "$JAR" -X DELETE "$BASE/api/keys?id=$KEYID" | head -c 50; echo " (xoá key xong)"
