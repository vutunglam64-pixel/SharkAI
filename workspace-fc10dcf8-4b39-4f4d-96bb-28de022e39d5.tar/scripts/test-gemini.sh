#!/bin/bash
# Test Gemini integration: key endpoint, delegate event flow, PATCH finalize, public API guard
set -e
BASE=http://localhost:3000

echo "=== 1. GET /api/gemini — kiểm tra key endpoint (không in key) ==="
curl -s $BASE/api/gemini | python3 -c "
import sys, json
d = json.load(sys.stdin)
print('ok:', d.get('ok'))
print('key length:', len(d.get('key','')))
print('defaultModel:', d.get('defaultModel'))
assert d.get('ok') and len(d.get('key','')) == 53, 'KEY SAI!'
print('=> PASS')
"

echo ""
echo "=== 2. POST /api/chat với model gemini-3.8-flash — phải phát event delegate ==="
SSE=$(curl -s -N -X POST $BASE/api/chat -H 'Content-Type: application/json' \
  -d '{"sessionId":null,"message":"Chào Gemini, bạn là model gì?","model":"gemini-3.8-flash","mode":"normal","topic":"chung","think":"off","speed":"medium","groupAI":false}' --max-time 30)
echo "$SSE" | python3 -c "
import sys, json
events = []
for line in sys.stdin:
    line = line.strip()
    if not line.startswith('data:'): continue
    try: events.append(json.loads(line[5:]))
    except: pass
types = [e.get('type') for e in events]
print('Event flow:', ' -> '.join(types))
assert 'meta' in types, 'thiếu meta'
assert 'delegate' in types, 'THIẾU DELEGATE!'
d = next(e for e in events if e.get('type')=='delegate')
print('delegate.model:', d.get('model'))
print('delegate.system dài:', len(d.get('system','')), 'ký tự')
print('delegate.system KHÔNG chứa <tool>:', '<tool>' not in d.get('system',''))
print('delegate.userText:', d.get('userText'))
print('history:', len(d.get('history',[])), 'tin')
meta = next(e for e in events if e.get('type')=='meta')
print('assistantMessageId:', meta.get('assistantMessageId'))
print('sessionId:', meta.get('sessionId'))
print('title event:', next((e.get('title') for e in events if e.get('type')=='title'), None))
# lưu id để test PATCH
open('/tmp/gemini-test-ids.json','w').write(json.dumps({'sid': meta.get('sessionId'), 'aid': meta.get('assistantMessageId')}))
print('=> PASS')
"

echo ""
echo "=== 3. PATCH /api/messages/<aid> finalize — client lưu kết quả giả về DB ==="
IDS=$(cat /tmp/gemini-test-ids.json)
AID=$(echo "$IDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['aid'])")
SID=$(echo "$IDS" | python3 -c "import sys,json; print(json.load(sys.stdin)['sid'])")
curl -s -X PATCH "$BASE/api/messages/$AID" -H 'Content-Type: application/json' \
  -d '{"finalize":true,"content":"Tôi là Gemini 3.8 Flash của Google — model Flash thông minh nhất.","thinking":"Người dùng hỏi danh tính...","status":"done"}' | python3 -c "
import sys, json
d = json.load(sys.stdin)
print('ok:', d.get('ok'))
print('status:', d['message']['status'])
print('content lưu:', d['message']['content'][:60])
print('thinking lưu:', (d['message'].get('thinking') or '')[:40])
print('=> PASS')
"

echo ""
echo "=== 4. Kiểm tra nội dung đã vào DB (load lại session) ==="
curl -s "$BASE/api/sessions/$SID" | python3 -c "
import sys, json
d = json.load(sys.stdin)
msgs = d.get('messages', [])
print('Số tin:', len(msgs))
for m in msgs:
    print(f\"  [{m['role']}] status={m.get('status')} model={m.get('model')} :: {m['content'][:50]}\")
print('title:', d.get('title'))
"

echo ""
echo "=== 5. GET /api/v1/models — phải có 5 model, gemini đứng cuối ==="
JAR=/tmp/gem-test-cookies.txt
rm -f "$JAR"
curl -s -c "$JAR" -X POST $BASE/api/auth/quick -H 'Content-Type: application/json' -d '{"name":"Gem Test","email":"gem-test@shark.local"}' > /dev/null
APIKEY=$(curl -s -b "$JAR" -X POST $BASE/api/keys -H 'Content-Type: application/json' -d '{"name":"test-gem"}' | python3 -c "import sys,json; print(json.load(sys.stdin).get('key',''))")
curl -s -H "Authorization: Bearer $APIKEY" $BASE/api/v1/models | python3 -c "
import sys, json
d = json.load(sys.stdin)
ids = [m['id'] for m in d['data']]
print('Số model:', len(ids), '|', ' -> '.join(ids))
assert 'gemini-3.8-flash' in ids, 'thiếu gemini!'
print('=> PASS')
"

echo ""
echo "=== 6. POST /api/v1/chat/completions model=gemini-3.8-flash → phải 400 rõ ràng ==="
curl -s -X POST $BASE/api/v1/chat/completions \
  -H "Authorization: Bearer $APIKEY" -H 'Content-Type: application/json' \
  -d '{"model":"gemini-3.8-flash","messages":[{"role":"user","content":"hi"}]}' | python3 -c "
import sys, json
d = json.load(sys.stdin)
print('error.code:', d.get('error',{}).get('code'))
print('message:', d.get('error',{}).get('message','')[:120])
print('=> PASS')
"

echo ""
echo "=== 7. Hồi quy: model thường (shark-1) vẫn stream bình thường (không delegate) ==="
curl -s -N -X POST $BASE/api/chat -H 'Content-Type: application/json' \
  -d '{"sessionId":null,"message":"2+2=?","model":"shark-1","mode":"normal","topic":"chung","think":"off","speed":"fast","groupAI":false}' --max-time 60 | grep -c "delegate" || echo "0 delegate — ĐÚNG (không có delegate)"
