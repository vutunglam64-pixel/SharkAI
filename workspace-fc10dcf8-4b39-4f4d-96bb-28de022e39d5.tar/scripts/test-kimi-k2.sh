#!/bin/bash
# Test Kimi K2 Instruct integration: /api/v1/models + /api/v1/chat/completions + /api/chat persona
set -e
BASE=http://localhost:3000
JAR=/tmp/kimi-test-cookies.txt
rm -f "$JAR"

echo "=== 1. Đăng nhập nhanh ==="
LOGIN=$(curl -s -c "$JAR" -X POST $BASE/api/auth/quick -H 'Content-Type: application/json' -d '{"name":"Kimi Test","email":"kimi-test@shark.local"}')
echo "$LOGIN" | head -c 200; echo

echo ""
echo "=== 2. Tạo API key ==="
KEYRES=$(curl -s -b "$JAR" -X POST $BASE/api/keys -H 'Content-Type: application/json' -d '{"name":"test-kimi-k2"}')
APIKEY=$(echo "$KEYRES" | python3 -c "import sys,json; print(json.load(sys.stdin).get('key',''))" 2>/dev/null || true)
echo "Key: ${APIKEY:0:20}..."

echo ""
echo "=== 3. GET /api/v1/models — tìm Kimi K2 ==="
curl -s -H "Authorization: Bearer $APIKEY" $BASE/api/v1/models | python3 -c "
import sys, json
d = json.load(sys.stdin)
models = d['data']
print(f'Tổng số model: {len(models)}')
for m in models:
    star = ' <== KIMI K2' if 'kimi' in m['id'] else ''
    print(f\"  - {m['id']}: {m.get('shark',{}).get('name','?')} | {m.get('shark',{}).get('params','?')}{star}\")
"

echo ""
echo "=== 4. POST /api/v1/chat/completions với model kimi-k2 ==="
curl -s -X POST $BASE/api/v1/chat/completions \
  -H "Authorization: Bearer $APIKEY" \
  -H 'Content-Type: application/json' \
  -d '{"model":"kimi-k2","messages":[{"role":"user","content":"Chào bạn, bạn là mô hình gì? Trả lời 2 câu ngắn."}]}' | python3 -c "
import sys, json
d = json.load(sys.stdin)
if 'choices' in d:
    print('Model trả về:', d.get('model'))
    print('Nội dung:', d['choices'][0]['message']['content'][:300])
else:
    print('ERROR:', json.dumps(d, ensure_ascii=False)[:300])
"

echo ""
echo "=== 5. Xoá key test + kiểm tra cleanup ==="
KEYID=$(curl -s -b "$JAR" $BASE/api/keys | python3 -c "
import sys, json
d = json.load(sys.stdin)
keys = d if isinstance(d, list) else d.get('keys', d.get('data', []))
for k in keys:
    if k.get('name') == 'test-kimi-k2':
        print(k['id']); break
")
if [ -n "$KEYID" ]; then
  curl -s -b "$JAR" -X DELETE "$BASE/api/keys?id=$KEYID" | head -c 100; echo " (đã xoá key test)"
fi
