import { extractToolCall } from '../src/lib/tools';
const raw2 = '<tool>\n<write_file>\n<path>hello-shark.html</path>\ncontent><!DOCTYPE html>\n<html lang=\\"vi\\">\n<head>\n    <title>Hello Shark</title>\n</head>\n<body>\n    <h1>Shark đây</h1>\n</body>\n</html>\n</content>\n</write_file>';
const { tool, textBefore } = extractToolCall(raw2);
console.log('tool:', tool?.name, '| path:', tool?.args?.path, '| contentLen:', String(tool?.args?.content||'').length);
console.log('content head:', JSON.stringify(String(tool?.args?.content||'').slice(0,60)));
if (tool?.name === 'write_file' && tool.args.path === 'hello-shark.html' && String(tool.args.content||'').includes('<h1>Shark đây</h1>') && String(tool.args.content||'').includes('"vi"')) {
  console.log('PASS: format lỗi thật 2');
} else {
  console.log('FAIL'); process.exit(1);
}
