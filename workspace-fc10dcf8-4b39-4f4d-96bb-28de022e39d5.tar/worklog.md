# Worklog

---
Task ID: 1
Agent: Main agent (Z.ai)
Task: Xây dựng "Nova AI" — trợ lý AI đa năng web app với UI/UX mô phỏng vico.kiyo.vn, dùng mixture-of-experts mã nguồn mở, tích hợp đầy đủ tính năng Claude (think mode, agent, terminal, tạo ảnh/video, skills, xuất file, đăng web)

Work Log:
- Khảo sát vico.kiyo.vn (WebFetch) để nắm cấu trúc UI: sidebar, welcome cards, model selector, chế độ làm việc, chủ đề, tốc độ, khung nhập
- Load skill fullstack-dev, khởi tạo môi trường (init-fullstack.sh)
- Load 6 skill AI: LLM, VLM, image-generation, TTS, ASR, video-understand để nắm SDK z-ai-web-dev-sdk
- Thiết kế Prisma schema: ChatSession, Message, Project, PublishedSite → db push
- Viết lib: config.ts (7 model MoE + topics + skills + modes + personas), prompts.ts (system prompt builder + suy nghĩ qua thẻ <suy>), tools.ts (executor + parser tool call 3 dạng: JSON chuẩn / tên+JSON / XML), stream.ts (SSE parser), sse.ts, workspace.ts, zai.ts
- Viết 15 API routes: chat (SSE streaming đa chế độ: normal/best/research/ultra/agent/groupAI, vision multimodal, tool interception), sessions, projects, upload, image (generate/search/edit), video (tạo + poll), tts, asr, terminal (blocklist an toàn), workspace (CRUD file), zip (JSZip), publish + sites, preview/[...path], asset/[...path]
- Viết store Zustand: SSE client, video polling, credit system (localStorage), skills persistence
- Viết UI: Sidebar (phiên chat mới/Group AI/Desktop/Dự án/Lịch sử/credit card/theme), Header (model selector MoE), Welcome (7 suggestion cards), Markdown + CodeBlock (copy/download/lưu/xem trước/đăng web), Messages (thinking block kiểu ChatGPT, tool event cards, sources, reflection), ChatInput (5 dropdowns + mic ASR ghi WAV 16k + drag-drop), RightPanel (Thư mục + file editor + Terminal + Xem trước iframe), Modals (Dự án/Group AI/Skills/Desktop/Publish)
- Debug quan trọng: (1) backend GLM strip thẻ <think> → đổi sang thẻ <suy> custom; (2) safePrefixLength khớp chuỗi rỗng → không giữ được tiền tố tag → sửa vòng lặp; (3) model viết tool call XML thay JSON → thêm XML parser; (4) suy nghĩ leak vào agent content → stripSuy + emit thinking events; (5) trùng tên CreditCard lucide vs component
- Kiểm thử bằng agent-browser: chat streaming ✓, history + titles ✓, thinking block ✓, agent tạo file Python + chạy terminal ✓, agent tạo website qua UI ✓, files panel + editor ✓, preview iframe ✓, publish lên web (link công khai) ✓, terminal panel chạy lệnh thật ✓, Deep Research 4 phases + 6 nguồn ✓, image gen ✓, TTS 97KB wav ✓, upload ✓, dark/light mode ✓, credit trừ đúng theo mode ✓
- Lint sạch (0 error), dev.log không có lỗi runtime

Stage Summary:
- Ứng dụng Nova AI hoàn chỉnh chạy tại / (Next.js 16 + TS + Tailwind 4 + shadcn/ui + Prisma SQLite)
- Đủ tính năng yêu cầu: UI/UX theo vico.kiyo.vn, 7 model MoE mã nguồn mở, think dropdown 4 mức, 5 chế độ làm việc (thường/tốt nhất/research/ultra/agent), 8 chủ đề, 3 tốc độ, 16 skills, Group AI 3 persona, agent + terminal thật, thư mục file + editor + ZIP, preview HTML/CSS/JS, xuất ZIP/HTML/tải file, đăng web công khai, upload ảnh/video/file phân tích (VLM/file_url), tạo ảnh + video AI, TTS/ASR, credit system, dark/light
- File chính: src/app/api/chat/route.ts (pipeline chính), src/lib/tools.ts (tool executor), src/components/app/* (9 component), src/store/app-store.ts

---
Task ID: 2
Agent: Main agent (Z.ai)
Task: Sửa toàn bộ lỗi người dùng báo cáo + thêm tính năng: tạo Skill tùy chỉnh như Claude, quản lý Web đã đăng, bỏ credit (free 100%), đổi thương hiệu Nova → Shark (model Shark 1.0)

Work Log:
- Phát hiện /api/upload route BỊ THIẾU hoàn toàn (frontend gọi 404) → viết mới route upload (multipart → saveUploadFile, phân loại image/video/text/document, giới hạn 20MB)
- Sửa preview route: thiếu import `path` (lỗi 500 khi ?download=1), thêm guard đường dẫn
- Prisma: thêm model UserSkill + default model → shark-1, db push + generate (phải restart server vì module Prisma cũ trong RAM)
- Viết API /api/skills (GET/POST/DELETE) cho skill tùy chỉnh; thêm DELETE cho /api/sites/[id]
- Chat route: nạp custom skills đang bật từ DB (id dạng custom:<cuid>) inject vào system prompt; nạp ngữ cảnh dự án (project name/goal) nếu phiên thuộc dự án; default model shark-1
- prompts.ts: AGENT_PROMPT cứng hoá (cấm "nói suông", bắt buộc gọi tool lượt đầu); buildSystemPrompt thêm khối SKILL TÙY CHỈNH
- Agent loop: thêm nudge logic (tối đa 3 lần) khi model không gọi tool / gọi sai format; strip khối <tool> rác khỏi text hiển thị cuối
- tools.ts extractToolCall mở rộng: (1) repair JSON có newline thô trong chuỗi, (2) chấp nhận <tool> KHÔNG ĐÓNG </tool>, (3) pseudo-XML content="..." attribute, (4) thẻ content> thiếu dấu <, (5) unescape \" \\n kiểu JSON, (6) 4b thiếu content → nhường 4c; executeTool write_file: tìm content ở key phụ (text/html/code/body...), cấm ghi file rỗng (soft-fail báo model gửi lại), cleanWsPath bỏ prefix /workspace/
- UI: viết lại sidebar (FreeCard "Miễn phí 100%" thay CreditCard, nút "Web đã đăng" + badge số lượng), modals (SkillsModal có form tạo/xoá skill tùy chỉnh, SitesModal quản lý trang đã đăng với xem/copy/mở/xoá), nút "Quản lý & tạo skill mới" trong dropdown Skills input, auto-open preview khi agent tạo file .html, nút Xem trước trong file event block
- Bỏ credit hoàn toàn: xoá getCredit/spendCredit/CREDIT_RULES/credit fields, migrate dọn key localStorage cũ
- Rebrand Nova → Shark: logo vây cá mập + sóng, model Shark 1.0, tên app Shark, metadata, placeholder, tất cả text UI, zip filename, event names (shark-fill-input...), localStorage shark-skills (migrate từ nova-skills)
- Store: thêm sites/customSkills/refreshSites/refreshCustomSkills/deleteSite; khôi phục enabledSkills từ localStorage sau reload (trước đây KHÔNG có loader — bug); auto-preview write_file .html
- Debug môi trường: process nền bị kill giữa các Bash call → dùng double-fork `( cmd & )` để server sống sót; .next hỏng cache Turbopack → xoá sạch khi server tắt
- Test parser tool-call: viết scripts/test-tool-parse.ts + test2.ts — 8/8 PASS (kể cả 2 format lỗi thật thu được từ log model)
- Kiểm thử browser (agent-browser): chat normal SSE ✓, agent tạo file HTML 1031 bytes + preview TỰ ĐỘNG MỞ ✓, tool block render ✓, publish "Lên web" → URL công khai phục vụ HTML ✓, badge "Web đã đăng 4" ✓, SitesModal ✓, tạo skill "Chuyên gia Excel" qua UI ✓, skill inject vào chat (model trả lời đúng phong cách) ✓, card gợi ý điền input ✓, dark mode ✓, upload API ✓, preview download ✓, terminal ✓, 0 console errors, lint 0 error

Stage Summary:
- Ứng dụng Shark (trước là Nova AI) chạy hoàn chỉnh tại / với mọi lỗi đã sửa: upload, preview, publish, tạo file qua agent
- Mới: tạo Skill tùy chỉnh như Claude (DB + UI + inject prompt), trang quản lý Web đã đăng, auto-preview, miễn phí 100% không credit
- Parser tool-call chịu lỗi 8+ biến thể format của model (JSON chuẩn/sửa lỗi/XML/pseudo-XML/attribute/không đóng thẻ)

---

Task ID: 3
Agent: Main agent (Z.ai)
Task: Nâng cấp Shark theo yêu cầu mới: chạy nền khi thoát chat, người tạo vutunglam08, effort suy nghĩ kéo như GLM, xoá/đổi tên phiên (mobile+PC), sửa/sao chép tin nhắn kiểu DeepSeek, xem code+tải+sao chép file Shark tạo (toml...), trang Điều khoản & Dịch vụ, đăng nhập Google/nhanh đồng bộ chat mọi thiết bị

Work Log:
- Prisma: thêm model User (email/name/image/googleId), ChatSession.userId, Message.status (running/done/stopped/error) → db push + generate
- Auth tự viết (src/lib/auth.ts): cookie shark_session ký HMAC-SHA256 (AUTH_SECRET trong .env), verify/hạ tầng cookie, loginOrRegister nhận (claim) mọi phiên ẩn danh vào tài khoản khi đăng nhập
- Routes auth: GET /api/auth/me (user + googleConfigured), GET /api/auth/google (redirect OAuth, redirect_uri suy từ x-forwarded-host), GET /api/auth/google/callback (đổi code→token→userinfo→upsert user→cookie), POST /api/auth/quick (email+tên khi chưa có Google creds), POST /api/auth/logout
- Chạy nền: chat route tạo dòng assistant status='running' TRƯỚC khi generate, lưu tiến trình tăng dần mỗi 2.5s (content/thinking/events), bỏ mọi `writer.closed break` (client ngắt vẫn chạy tiếp), streamToClient thêm opts.stop → dừng tức thì khi huỷ; registry huỷ src/lib/runner.ts dùng chung cho /api/chat (body.cancelSessionId) và sessions DELETE
- Chat route: body.reuseUserMessageId (sửa/tạo lại không tạo dòng user mới), meta event gửi assistantMessageId (client đổi id tạm→id thật), session mới gắn userId, history loại trừ dòng status running
- API /api/messages/[id]: PATCH (sửa nội dung user msg + xoá mọi tin sau) & DELETE (xoá msg + mọi tin sau) cho edit/regenerate
- /api/sessions: GET lọc theo user đăng nhập (userId null nếu ẩn danh) + tính cờ running qua messages where status running; POST gắn userId; DELETE gọi cancelSession
- prompts.ts: khối DANH TÍNH "Bạn được tạo ra bởi vutunglam08"; AGENT_PROMPT nêu rõ write_file hỗ trợ MỌI loại tệp (.toml/.ini/.cfg/.env...)
- Store: mapDbMessages (status/streaming), pollers Map poll 2s phiên đang chạy (cập nhật messages + streaming + tự dừng khi xong), loadSession phát hiện running/tin cuối là user → startPolling, send(opts.reuseUserMessageId) không thêm bubble user khi sửa/tạo lại, meta đổi id tạm, stop() gọi cancelSessionId từ xa, editMessage/regenerate (PATCH/DELETE + gửi lại), user/googleConfigured/refreshUser/loginQuick/logoutUser
- Sidebar: SessionItem thay hover-only bằng menu "..." DropdownMenu (Ghim/Đổi tên/Xoá — dùng được touch mobile lẫn chuột PC), badge "chạy nền" + Loader2 khi phiên đang chạy, AccountCard (đăng nhập/đăng xuất, avatar chữ), link "Điều khoản & Dịch vụ", mở modal login khi redirect ?login=quick|error
- Messages: UserActions kiểu DeepSeek (Sao chép + Sửa inline textarea → Huỷ/Gửi lại), AssistantActions regenerate đúng theo msg.id, ToolEventBlock nhánh file → thẻ tệp nút bấm: "Đã tạo tệp <tên>" + Xem code / Tải về (/api/preview?download=1) / Sao chép (đọc workspace→clipboard) + Xem trước (html); FileCodeDialog (useEffect fetch /api/workspace read, SyntaxHighlighter EXT_LANG mở rộng toml/ini/csv/env/dockerfile..., nút Sao chép + Tải về); badge "Chạy nền" khi msg.status=running
- Input: thay dropdown Suy nghĩ bằng Popover + Slider Radix 4 mức (Tắt/Tự động/Suy nghĩ/Sâu hơn) kéo như effort GLM + nhãn mô tả; footer link /terms + /terms#quyen-rieng-tu
- Trang /terms: 6 mục (Điều khoản sử dụng, Điều khoản dịch vụ, Quyền riêng tư, Tài khoản & đồng bộ, Chế độ chạy nền, Liên hệ & ghi nhận vutunglam08), mục lục anchor, nút "Về Shark"
- Modals: LoginModal (nút Google SVG khi đã cấu hình OAuth, form tài khoản nhanh email+tên, giải thích đồng bộ)
- .env: thêm AUTH_SECRET random + placeholder GOOGLE_CLIENT_ID/SECRET (comment)
- Kiểm thử curl: auth me/quick/cookie ✓, claim 24 phiên ✓, chạy nền (client ngắt sau 2s → content vẫn lưu đủ) ✓, huỷ research → status stopped ✓, PATCH sửa + reuse (2 tin sau gửi lại) ✓, DELETE + regenerate ✓, câu "Ai tạo ra em?" → "Tôi được tạo ra bởi vutunglam08" ✓
- Kiểm thử browser: thanh trượt effort ✓, menu "..." ghim/đổi tên/xoá (desktop + iPhone 14 viewport) ✓, sửa tin nhắn user → tạo lại HTML mới ✓, Agent tạo Cargo.toml → thẻ file + dialog hiện TOML ([package] hello-shark serde) ✓, đăng nhập nhanh → AccountCard ✓, research chạy nền → badge "chạy nền" sidebar → quay lại poll live tới khi xong ✓, 0 console error
- Dọn dữ liệu test: scripts/cleanup-test-data.cjs xoá 6 phiên automation tạo, trả 24 phiên thật về ẩn danh, khôi phục tên phiên "Tạo trang web HTML" + nội dung "Tạo html", xoá 2 user test (lưu ý: 1 phiên chat test cũ "Giới thiệu AI Nova MoE" bị xoá nhầm do trùng marker — nội dung QA cũ, không phải dữ liệu quan trọng)
- eslint ignore scripts/**; lint 0 error; tsc các lỗi còn lại đều có sẵn từ template (examples/skills/kiểu zai) không liên quan thay đổi mới

Stage Summary:
- Shark giờ chạy nền thật sự: thoát chat/tắt tab vẫn xử lý xong, có badge + poll khi quay lại, huỷ được từ xa
- Đủ tính năng mới: người tạo vutunglam08, effort slider GLM, quản lý phiên kiểu Claude (mobile+PC), sửa/sao chép tin nhắn kiểu DeepSeek, thẻ file xem code/tải/sao chép mọi định dạng, trang /terms, đăng nhập Google (sẵn sàng khi điền env) + tài khoản nhanh đồng bộ mọi thiết bị

---
Task ID: 4
Agent: Main agent (Z.ai)
Task: Đăng web ĐA TỆP (nhiều file thành 1 trang, nút dưới Xuất ZIP) + xem trước đa tệp (html+css+js ghép chung), sửa lỗi đổi tên đoạn chat cũ, file code hiện live không cần tải lại, suy nghĩ AI xuất hiện TRƯỚC câu trả lời như DeepSeek

Work Log:
- Prisma: PublishedSite thêm cột `files` (JSON map path→{c: base64, bin}) + `html` default "" → db push + generate + restart dev server (Prisma client mới)
- POST /api/publish 3 chế độ: {multi:true} thu thập cả thư mục workspace (max 200 tệp, mỗi tệp ≤2MB, base64) → tìm entry index.html/*.html → trả url /api/sites/<id>/; giữ chế độ {path} và {html} cũ. GET trả thêm multi + fileCount
- GET /api/sites/[id]: site đa tệp → xuất entry HTML có inject <base href="/api/sites/<id>/"> (link tương đối css/js/ảnh tự trỏ đúng); site cũ giữ nguyên
- NEW GET /api/sites/[id]/[...path]: phục vụ mọi tệp thành phần (css/js/ảnh/font) đúng MIME từ JSON
- NEW GET /api/preview-bundle?path=: xem trước ĐA TỆP — inline <link stylesheet> → <style>, <script src> → inline (escape </script>), ảnh/video/font → data URL, url(...) trong CSS → data URL, <a href="*.html"> → link bundle khác; max 40 tệp inline
- chat route streamToClient: FIX NGUYÊN NHÂN — delta.thinking (reasoning_content) trước đây BỊ BỎ QUA hoàn toàn → giờ stream event 'thinking' NGAY (xuất hiện trước câu trả lời như DeepSeek) + collect vào fullThinking; agent mode cũng capture message.reasoning_content + <suy> cũ
- messages.tsx ThinkingBlock: live = đang streaming (mở suốt quá trình, nhãn Đang suy nghĩ.../Suy nghĩ/Đã suy nghĩ tùy trạng thái có answer chưa) — render TRƯỚC events & content
- tools.ts: thêm TOOL_ALIASES chuẩn hoá tên model hay viết sai (writeFile/save_file/shell/ls/search... → write_file/run_terminal/list_files/web_search...) → chống "lỗi tạo file"
- store: bumpFiles khi loadSession, mỗi tick poll phiên chạy nền, và khi send() xong → cây thư mục + file mới hiện LIÊN TỤC không cần tải lại; auto-preview write_file .html chuyển sang bundle URL
- panel.tsx FilesTab: nút "Đăng cả thư mục lên web (N tệp)" NGAY DƯỚI nút Xuất ZIP (prompt tên site → POST multi → copy link + tự mở preview); nút mắt editor → bundle URL; PreviewTab: publish nhận diện srcdoc/bundle/preview/site URL
- modals SitesModal: nhãn "đa tệp · N" cho site đa tệp, link/sao chép dùng /api/sites/<id>/
- sidebar SessionItem: bỏ side="right" (menu tràn màn hình mobile) → align="end" tự flip; đổi tên commit khi Enter HOẶC blur (bàn phím mobile), nút ✓ dùng onMouseDown preventDefault tránh double-commit
- Kiểm thử curl: PATCH đổi tên ✓ (từ đầu vẫn chạy được — lỗi là UI mobile), publish multi (8 tệp) → base tag ✓ + style.css/app.js HTTP 200 ✓
- Kiểm thử browser (desktop + iPhone 14 viewport): đổi tên phiên ✓ PC lẫn mobile (menu trong viewport 70-246/390px, blur commit ✓), sửa tin nhắn cũ → agent tạo lại index.html + thẻ file + auto-preview mở ✓, bundle preview: style.css inlined (h1 #D97757) + app.js chạy trong iframe ✓, nút đăng thư mục → toast "Đã đăng 9 tệp" + iframe /api/sites/<id>/ ✓, suy nghĩ: agent mode + normal mode — ThinkingBlock TRƯỚC câu trả lời (DOM top nhỏ hơn), nội dung suy luận thật 658-1014 ký tự lưu DB ✓, 0 console error, 0 dev.log error, lint 0 lỗi
- Dọn test: xoá phiên "Bài toán bơm nước", khôi phục tên "Tạo trang web HTML" cho phiên test cũ (lưu ý: 2 tin nhắn QA Cargo.toml cuối phiên này bị PATCH test thay mất — nội dung QA cũ), xoá 2 site test + 3 file test (giữ index.html do agent session thật tạo)

Stage Summary:
- Đăng web đa tệp hoàn chỉnh: 1 nút dưới Xuất ZIP đưa TOÀN BỘ thư mục (index.html + style.css + app.js + ảnh) lên 1 URL công khai, base-tag + route catch-all phục vụ từng tệp
- Xem trước đa tệp: bundle tự ghép html+css+js+ảnh thành 1 bản hoàn chỉnh chạy được trong iframe, cả auto-preview khi agent tạo file
- Suy nghĩ của AI giờ xuất hiện TRƯỚC câu trả lời (fix reasoning_content bị bỏ qua trước đó) — giống DeepSeek ở mọi chế độ
- Đổi tên phiên hoạt động cả mobile (menu không tràn, commit bằng blur); file code/cây thư mục cập nhật live khi đang ở trong web — không cần tải lại

---
Task ID: 5
Agent: Main agent (Z.ai)
Task: Sửa lỗi "không tạo được ảnh AI và video AI qua chat" + lỗi trên ảnh chụp (Sửa tin nhắn → Gửi lại không hoạt động)

Work Log:
- Chẩn đoán: test /api/image + /api/video trực tiếp → đều OK (SDK tạo ảnh 1024px, video task done URL mp4 hợp lệ) → lỗi nằm ở LUỒNG CHAT
- Test chat yêu cầu tạo ảnh → stream chỉ có meta → title → done, CONTENT RỖNG, không tool_result; DB assistant message content ""
- Test SDK stream trực tiếp (scripts/test-sdk-stream.mjs, test-sdk-assemble.mjs) → model CÓ gọi <tool>{"name":"generate_image","args":{...}}</tool> đúng chuẩn
- Tìm ra NGUYÊN NHÂN 1: streamToClient trong /api/chat — khi gặp <tool> trong stream, code đặt toolFound=true và VỨT TOÀN BỘ nội dung sau đó (JSON tool call) khỏi buf; cuối stream gọi extractToolCall(fullText) trên chuỗi ĐÃ VỨT tool → tool không bao giờ được tìm thấy → generate_image/generate_video không bao giờ thực thi → không có ảnh/video
- Tìm ra NGUYÊN NHÂN 2 (lỗi trên ảnh chụp): store send() tạo tin user với id tạm tmp-u-...; meta event từ server có gửi userMessageId thật nhưng handler CHỈ map id assistant, BỎ QUA id user → editMessage() PATCH /api/messages/tmp-u-... → 404 (có trong dev.log 17:35 trùng thời điểm ảnh chụp) → bấm "Gửi lại" không làm gì cả
- FIX 1 (route.ts): viết lại streamToClient — thêm biến rawAll tích lũy TOÀN BỘ delta.content bản gốc (kể cả <tool> JSON); state machine inTool ẩn <tool>...</tool> khỏi hiển thị nhưng text sau </tool> vẫn hiển thị trở lại (model hay viết câu chốt sau tool); cuối stream extractToolCall(rawAll) thay vì fullText; script scripts/fix-streamtoclient.py thay hàm theo số dòng
- FIX 2 (store.ts): track tempUserId trong send(); meta handler map thêm userMessageId → m.id === tempUserId thay bằng id thật DB
- FIX phụ (tools.ts): generateImage/editImage phát hiện magic bytes JPEG (FF D8) → lưu đuôi .jpg đúng định dạng thực (trước đây API trả JPEG nhưng lưu .png)
- Kiểm thử curl end-to-end: chat tạo ảnh → tool_result generate_image + URL /api/asset/... (ảnh 1024x1024 hợp lệ) ✓; chat tạo video → tool_result generate_video + taskId, poll → done + URL video/mp4 (HTTP 206) ✓; PATCH message id thật → 200 + xoá tin sau ✓; reuseUserMessageId gửi lại → ảnh mới đúng nội dung sửa (mèo XÁM) ✓
- Kiểm thử browser (agent-browser): gõ "Tạo cho mình một bức ảnh con robot dễ thương" → ảnh robot render trong chat + nút Tải ảnh ✓; bấm Sửa tin nhắn → sửa text thành "con chó corgi đáng yêu" → Gửi lại → PATCH 200 (id thật, không còn 404) → ảnh CORGI mới render ✓; 0 console errors
- Dọn test: xoá 4 phiên test (Mèo cam x2, Chú mèo cam chạy giỡn, Robot dễ thương) + 3 ảnh test mồ côi trong upload/; giữ nguyên 25 phiên thật của user
- Lint 3 file sửa: 0 lỗi; dev.log: 0 error

Stage Summary:
- Tạo ảnh AI + tạo video AI qua chat giờ HOẠT ĐỘNG (trước đây tool call bị stream state machine vứt bỏ — lỗi thiết kế nghiêm trọng khiến MỌI tool trong chế độ thường/research/vision không chạy)
- Sửa tin nhắn + "Gửi lại" (lỗi trong ảnh chụp) đã fix — client giờ dùng id thật từ meta event
- Ảnh AI lưu đúng định dạng (jpg/png theo magic bytes)

---
Task ID: 6
Agent: Main agent (Z.ai)
Task: Đợt 5 — UI nền TRẮNG kiểu vico + animation mượt; Group AI thành TRANG RIÊNG (bật sang trang group, tắt về bình thường); đội 8 AI agent (Sếp, Agent, Slide, Code, Terminal, Kiểm tra, Kiểm thử, Kết quả) cùng hỗ trợ làm việc; ảnh đại diện mới chữ S phát sáng cho Shark AI

Work Log:
- globals.css: đổi nền trắng sữa #faf9f5 (kiểu Claude) → TRẮNG TINH #ffffff kiểu vico; secondary/muted/accent/sidebar/border chuyển sang xám trung tính (#f5f5f6/#f4f4f5/#f2f2f4/#f9f9fa/#e9e9ec); giữ primary #D97757; dark mode giữ nguyên
- Thư viện animation mượt (globals.css): keyframes rise-in/pop-in/slide-in-left/right/fade-in/shimmer/glow-pulse/float-y/ring-spin/progress-slide/sheen + class .anim-rise .anim-pop .anim-left .anim-right .anim-fade-in .anim-d1..d8 .hover-lift (lò xo translateY -3px + shadow) .press (bóp 0.955 khi bấm) .logo-glow .float-y .shimmer .speaking-ring (vòng quay quanh avatar đang nói) .progress-sheen (vệt sáng chạy ngang) .sheen-host (quét sáng nút) .stagger (bậc thang 8 con) .text-gradient; tôn trọng prefers-reduced-motion
- Ảnh đại diện mới: user cung cấp ảnh chữ S phát sáng → nén 1254px→512px PNG (242KB) lưu public/shark-avatar.png; SharkLogo component thay SVG vây cá mập bằng <img> (tự cập nhật khắp app: sidebar/header/welcome/messages/group); favicon layout.tsx → /shark-avatar.png
- config.ts: PERSONAS 3 → 8 chuyên gia: boss Sếp #D97757, agent Đa nhiệm #5B8DB8 (tool), slide #9A8FB8, code Lập trình viên #7D9B76 (tool), terminal #C9A227 (tool), check Kiểm tra #B87A6B, test Kiểm thử #3E9B8F, result Kết quả #D94F70; thêm getPersona() + trường tools/always
- prompts.ts: buildWorkerPrompt (persona 8-agent + cú pháp tool khi canUseTools), buildBossPlanPrompt (Sếp chọn 1-4 chuyên gia trả JSON {agents, plan}), buildPersonaPrompt cũ giữ tương thích
- api/chat route.ts: VIẾT LẠI nhánh Group AI thành orchestration: (1) Sếp gọi model chọn đội từ 6 worker + viết kế hoạch (fallback từ khoá: web→code+terminal+check+test; slide→slide; kiểm thử→check+test; ngược lại agent); (2) từng chuyên gia làm việc — worker có tool (code/terminal/agent) được 1-2 vòng gọi tool thật (write_file/run_terminal/web_search...) qua extractToolCall + executeTool + streamToClient vòng 2, worker nội dung stream thẳng; (3) result agent luôn tổng hợp báo cáo cuối; mỗi persona 1 dòng DB riêng (model persona:<id>, events có icon) — chạy nền vẫn phục vụ đủ khi reload
- store: setGroupAI(v) giờ là ĐIỀU HƯỚNG TRANG (bật sang trang Group, tắt về chat thường; phiên khác loại có nội dung → tự mở phiên trống); thêm activePersonaId (set khi persona event, xoá khi persona_done/finally); persona event thêm icon; startPersona lưu icon vào events
- group-page.tsx (MỚI): trang Group AI riêng — header (logo S + badge "8 chuyên gia" + switch "Tắt để về chat thường" + progress-sheen bar khi streaming), roster trái 8 thẻ (desktop, avatar tròn màu + ring quay "đang nói…" + badge tool, vào bậc thang .stagger), dải avatar cuộn ngang mobile, màn hình chào "Giao việc cho Team SKU" + lưới 8 agent + 4 chip gợi ý nhiệm vụ, message persona dùng MessageBubble; ẩn dòng assistant nháp trống; speakingId dự phòng qua SSE hoặc tin nhắn streaming (poll nền)
- persona.tsx (MỚI, tách chống import vòng): PERSONA_ICONS (crown/bot/presentation/code/terminal/search-check/flask/clipboard-check + compass/shield cũ) + PersonaAvatar
- page.tsx: groupAI ? <GroupPage/> : chat thường — chuyển trang mượt anim-fade-in
- sidebar: nút Group AI giờ BẮM SANG TRANG (đổi từ openModal), active state cam + badge "8", phiên group có icon Users; stagger nhẹ toàn sidebar; nút bấm có press/translate
- input: chip Group AI cập nhật "8 chuyên gia", text "Bật → sang trang group · Tắt → về chat thường"; nút Gửi/Dừng có press + sheen-host
- messages: nhãn persona thành avatar tròn màu + icon + tên màu + role chip + "đang viết…" + speaking-ring khi stream (kèm cả persona cũ không icon vẫn fallback Bot)
- modals: GroupAIModal mới lưới 2 cột 8 chuyên gia hover-lift + switch điều hướng trang
- welcome: logo S float-y + logo-glow + pop-in, tiêu đề text-gradient, 7 card vào bậc thang anim-d1..d8 + hover-lift + icon scale/rotate khi hover
- Kiểm thử agent-browser end-to-end: nền = rgb(255,255,255) ✓; avatar /shark-avatar.png hiện 3 chỗ ✓; bấm Group AI → TRANG GROUP "Giao việc cho Team Shark" ✓; 8 agent hiện đủ ✓; gửi "Team làm giúp mình một trang web tính điểm bàn cầu lông" → SẾP giao "Slide thiết kế giao diện, Code phát triển, Test kiểm tra" → SLIDE dàn ý 4 trang → LẬP TRÌNH VIÊN tạo THẬT index.html + styles.css (thẻ file Xem code/Tải/Sao chép/Xem trước) → KIỂM THỬ kịch bản → KẾT QUẢ tổng hợp báo cáo đầy đủ ✓; ring "đang nói…" đúng agent ✓; roster ring hoạt động khi poll nền (speakingId dự phòng) ✓; tắt switch → VỀ TRANG THƯỜNG ✓; mở lại phiên group từ lịch sử → tự sang trang group với đủ Sếp/Slide/Kết quả/thẻ file ✓; mobile 390px roster dải ngang ✓; regression chat thường "2+2" trả lời đúng ✓; 0 console errors, 0 dev.log error, lint 0 lỗi
- Dọn dẹp: xoá phiên test "Câu hỏi toán đơn giản" (2+2); GIỮ phiên group "Tính Điểm Cầu Lông" làm demo đội AI cho user; lưu ý: index.html trong workspace bị phiên group demo ghi đè (file cũ là sản phẩm QA phiên test cũ, không phải dữ liệu user thật)

Stage Summary:
- UI Shark giờ nền TRẮNG như vico (không còn trắng sữa Claude) + hệ animation mượt toàn app
- Group AI là TRANG RIÊNG: bật → sang trang group với đội hình 8 agent, tắt → về chat thường (nút sidebar, chip input, switch header đều điều hướng)
- Đội 8 AI agent hoạt động thật: Sếp tự chọn chuyên gia theo nhiệm vụ, Code/Terminal/Agent chạy TOOL THẬT (tạo file/chạy lệnh), Kết quả luôn tổng hợp cuối; mỗi thành viên 1 bubble avatar màu riêng, có ring "đang nói…"
- Ảnh đại diện mới chữ S phát sáng áp dụng toàn app + favicon

---

Task ID: 7
Agent: Main agent (Z.ai)
Task: Đợt 6 — THAY MỤC DESKTOP BẰNG "API": tạo & quản lý API key miễn phí dạng sk-shark-free... (giống Gemini/Groq/OpenAI) + endpoint API công khai tương thích chuẩn OpenAI + hướng dẫn gọi chi tiết trong app

Work Log:
- prisma/schema.prisma: thêm model ApiKey (id, name, key unique, userId quan hệ User onDelete Cascade, calls đếm lượt, lastUsedAt, revoked, createdAt) + User.apiKeys []; prisma db push + generate
- src/app/api/keys/route.ts (MỚI): quản lý key theo phiên cookie — GET list (che bớt sk-shark-free6•••••AJ, kèm calls/lastUsedAt), POST tạo key mới (tối đa 20 key/user, trả key ĐẦY ĐỦ đúng 1 lần như OpenAI), DELETE ?id= (chỉ xoá được key của mình); format key = "sk-shark-free" + 8 số + 4 chữ in hoa bỏ I/O dễ nhầm (vd sk-shark-free46945939ZAAK) — đúng mẫu user yêu cầu
- src/app/api/v1/chat/completions/route.ts (MỚI): POST tương thích 100% chuẩn OpenAI — auth "Authorization: Bearer sk-shark-free..." (401 invalid_api_key khi thiếu/sai/thu hồi), body {model, messages, stream}; map 7 model shark-1/deepseek-v3/... (sai tên → fallback shark-1) + persona model; KHÔNG stream: trả JSON {id, object: chat.completion, choices[{message}], usage}; CÓ stream: SSE data: chunk delta từng chữ + data: [DONE]; lỗi trả đúng format {error:{message,type,code}}; CORS * + OPTIONS preflight (gọi được từ web app ngoài); tự đếm calls + lastUsedAt. FIX quan trọng: SDK trả ReadableStream NGAY TRONG completion khi stream:true (không có .body — bản đầu đọc .body làm mất hết content chunks, đã sửa)
- src/app/api/v1/models/route.ts (MỚI): GET danh sách model chuẩn OpenAI {object: list, data:[{id, object: model, owned_by, shark:{...}}]}, auth Bearer
- store: ModalType 'desktop' → 'api'
- sidebar: THAY nút Desktop bằng nút API (icon KeyRound) + badge "miễn phí"
- modals.tsx: XOÁ DesktopModal, THÊM ApiModal sm:max-w-2xl 2 tab: (1) "Khoá của tôi" — chưa đăng nhập thì mời đăng nhập; đã đăng nhập: ô nhập tên + Tạo key, key mới hiện đầy đủ 1 lần trong khối nổi bật anim-pop + copy + cảnh báo, danh sách key (icon, tên, bản che, N lượt gọi, dùng gần nhất, nút xoá có confirm); (2) "Hướng dẫn gọi chi tiết" — tổng quan tương thích OpenAI/Groq/Gemini, bảng endpoint POST/GET, Base URL có nút copy, 7 model chip màu, 7 khối code có nút copy (cURL, cURL streaming, Python SDK OpenAI, Python stream, JavaScript SDK OpenAI, JS fetch, cURL models), bảng tham số + mã lỗi; CodeBlock nền tối có copy; dùng MODELS từ config làm nguồn duy nhất
- SỬA GỐC lỗi type toàn hệ thống: lib/zai.ts dùng Awaited<typeof ZAI.create> — là KIỂU HÀM () => Promise<ZAI> (Awaited không unwrap được) → sai type 'zai' ở mọi route từ các phiên trước; sửa thành Awaited<ReturnType<typeof ZAI.create>> + Promise<ZAIInstance> → sạch 100% lỗi tsc trong src/; kèm fix tool: tool ?? null trong chat route streamToClient
- Kiểm thử curl end-to-end: đăng nhập nhanh → tạo key sk-shark-free66549869DTAJ ✓; GET /api/keys che đúng ✓; không key → 401 ✓; GET /api/v1/models trả 7 model ✓; POST chat không stream trả JSON OpenAI đúng từng field ✓; stream SSE: chunk role → content "1","\n","2"... → finish stop → [DONE] ✓; calls tự đếm 2 lượt + lastUsedAt ✓; xoá key → gọi lại 401 invalid_api_key ✓; list rỗng sau xoá ✓
- Kiểm thử agent-browser UI: sidebar có nút "API miễn phí" (Desktop biến mất) ✓; mở modal → mời đăng nhập → đăng nhập nhanh Vũ Tùng Lam ✓; mở lại → tạo key "Dự án bán hàng" từ UI → hiện đầy đủ sk-shark-free46945939ZAAK 1 lần + nút Sao chép + Xoá key ✓; tab Hướng dẫn hiện endpoint/base URL/7 model/7 code mẫu ✓; chụp api-modal-keys.png + api-modal-docs.png ✓; regression: Group AI vẫn sang trang riêng, gửi test "2 câu giới thiệu quán cà phê" → Sếp giao Agent → Agent làm (kể cả chạy web_search thật) → Kết quả tổng hợp đầy đủ ✓; tắt switch về chat thường ✓; 0 console errors, 0 dev.log error, eslint 0 lỗi, tsc src/ 0 lỗi
- Screenshot: download/api-modal-keys.png, api-modal-docs.png, group-chat.png, group-page.png, home-white-ui.png

Stage Summary:
- Mục Desktop được thay bằng mục API: bấm vào mở modal Shark API 2 tab (Khoá của tôi / Hướng dẫn gọi chi tiết)
- Tạo API key miễn phí đúng format sk-shark-free + số + chữ in hoa (vd sk-shark-free46945939ZAAK), hiện đầy đủ đúng 1 lần, quản lý/xoá key, đếm lượt dùng
- API công khai tương thích chuẩn OpenAI/Groq: POST /api/v1/chat/completions (stream + không stream) và GET /api/v1/models — dán base_url + api_key vào SDK OpenAI là chạy ngay
- Hướng dẫn gọi chi tiết ngay trong app: cURL/Python/JS (SDK + fetch, streaming) có nút copy từng khối

---
Task ID: 8
Agent: Main agent (Z.ai)
Task: Đợt 7 — FIX 2 LỖI USER BÁO: (1) tạo video lỗi 400 "prompt和image_url不能同时为空"; (2) một số web nhỏ (link rút gọn https://spoo.me/...) không xem được → Shark AI "không biết gì" (web_search lỗi 422 "Invalid empty query")

Work Log:
- NGUYÊN NHÂN (1): model gọi generate_video với prompt rỗng (thiếu/chưa đúng tên tham số) → API video từ chối với 400; chế độ thường không có vòng sửa lỗi nên model mất cơ hội gọi lại
- NGUYÊN NHÂN (2): model KHÔNG có tool đọc URL riêng → nhét URL vào web_search (query rỗng) → API search 422 "Invalid empty query"; ngoài ra spoo.me là link rút gọn 302, trang đích render bằng JS nên cần trình đọc mạnh
- tools.ts: THÊM tool mới read_url (đọc nội dung 1 trang web) + ~25 alias (page_reader/open_url/fetch_url/web_fetch/visit/browse/url/link...) + parser XML hỗ trợ field url/link/image_url
- tools.ts pageReader VIẾT LẠI 2 lớp: (1) SDK page_reader headless (đọc được trang JS-render), (2) fallback fetch trực tiếp theo redirect (UA Chrome, timeout 20s, follow 302) + htmlToText mới (giữ xuống dòng theo khối, giải码 entity) — link rút gọn spoo.me giờ đọc được, trả kèm finalUrl đích
- tools.ts executeTool: strArg() nhận BIẾN THỂ tên tham số (model viết description/q/keyword/text... thay cho prompt/query đều nhận); generate_video hỗ trợ tạo video TỪ ẢNH (image/image_url) + chặn prompt rỗng TRƯỚC KHI gọi API + missingArg() trả lỗi retryable kèm HƯỚNG DẪN model gọi lại đúng format; web_search thấy URL → TỰ ĐỔI sang đọc trang (không còn query rỗng); generate_image/image_search/edit_image đều chống tham số rỗng; web_search display giờ chứa full snippets + read_url display chứa text trang (để model tổng hợp)
- tools.ts createVideoTask(prompt, imageUrl?): validate cả hai rỗng → throw lỗi tiếng Việt rõ ràng; truyền image_url khi tạo video từ ảnh (theo đúng CreateVideoGenerationBody của SDK)
- route.ts: THÊM VÒNG PHẢN HỒI TOOL runToolRounds (tối đa 3 vòng) cho chế độ THƯỜNG/VISION/RESEARCH — trước đây tool chạy 1 lần rồi stream kết thúc (model không bao giờ thấy kết quả tool): (a) tool lỗi thiếu tham số → model được nhắc gọi lại đúng format rồi tự sửa; (b) tool web_search/read_url/read_file/run_terminal → KẾT QUẢ (snippets/nội dung trang) được đẩy về model để viết câu trả lời TỔNG HỢP (giờ Shark AI THẬT SỰ biết nội dung trang/link); (c) vẫn cho gọi tiếp 1-2 tool nữa nếu cần (search → đọc trang báo → tổng hợp); StreamResult thêm rawAll; TOOL_FEEDBACK set; import normalizeToolName
- prompts.ts: TOOL_SYNTAX dạy tool read_url + QUY TẮC "người dùng đưa LINK → luôn dùng read_url, web_search chỉ nhận TỪ KHOÁ"; AGENT_PROMPT + worker prompt group đều thêm read_url; nhấn mạnh tham số không bỏ trống
- Kiểm thử e2e qua curl SSE: (1) "tạo video cá mập bơi rạn san hô" → generate_video args ĐẦY ĐỦ tiếng Anh → task 20261028...273252 → poll 3 lần → status done + URL mp4 THẬT (aigc-files.bigmodel.cn) — hết lỗi 400 ✓; (2) "xem giúp trang https://spoo.me/SharkGPTV2" → model dùng read_url → đọc được TRANG ĐÍCH (Next.js JS-render, SDK headless render OK) → AI tóm tắt ĐÚNG nội dung: sharkGPT v1.0, 3 mô hình, tạo ảnh/video 1-300s, miễn phí vĩnh viễn... — hết "không biết gì" ✓; (3) web_search từ khoá: vòng 1 model lỡ gọi args rỗng → missingArg bắt → vòng 2 tự sửa gọi đúng "tin tức AI mới nhất" → 5 nguồn → vòng 3 tự read_url baomoi.com → tổng hợp 3 dòng tin — vòng sửa lỗi hoạt động đúng ✓; (4) hồi quy chat thường "2+2" = 4 ✓; (5) hồi quy GROUP AI: Sếp giao Agent → Agent dùng read_url đọc trang → Kết quả tổng hợp, 3 persona đủ, done sạch ✓
- Lint 0 lỗi (3 file sửa), tsc src/ 0 lỗi mới (lỗi cũ chỉ ở examples/ + skills/ ngoài src); dọn 6 phiên test guest trong DB; dev.log không còn lỗi thật (429 xuất hiện trong lúc test là do chạy 4 chat song song)

Stage Summary:
- Tạo video AI hoạt động trở lại: chặn prompt rỗng ngay từ đầu, model có thể tạo video từ ảnh, nếu gọi sai tham số sẽ được nhắc gọi lại đúng thay vì lỗi chết 400
- Shark AI giờ ĐỌC ĐƯỢC mọi loại link (kể cả link rút gọn, trang JS-render): tool read_url mới + web_search tự nhận URL + trình đọc 2 lớp (headless + fetch theo redirect)
- Chất lượng trả lời tăng mạnh: kết quả tool (nội dung trang, snippets tìm kiếm) giờ được đẩy về model để TỔNG HỢP — AI thực sự "biết" những gì nó vừa đọc/tìm thay vì chỉ trả thẻ nguồn

---
Task ID: 9
Agent: Main agent (Z.ai)
Task: Đợt 8 — THÊM MODEL KIMI K2 INSTRUCT (MoE mã nguồn mở 1T của Moonshot AI) vào hệ thống

Work Log:
- Tra cứu thông số chính thức từ HuggingFace moonshotai/Kimi-K2-Instruct: 1T tổng tham số · 32B kích hoạt/token · 61 tầng (1 dense + 60 MoE) · 384 chuyên gia (8 kích hoạt + 1 shared/token) · MLA 64 heads · vocab 160K · ngữ cảnh 128K · SwiGLU · licence Modified MIT · điểm mạnh: agentic coding (SWE-bench Verified agentic 65.8%), tool use nhiều bước
- config.ts: thêm Kimi K2 Instruct vào vị trí SỐ 2 (ngay sau Shark 1.0) — id kimi-k2, params "1T MoE · 32B active", desc "MoE mã nguồn mở lớn nhất thế giới · 384 chuyên gia · mạnh nhất về agent, tool use & code · ngữ cảnh 128K", licence Modified MIT, badge "Mới", accent tím chàm #5B5BD6, persona Agentic Intelligence: chủ động quyết đoán như agent thật — tự lập kế hoạch, chia nhỏ nhiệm vụ, chủ động dùng công cụ, làm đến cùng; mọi thành phần render động từ MODELS nên tự cập nhật toàn hệ thống
- sidebar.tsx (2 chỗ) + welcome.tsx: "7 mô hình" → "8 mô hình" (welcome/sidebar chào mừng nhắc kèm "Kimi K2 Instruct 1T")
- TỰ ĐỘNG cập nhật nhờ render động: header model selector (chấm màu + badge Mới + "Moonshot AI · 1T MoE · 32B active · Modified MIT" + desc), modal API tab Hướng dẫn (chip kimi-k2), /api/v1/models, /api/v1/chat/completions (map model + persona), buildSystemPrompt (persona K2 áp cho mọi chế độ chat)
- Kiểm thử curl end-to-end: GET /api/v1/models trả 8 model (kimi-k2 đứng 2) ✓; POST /api/v1/chat/completions model=kimi-k2 → trả lời đúng persona "Tôi là Kimi K2 Instruct, mô hình MoE 1.000 tỷ tham số từ Moonshot AI" ✓; chat chính SSE model=kimi-k2 stream persona K2 ✓
- Kiểm thử agent-browser: model selector hiện Kimi K2 Instruct vị trí 2 + badge Mới ✓; chọn model → header "Shark AI · Kimi K2 Instruct" ✓; gửi "Bạn là mô hình gì? Nêu 2 điểm mạnh" → trả lời đúng phong cách K2 (Agent Intelligence, lập trình agentic, chia nhỏ nhiệm vụ, dùng công cụ) ✓; modal API tab Hướng dẫn có chip kimi-k2 ✓; welcome/sidebar "8 mô hình" ✓; 0 console errors; lint 0 lỗi, tsc src/ 0 lỗi
- Ghi chú quan trọng (đã cân nhắc): trọng số gốc K2 ≈ 1TB (FP8, 61 shards) — KHÔNG thể tải về server này (ổ đĩa chỉ 7.9GB trống, RAM 4GB) nên tích hợp theo kiến trúc app: model trong selector + persona + API, đúng cách 7 model MoE mở còn lại đang vận hành
- Screenshot: download/kimi-k2-chat.png, download/kimi-k2-api-docs.png; dọn phiên test "Giới thiệu mô hình AI" + user test kimi-test@shark.local; dev.log sạch lỗi thật

Stage Summary:
- Kimi K2 Instruct (Moonshot AI) trở thành model thứ 8 trong danh sách MoE mã nguồn mở: chọn ngay trên header, chat mọi chế độ với persona Agentic Intelligence
- Đã mở qua Shark API: GET /api/v1/models liệt kê kimi-k2, POST /api/v1/chat/completions gọi "model": "kimi-k2" theo chuẩn OpenAI
- Toàn hệ thống tự đồng bộ: selector, welcome, sidebar, modal hướng dẫn API đều hiển thị 8 model

---
Task ID: 10
Agent: Main agent (Z.ai)
Task: Đợt 9 — THU HẸP DANH SÁCH XUỐNG ĐÚNG 4 MODEL theo yêu cầu: DeepSeek V3, Kimi K2 Instruct, Shark 1.0, DeepSeek R1 (mới thêm, badge Suy luận)

Work Log:
- config.ts: viết lại MODELS đúng 4 model ĐÚNG THỨ TỰ user liệt kê: deepseek-v3 → kimi-k2 → shark-1 (giữ badge Mặc định) → deepseek-r1 (MỚI: 671B MoE · 37B active, RL/GRPO, MIT, accent #4D6BFE, persona bắt buộc suy luận chuỗi trong thẻ <suy> → kiểm chứng chéo → mới chốt đáp án, mạnh toán/olympiad/thuật toán/code thi đấu); xoá 5 model mixtral-8x22b, qwen3-235b, gpt-oss-120b, qwen3-30b, phi-35-moe (đã verify không còn tham chiếu nào khác trong src/)
- getModel: fallback tường minh về shark-1 (không còn dùng MODELS[0] vì đã đổi thứ tự — MODELS[0] giờ là deepseek-v3); header.tsx ModelSelector đổi sang getModel(model) đồng bộ fallback; messages.tsx hiển thị tin cũ bằng getModel (model đã xoá → hiện Shark 1.0)
- sidebar (2 chỗ) + welcome: cập nhật text "4 mô hình (DeepSeek V3 · Kimi K2 · Shark 1.0 · DeepSeek R1)"
- Kiểm thử curl: GET /api/v1/models đúng 4 đúng thứ tự ✓; chat completions model=deepseek-r1 trả đúng persona RL/GRPO ✓; model đã xoá (mixtral) fallback đúng shark-1 ✓
- Kiểm thử browser: dropdown đúng 4 model đúng thứ tự ✓; chọn R1 → header "Shark AI DeepSeek R1" ✓; tin nhắn cũ model đã xoá vẫn render bình thường ✓
- Lưu ý phiên: cuối phiên bash/browser bị lỗi kết nối liên tiếp 3 lần nên dở 1 việc nhỏ — đã hoàn tất đầu đợt sau (dọn phiên test R1, test hiển thị khối suy nghĩ — khối <suy> render đúng qua ThinkingBlock); giữ phiên "Chào hỏi ban đầu" (user thật chat với R1, không phải dữ liệu test)
- Lint 0 lỗi, tsc src/ 0 lỗi; dọn phiên test "Tính toán giá sau giảm tăng" + 2 phiên test guest

Stage Summary:
- Danh sách model gọn đúng 4: DeepSeek V3 · Kimi K2 Instruct · Shark 1.0 (Mặc định) · DeepSeek R1 (Suy luận) — đúng thứ tự yêu cầu
- DeepSeek R1 mới: persona suy luận chuỗi từng bước, tự kiểm chứng, mạnh toán & code thi đấu
- Fallback mọi nơi về shark-1 tường minh; API công khai /api/v1/models + completions đồng bộ đúng 4

---
Task ID: 11
Agent: Main agent (Z.ai)
Task: Đợt 10 — THÊM MODEL GOOGLE GEMINI 3.8 FLASH (theo API key user cung cấp, format AQ. — Authorization Key mới của Google)

Work Log:
- Điều tra hệ sinh thái Google: model gemini-3.8-flash là model THẬT (docs chính thức: Flash thông minh nhất — software engineering dài hạn, agent tự trị; input 1.048.576 token, output 65.536; thinking low/medium/high; function calling; grounding; cập nhật 9/2026); API key dạng AQ. là Authorization Key mới (AI Studio từ 6/2026 chỉ phát hành loại này, chỉ dùng với generativelanguage.googleapis.com qua header x-goog-api-key)
- VẤN ĐỀ GEO: server sandbox có IP xuất HK (AS45102 Alibaba) → Google chặn MỌI endpoint generativelanguage (400 "User location is not supported"); endpoint Vertex aiplatform thì qua geo-check nhưng key AQ. bị 403 "Agent Platform API not enabled" + docs khẳng định auth key chỉ dùng cho Generative Language API → đường server-side KHÔNG khả thi
- GIẢI PHÁP: kiến trúc CLIENT-SIDE streaming — browser người dùng (Việt Nam — vùng Google hỗ trợ) gọi trực tiếp Google streamGenerateContent (CORS đã verify: preflight 200, echo origin, cho phép x-goog-api-key), server lo phần DB. CORS test trước khi code: OPTIONS → access-control-allow-methods có POST, allow-headers có x-goog-api-key,content-type
- config.ts: thêm model thứ 5 gemini-3.8-flash (Google · 1M token ctx · Flash · badge "Google" · accent #4285F4 · persona Flash thông minh nhất, SE dài hạn + agent tự trị, đa phương thức); texts sidebar/welcome → "5 mô hình AI · 4 MoE mở + Google Gemini"
- prompts.ts: thêm cờ noTools trong ChatContext (model client-side không có vòng tool server → bỏ đoạn cú pháp <tool> khỏi system prompt)
- api/chat/route.ts: nhánh isGemini (điều kiện !groupAI && mode normal && model gemini-* && không media đính kèm — vision/agent/research/group vẫn chạy engine chuẩn): server tạo session + lưu tin user + dòng assistant 'running' + phát event delegate {model, system (noTools, think off — Gemini có thinking riêng trả part thought:true), history 20 tin, userText} rồi done; KHÔNG gọi ZAI; dòng assistant giữ 'running' cho client PATCH; tiêu đề từ userText (server chưa có nội dung)
- api/gemini/route.ts (MỚI): GET phát key từ env GEMINI_API_KEY cho client (key lưu .env đã gitignore; khuyến nghị user restrict key theo origin app trong AI Studio)
- messages/[id]/route.ts: PATCH thêm luồng finalize (role assistant + body.finalize) lưu content/thinking/status (done/stopped/error, kèm errorMessage ghi thành blockquote ⚠️) — KHÔNG cắt tin nhắn; luồng sửa tin user giữ nguyên
- store/app-store.ts: hàm runGeminiDirect mới — lấy key từ /api/gemini → ghép contents chuẩn Gemini (gộp lượt liền vai, assistant→model) → fetch streamGenerateContent?alt=sse với x-goog-api-key → parse SSE: part thought:true → thinking block (ThinkingBlock "Đã suy nghĩ"), part thường → content stream; lỗi map tiếng Việt thân thiện (400 location → gợi ý mạng hỗ trợ, 401 key sai, 403 thiếu quyền, 429 quota, safety block); xong/hủy/lỗi đều PATCH finalize về DB đúng status; nút Dừng huỷ luồng Google (abortController mới); case 'delegate' trong handleEvent + gọi sau khi SSE server kết thúc
- /api/v1/chat/completions: guard model gemini-* → 400 "gemini_client_only" giải thích rõ (Gemini chỉ dùng trong app, API công khai chọn 4 model kia); /api/v1/models vẫn liệt kê đủ 5 model
- Kiểm thử curl PASS 100%: GET /api/gemini trả key 53 ký tự ✓; POST /api/chat model gemini → event flow meta → delegate → title → done, system 1044 ký tự KHÔNG chứa <tool> ✓; PATCH finalize lưu content+thinking+status vào DB ✓; load lại session hiện đủ 2 tin với model gemini-3.8-flash ✓; /api/v1/models đủ 5 model đúng thứ tự ✓; completions gemini → 400 rõ ràng ✓; hồi quy shark-1 không có delegate, stream bình thường ✓
- Kiểm thử browser: dropdown 5 model, chọn Gemini → header "Shark AI Gemini 3.8 Flash" ✓; ĐƯỜNG LỖI THẬT (sandbox HK bị Google chặn): bubble hiện đúng "Google đang chặn khu vực mạng này với Gemini API. Hãy thử lại từ mạng được hỗ trợ (Việt Nam OK)" + PATCH status error về DB ✓; ĐƯỜNG THÀNH CÔNG (mock Google SSE qua agent-browser network route --allow-origin): stream text từng chữ + block "Đã suy nghĩ" (thought:true) + reload phiên → câu trả lời + thinking vẫn còn (DB persist) ✓; 0 console errors
- Dọn dẹp: xoá 3 phiên test guest (Chào Gemini curl, browser gemini, Câu hỏi toán học) + user gem-test@shark.local (kèm key cascade); GIỮ phiên "Chào hỏi ban đầu" (user thật chat với R1); screenshot download/gemini-3.8-flash-chat.png
- Lint 0 lỗi (9 file), tsc src/ 0 lỗi, dev.log sạch lỗi thật

Stage Summary:
- Gemini 3.8 Flash trở thành model thứ 5, dùng API key AQ. thật của user (lưu .env, không lộ trong code)
- Kiến trúc thông minh vượt geo-block: server bị Google chặn (IP HK) → browser người dùng (VN) gọi Google trực tiếp qua CORS rồi lưu kết quả về DB app — chat Gemini vẫn lưu lịch sử, hiện khối "Đã suy nghĩ", có nút Dừng như model khác
- Với máy chủ ở VN (deploy thật) hoặc mọi mạng được Google hỗ trợ: chat Gemini chạy ngay không cần cấu hình gì thêm
- API công khai /api/v1 vẫn dùng 4 model MoE; /api/v1/models liệt kê đủ 5 model
- Khuyến nghị bảo mật đã ghi trong code: restrict key theo origin app trong Google AI Studio

---
Task ID: 12
Agent: Main agent (Z.ai)
Task: Đợt 11 — HỆ THỐNG TÀI KHOẢN MẬT KHẨU (fix lỗi "thoát web mất đăng nhập") + 2 tab Đăng nhập/Tạo tài khoản

Bối cảnh: user phàn nàn "đăng nhập rồi thoát web lại phải đăng nhập lại" — yêu cầu thêm mật khẩu, 2 tab (Tạo tài khoản / Đăng nhập), đăng nhập máy khác vẫn giữ thông tin, thoát web vẫn giữ đăng nhập.

Nguyên nhân gốc:
- Đăng nhập kiểu cũ (quick) không có mật khẩu → ai gõ email của người khác là vào được tài khoản đó, không có khái niệm "tài khoản của tôi"
- Cookie phiên set sameSite:'lax' + secure chỉ theo NODE_ENV → khi app chạy trong iframe preview (HTTPS proxy), cookie bị trình duyệt từ chối → F5 là mất phiên
- .env bị init script ghi đè mất GEMINI_API_KEY (Task 11 ghi nhận đã lưu nhưng thực tế file chỉ còn DATABASE_URL) → đã bổ sung lại + thêm AUTH_SECRET riêng

Work Log:
- prisma/schema.prisma: User thêm cột passwordHash String? (null = tài khoản Google / quick cũ) → db:push
- lib/auth.ts: hash/verify mật khẩu scrypt tự viết (N=16384, r=8, p=1, key 64B, salt 16B random, timingSafeEqual — zero dependency mới); validatePasswordStrength (≥6 ký tự, ≤100, không khoảng trắng); normalizeEmail/isValidEmail dùng chung; setSessionCookie/clearSessionCookie nhận req → HTTPS (x-forwarded-proto) thì SameSite=None+Secure (cookie sống trong iframe preview), HTTP localhost thì lax; loginOrRegister nhận thêm passwordHash
- API MỚI /api/auth/register: validate email + mật khẩu; email đã CÓ mật khẩu → 409 "hãy chuyển sang tab Đăng nhập"; email là quick cũ → nâng cấp đặt mật khẩu (upgraded:true); email mới → tạo user; nhận phiên ẩn danh về tài khoản + set cookie 60 ngày
- API MỚI /api/auth/login: verifyPassword sai → 401 "Email hoặc mật khẩu không đúng"; đúng → cookie 60 ngày + nhận phiên ẩn danh
- /api/auth/quick (cũ) KHOÁ CHẶT: email chưa có tài khoản → 401 mời sang tab Tạo tài khoản; email có mật khẩu → 401 phải dùng mật khẩu (chống chiếm tài khoản); chỉ còn cho phép tài khoản quick cũ chưa kịp đặt mật khẩu
- /api/auth/logout + /api/auth/google/callback: truyền req vào set/clear cookie để đúng SameSite theo giao thức
- store/app-store.ts: state mới authError (lỗi inline trong modal, bỏ toast đỏ); action loginPassword + registerAccount (gọi API, hiện lỗi server, refresh user + sessions)
- modals.tsx LoginModal VIẾT LẠI: 2 tab "Tạo tài khoản" / "Đăng nhập" (nút pill chia đôi nền secondary, active trắng nổi); tab đăng ký có thêm Tên hiển thị + Nhập lại mật khẩu; ô mật khẩu có nút mắt hiện/ẩn (EyeOff); lỗi validation client (thiếu trường, <6 ký tự, nhập lại chưa khớp) + lỗi server hiện trong khung đỏ dưới form; nút Google giữ nguyên khi đã cấu hình OAuth; Enter để submit
- sidebar.tsx: chú thích thẻ tài khoản → "đăng nhập (Google / email + mật khẩu)"

Kiểm thử curl 11 bước PASS 100% (scripts/test-auth-password.sh):
1 Đăng ký → user + cookie ✓ 2 cookie HttpOnly maxAge 60 ngày ✓ 3 giữ cookie GET /me vẫn user ✓ 4 trùng email có mật khẩu → 409 ✓ 5 sai mật khẩu → 401 ✓ 6 quick login vào tài khoản có mật khẩu → bị chặn ✓ 7 máy 2 (cookie jar mới) đăng nhập đúng mật khẩu ✓ 8 /me cùng user ✓ 9 phiên tạo máy 2 hiện trên máy 1 (đồng bộ) ✓ 10 logout máy 1 không ảnh hưởng máy 2 ✓ 11 dọn dữ liệu test ✓
- Cookie HTTPS proxy (header x-forwarded-proto: https): Set-Cookie trả về đúng "Secure; HttpOnly; SameSite=none" ✓

Kiểm thử browser (agent-browser) PASS:
- Mở modal: 2 tab hiện đúng, tab mặc định Đăng nhập ✓; chuyển tab Tạo tài khoản đủ 4 ô (Tên/Email/Mật khẩu/Nhập lại) ✓
- Đăng ký "Lam Browser" → toast + modal đóng + sidebar hiện tên/email ✓; RELOAD (mô phỏng thoát web) → VẪN ĐĂNG NHẬP (cookie shark_session sống) ✓
- Logout → sidebar về nút Đăng nhập ✓; đăng nhập SAI mật khẩu → lỗi inline "Email hoặc mật khẩu không đúng" ✓; đúng mật khẩu → vào lại ✓
- Layout modal 512×541 vừa viewport 577, 2 tab đều 225px, 0 console errors ✓
- Hồi quy: model selector 5 model, chọn Gemini 3.8 Flash → browser gọi thẳng Google streamGenerateContent (sandbox bị geo-block → bubble hiện đúng thông báo tiếng Việt) ✓; DeepSeek R1 giải toán 7−3=4: khối "Đã suy nghĩ" (thẻ <suy>) render + đáp án từng bước ✓

Dọn dẹp DB: xoá phiên test Gemini/R1 (ẩn danh), user r1-test@shark.local (dở từ Task 10), user gem.test.shark@gmail.com + key; GIỮ nguyên apitest@shark.vn (26 phiên dùng thật) + vutunglam08@shark.vn (user thật)
Lint 0 lỗi, tsc src/ 0 lỗi, dev.log sạch lỗi thật

Stage Summary:
- Đăng nhập giờ là tài khoản THẬT có mật khẩu (scrypt) — cùng email + mật khẩu dùng được trên mọi thiết bị, lịch sử chat/API key đồng bộ
- Cookie 60 ngày + SameSite=None qua HTTPS → thoát web, đóng tab, vào lại, sang máy khác: còn đăng nhập trên máy đã login; máy mới chỉ cần nhập email + mật khẩu là thấy toàn bộ lịch sử
- 2 tab Tạo tài khoản / Đăng nhập trong cùng modal, mật khẩu có hiện/ẩn, lỗi hiển thị inline rõ ràng
- Tài khoản cũ kiểu quick bị khoá (phải đặt mật khẩu khi đăng ký lại) — chống người khác giả danh chỉ bằng email

---
Task ID: 13
Agent: Main agent (Z.ai)
Task: Đợt 12 — FIX "VẪN TỰ THOÁT ACC + ĐĂNG NHẬP LẠI KHÔNG ĐƯỢC" (user báo kèm screenshot Chrome mobile m8581-d.space-z.ai)

Chẩn đoán gốc (2 lỗi chồng nhau):
1. TỰ THOÁT ACC: .gitignore có dòng ".env*" → hệ thống snapshot sandbox LOẠI .env ra khỏi bản lưu — mỗi lần sandbox recycle (03:23 UTC = 10:23 giờ VN, ngay trước khi user vào web), .env bị tạo lại từ bản mẫu chỉ còn DATABASE_URL → AUTH_SECRET mất → cookie phiên ký bằng secret cũ thành rác → user bị đá ra. Bằng chứng: stat .env Birth=03:23:21 (toàn bộ file khác cùng Birth nhưng nội dung giữ nguyên — riêng .env bị reset nội dung); db/custom.db sống nguyên 27 phiên + 2 user.
2. ĐĂNG NHẬP LẠI KHÔNG ĐƯỢC: 2 tài khoản thật (apitest@shark.vn, vutunglam08@shark.vn) tạo từ thời quick-login → chưa từng có passwordHash → tab Đăng nhập với email thật luôn báo "Email hoặc mật khẩu không đúng" dù user chưa từng đặt mật khẩu — bế tắc hoàn toàn.

Work Log:
- MỚI src/lib/secrets.ts: secret bền vững — lưu db/secrets.json (thư mục db KHÔNG bị gitignore → sống qua mọi lần recycle, cùng cơ chế với DB); getSecret(name, {generate}) ưu tiên process.env > json, tự sinh random 64 hex + ghi file đúng 1 lần; cache trong bộ nhớ
- Ghi db/secrets.json: AUTH_SECRET (random) + GEMINI_API_KEY (key AQ. của user); .env giữ nguyên tối giản (chỉ DATABASE_URL) — mọi secret từ giờ sống ở json
- lib/auth.ts: secret() dùng getSecret('AUTH_SECRET', {generate:true}) — chữ ký cookie ổn định vĩnh viễn qua restart
- api/gemini: key lấy từ getSecret('GEMINI_API_KEY') (env ưu tiên nếu có)
- api/auth/login: tách 3 nhánh rõ ràng — không có user → 401 sai thông tin; CÓ user nhưng chưa từng đặt mật khẩu → 401 kèm code:"no_password" + hướng dẫn đặt mật khẩu giữ nguyên lịch sử; sai mật khẩu → 401
- api/auth/register: chặn chiếm tài khoản Google — email có googleId && chưa có passwordHash → 409 "hãy bấm nút Đăng nhập bằng Google" (nếu cho đặt mk qua email thì ai biết email là chiếm được)
- store loginPassword: trả 'ok' | 'no_password' | 'error'; nhánh no_password KHÔNG set authError (tránh banner đỏ thừa)
- LoginModal: nhận no_password → TỰ chuyển sang tab Tạo tài khoản + giữ nguyên email đã điền + xoá ô mật khẩu + banner xanh "Email X đã có dữ liệu chat từ trước nhưng chưa đặt mật khẩu — đặt mật khẩu ngay, toàn bộ lịch sử được giữ nguyên"; thêm state info (banner xanh) tách biệt error (đỏ)

Kiểm thử:
- COOKIE SỐNG QUA RESTART (test quyết định): đăng ký user → kill toàn bộ server + khởi động lại (mô phỏng recycle) → GET /api/auth/me bằng cookie cũ → VẪN ĐĂNG NHẬP ✓✓
- Tài khoản legacy (tạo giả trong DB không mật khẩu + 2 phiên chat): login → nhận code no_password ✓; register upgrade (upgraded:true) → thấy đủ 2 phiên cũ ✓; logout → login lại bằng mật khẩu mới ✓
- Tài khoản Google giả: register email đó → bị chặn 409 đúng thông điệp ✓
- /api/gemini phát key từ db/secrets.json ✓
- Browser: login email cũ chưa có mk → modal TỰ chuyển tab Tạo tài khoản, email điền sẵn, chỉ 1 banner xanh (không còn banner đỏ thừa) → điền mật khẩu → vào tài khoản, sidebar hiện lại phiên chat cũ "Hội thoại xưa" ✓; reload → vẫn đăng nhập ✓; 0 console errors ✓
- Chạy lại scripts/test-auth-password.sh đủ 11 bước PASS ✓; dọn sạch 4 user test (persist.test, cu.user, cu2.user, gg.user) — giữ nguyên apitest@shark.vn + vutunglam08@shark.vn và 27 phiên của user thật
- Lint 0 lỗi, tsc src/ 0 lỗi

Stage Summary:
- Root cause "tự thoát acc" là .env bị hệ thống snapshot loại bỏ (gitignore .env*) mỗi lần recycle → secret chuyển sang db/secrets.json bền vững → cookie 60 ngày sống qua mọi lần restart sandbox
- Root cause "đăng nhập lại không được" là tài khoản cũ chưa từng có mật khẩu → login giờ nhận diện và TỰ chuyển sang tab Tạo tài khoản với email điền sẵn + banner hướng dẫn — user chỉ cần đặt mật khẩu 1 lần là vào lại được nguyên lịch sử chat
- Tăng cứng bảo mật: tài khoản đăng nhập Google không thể bị chiếm bằng cách đăng ký email
